var spBeautifyConfigData = {
	"list":[{"type":100,"gid":"56576581922d19d8bd3e1e6b","fid":"e8634e109612c8fcc3ce798c","suffix":"swf","x":886,"y":46,"index":7,"expire":"1577808000","w":100,"h":50}]
	,beautifyList:[
        {
            beautify_id:'56576581922d19d8bd3e1e6b',
            beautify_x:'0',
            beautify_y:'0',
            beautify_fid:'e8634e109612c8fcc3ce798c',
            beautify_name:'װ��������',
            beautify_expire:'1577808000',
            beautify_w:'100',
            beautify_h:'50',
            beautify_tags:'',
            beautify_author:'du�ƹ�',
            beautify_space:'http://hi.baidu.com/sys/checkuser/du%D5%C6%B9%F1/3',
            beautify_type:'100', beautify_status:'0',
            beautify_picsuffix:'swf',
            beautify_thumb:'http://hitn.baidu.cn/du%D5%C6%B9%F1/tnfile/item/57f97b8b6910b912c8fc7a8c.jpg'
        }
    ]
	};