jQuery(document).ready(function($){
    $(window).scroll(function (){
        $("#shangxia").animate({
            top : $(window).scrollTop() + 100 + "px"
        },{
            queue:false,
            duration:500
        });
        return false;
    });
    $('#shang').click(function(){
        $('html,body').animate({
            scrollTop: '0px'
        }, 800);
    });
    $('#xia').click(function(){
        $('html,body').animate({
            scrollTop:$('#footer').offset().top
        }, 800);
    });
    $('#comt').click(function(){
        $('html,body').animate({
            scrollTop: '90px'
        }, 800);
    });
});
