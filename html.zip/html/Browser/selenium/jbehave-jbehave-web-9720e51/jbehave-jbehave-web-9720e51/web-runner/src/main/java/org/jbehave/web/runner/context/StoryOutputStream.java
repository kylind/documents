package org.jbehave.web.runner.context;

import java.io.ByteArrayOutputStream;
import java.io.Serializable;

@SuppressWarnings("serial")
public class StoryOutputStream extends ByteArrayOutputStream implements Serializable {

}
