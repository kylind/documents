To run in IDE, open terminal and start webapp:

mvn jetty:run

The webapp must be running for the flash stories to run.

When using mvn in CLI, jetty is automatically started and stopped before and after stories execution.