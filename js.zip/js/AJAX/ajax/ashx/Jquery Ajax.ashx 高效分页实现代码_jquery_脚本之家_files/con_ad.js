<!--
function switchad(adname,adtpname){
if ($(adname) && $(adtpname)){
$(adname).innerHTML=$(adtpname).innerHTML;
$(adtpname).innerHTML='';
}
} 
try{
switchad("logo_m","logo_m_tp");
switchad("logo_r","logo_r_tp");
switchad("tonglan1","tonglan1_tp");
switchad("con_da2","con_da2_tp");
switchad("baidu300","baidu300_tp");
switchad("mainad2","mainad2-tp");
switchad("con_bo1","con_bo_tp");
addLoadEvent(this.focus());
}catch(e){}
//-->