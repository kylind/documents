﻿<!--
google_ad_client = "pub-6384567588307613";
google_ad_slot = "1524299892";
google_ad_width = 336;
google_ad_height = 280;
document.write('<sc'+'ript type="text/javascript" src="http://pagead2.googlesyndication.com/pagead/show_ads.js"></scr'+'ipt>');
//-->