﻿
var url = window.location.toString();
var Target1="/content/";
var Index1=url.indexOf(Target1);
var Target2="lib.360doc.com";
var Index2=url.indexOf(Target2);

if(Index1<0&&Index2<0)
{
    document.getElementById("ad01").innerHTML="<div id=\"Layer2\"><object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" codebase=\"http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0\" width=\"468\" height=\"60\"><param name=\"movie\" value=\"http://www.360doc.com/ad/59rich.swf\" /><param name=\"quality\" value=\"high\" /><param name=\"wmode\" value=\"transparent\" /><embed src=\"http://www.360doc.com/ad/59rich.swf\" width=\"468\" height=\"60\" quality=\"high\" pluginspage=\"http://www.macromedia.com/go/getflashplayer\" type=\"application/x-shockwave-flash\" wmode=\"transparent\"></embed></object></div><div id=\"Layer1\"><a target=\"_blank\" href=\"http://www.59rich.com\" onclick=\"hitad();\"><img src=\"http://pubimage.360doc.com/ico_jiantou_white.gif\" width=\"468\" height=\"60\" border=\"0\" style=\"filter:alpha(opacity=0);-moz-opacity:0;\"></a></div>";
}

function hitad()
{    
     $.getJSON("http://webservice.360doc.com/hitad.ashx?jsoncallback=?",function(responseText)
             {
               if(responseText!=null)
                {
                }
                else
                {
                    
                }
              }
         ); 
    
}

//updated by chengeng 2009-05-10
//var url = window.location.toString();
//var Target1="/content/";
//var Index1=url.indexOf(Target1);
//var Target2=".html";
//var Index2=url.indexOf(Target2);
//if ((Index1!=-1) && (Index2!=-1))
//{
//   //文章页面
//    var ArticleID="";
//    var ArtUserID="";
//    var ArtIDInt=0;
//    var Mode=-1;
//    var indexArticleFirst = url.lastIndexOf("_");
//    var indexArticleLast = url.lastIndexOf(".html");
//    if (indexArticleLast >= 0) 
//    {
//        ArticleID = url.substring(indexArticleFirst + 1, indexArticleLast);
//    }
//    else 
//    {
//        ArticleID = url.substring(indexArticleFirst + 1);
//    }
//    ArtIDInt=parseInt(ArticleID);
//    Mode=ArtIDInt%2;
//    
//    indexArticleFirst = url.lastIndexOf("/");
//    indexArticleLast = url.lastIndexOf("_");
//    if (indexArticleLast >= 0) 
//    {
//        ArtUserID = url.substring(indexArticleFirst + 1, indexArticleLast);
//    }
//    else 
//    {
//        ArtUserID = url.substring(indexArticleFirst + 1);
//    }
//    var SeeingUserID=getCookie("360docUserID");
//    if (ArtUserID!=SeeingUserID)
//    {
//          //点睛
//           document.write("<scri" + "pt src='http://www230.clickeye.cn/common/clickeye.js'></sc" + "ript>");
//    }
//}
//else
//{
//   //非文章页
//   //不做处理
//}



//function SetCookie(name, value, day, domainName)//四个参数，一个是cookie的名字，一个是值，一个保存天数，一个是域名称
//{
//    var ctuskytime=new Date();
//    ctuskytime.setDate(ctuskytime.getDate()+1);
//    ctuskytime.setHours(0);
//    ctuskytime.setMinutes(0);
//    ctuskytime.setSeconds(0);
//     
//	document.cookie = name + "=" + escape(value) + ";path=/;expires=" + ctuskytime.toGMTString()+";domain=" + domainName + ";";
//}
//function getCookie(name)//取cookies函数        
//{
//    var arr = document.cookie.match(new RegExp("(^| )" + name + "=([^;]*)(;|$)"));
//    if (arr != null) 
//        return unescape(arr[2]);
//    return null;
//}


//var url = window.location.toString();
//var Target1="/index.html";
//var Index1=url.indexOf(Target1);

//if (url=="http://www.360doc.com/"||url=="http://www.360doc.com.cn/"||url=="http://360doc.com/"||url=="http://360doc.com.cn/"||url.indexOf("http://lib.360doc.com")!=-1||url.indexOf("http://rel.360doc.com")!=-1||Index1!=-1)
//{
//    var strcookie=getCookie("360docpopupad");
//    if(strcookie==null)
//    {
//        document.write('<sc'+'ript src="http://www.unionbig.com/c2679.js" type=text/javascript></scr'+'ipt>');
//        SetCookie("360docpopupad", "1");    
//        loadad();    
//    }
//}
//function loadad()
//{
//    $.getJSON("http://webservice.360doc.com/popad.ashx?url="+escape(url)+"jsoncallback=?",function(responseText)
//             {
//               if(responseText!=null)
//                {
//                }
//                else
//                {
//                    
//                }
//              }
//         ); 
//}


