var makeDrag_flag=false;var oPos,cPos;var makeDrop_objs = [];
var winbg="<div id=\"winbg\"><iframe id=\"winbg2\" frameborder=\"0\" height=\"100%\" width=\"100%\"></iframe></div>";
var win="<div id=\"newwin\"></div><div id=\"newwin2\"></div>";
var stylestr="<style type=\"text/css\">body{display:block;height:100%;}"
+"#newwin_text ul,#newwin_text ol,#newwin_text h5,#newwin_text form,#newwin_text h1,#newwin_text h2,#newwin_text h3,#newwin_text h4,#newwin_text h6"
+"{margin:0px;padding:0px;}"
+"#newwin{background:#000;}"
+"#newwin2{border:0 solid #E1E7F2;}"
+"#winbg{position:fixed;_ position:absolute;z-index:1;background:#000;filter: alpha(opacity=60);opacity:0.6;width:100%;height:100%;left:0px;top:0px;display:none;color:#FFF;}"
+"#winbg2{position:fixed;_ position:absolute;width:100%;height:100%;filter: alpha(opacity=0);opacity:0;top:0px;left:0px;font-size:0;background:#000;display:none;}"
+"#dragBar{text-align:right;font-size:14px;color:#ffffff;margin-bottom:0px;cursor:pointer;}"
+"#closeButton{float:right;cursor:pointer;font-size:18px;font-family:Verdana;color:#ffffff;font-weight:bold;display:block;height:18px;width:18px;line-height:18px;margin:4px 8px 3px 3px;text-align:center;}"
+"#newwin_text{color:#555555;font-size:14px;line-height:28px;word-break:break-all;background:#ffffff;clear:both;display:inline-block;}</style>";
document.write(stylestr);
/*
document.write(win);
document.write(style);
document.write(winbg);*/
var newwin=document.createElement('div');newwin.id="newwin";
var newwin2=document.createElement('div');newwin2.id="newwin2";
var winbg=document.createElement('div');winbg.id="winbg";
var winbg2=document.createElement('iframe');winbg2.id="winbg2";
var style=document.createElement('div');
//style.AppendText(stylestr);
window.onload=function(){
var b=document.getElementsByTagName('body')[0];
b.appendChild(newwin);
b.appendChild(newwin2);
b.appendChild(winbg);
b.appendChild(winbg2);
b.appendChild(style);style.innerHTML=stylestr;
//popwin("str",700,400,'#67A7E3');
}
function Opacity(element, value){
    var style = element.style;
    style.opacity = value / 100;
    style.filter = "alpha(opacity=" + value + ")";
}

function getObjPos(obj)
{var x=0,y = 0;
	if (obj.getBoundingClientRect)
	{
		var box = obj.getBoundingClientRect();
		var D = document.documentElement;
		x = box.left + Math.max(D.scrollLeft, document.body.scrollLeft) - D.clientLeft;
		y = box.top + Math.max(D.scrollTop, document.body.scrollTop) - D.clientTop;		
	}
	else
	{for(; obj != document.body; x += obj.offsetLeft, y += obj.offsetTop, obj = obj.offsetParent );}
	return {'x':x, 'y':y};
}

function getCurPos(e)
{
	e = e || window.event;
	var D = document.documentElement;
	if (e.pageX) return {x: e.pageX, y: e.pageY};
	return {
		x: e.clientX + D.scrollLeft - D.clientLeft,
		y: e.clientY + D.scrollTop - D.clientTop	
	};
}

function makeDrag(o)
{  var obj=o.parentNode;
	o.onmousedown = function (e)
	{   o.style.cursor='move';
		if (!document.all) e.preventDefault();
		var oPos = getObjPos(obj);
		var cPos = getCurPos(e);
		makeDrag_flag = true;
		document.onmouseup = function (e){
			makeDrag_flag = false;
			document.onmousemove = null;
			document.onmouseup = null;
			o.style.cursor='default';
	    };
		document.onmousemove = function (e)
		{
			if (makeDrag_flag)
			{
				obj.style.position = 'absolute';
				var Pos = getCurPos(e);
				obj.style.left = Pos.x - cPos.x + oPos.x + 'px';
				obj.style.top = Pos.y - cPos.y + oPos.y + 'px';
				var win = document.getElementById("newwin");
				win.style.left = Pos.x-cPos.x+oPos.x+5+ 'px';
				win.style.top = Pos.y-cPos.y+oPos.y+5+ 'px';
			}
			return false;
		}
	}
}


function popwin(str,fw,fh,TitleBar_bgColor)
 {      closeWin(false);
        var maxw=parseInt(document.documentElement.clientWidth);
		var maxh=parseInt(document.documentElement.clientHeight);
		var maxw2=parseInt(document.documentElement.scrollWidth);
		var maxh2=parseInt(document.documentElement.scrollHeight);
		var h=(maxh<maxh2?maxh2:maxh);
		var w=(maxw<maxw2?maxw2:maxw);
		fh=(fh<h?fh:h);
		fw=(fw<w?fw:w);
        var px=(maxw-fw)/2;
		var py=(maxh-fh)/2+parseInt(document.body.scrollTop||document.documentElement.scrollTop);
		var h1=25;
		var h2=fh-h1;
		TitleBar_bgColor=(TitleBar_bgColor==("parent"||null||"")?"#0099ff":TitleBar_bgColor);
		var Class_0="height:"+h2+"px;width:"+fw+"px;"; //��������
		var Class_1="height:"+h1+"px;background:"+TitleBar_bgColor+";line-height:"+h1+"px;width:"+fw+"px;";//������
		var TitleBar="<div style=\""+Class_1+"\" onselectstart=\"return false\" id=\"dragBar\">\n";
		TitleBar+="<span id=\"closeButton\">��</span></div>"
		var divbody="<div style=\""+Class_0+"\" id=\"newwin_text\">"+str+"</div>";
	    var newwin1=document.getElementById("newwin");
	    var newwin2=document.getElementById("newwin2");
	    if (document.all){newwin2.style.border="1px solid "+TitleBar_bgColor;}
	    popwin_winStyle(newwin2,'absolute',px,py,fw,fh,3);
	    popwin_winStyle(newwin1,'absolute',px+5,py+5,fw,fh,2);
	    Opacity(newwin1,30);
		newwin2.innerHTML=TitleBar+divbody;
		document.body.appendChild(newwin2);
		document.body.appendChild(newwin1);
		document.getElementById("winbg").style.display="block";
		document.getElementById("winbg").style.height=h+"px";
		/***/
		var closeBtn=document.getElementById("closeButton");
		closeBtn.onclick=function(){closeWin(true);}
		closeBtn.onmouseover=function(){this.style.color='#555';}
		closeBtn.onmouseout=function(){this.style.color='#FFF';}
		/***/
		makeDrag(document.getElementById("dragBar"));
	}
	
function popwin_winStyle(o,oPosition,oLeft,oTop,oWidth,oHeight,ozIndex,ovisibility,odisplay)
{ 
    var divstyle=o.style;
		divstyle.position=(oPosition==undefined?'absolute':oPosition);
		divstyle.display=(odisplay==undefined?'block':odisplay);
		divstyle.visibility=(ovisibility==undefined?'visible':ovisibility);
		divstyle.zIndex = ozIndex;
		divstyle.left=oLeft+"px";
		divstyle.top=oTop+"px";
		divstyle.width=oWidth+"px";
		divstyle.height=oHeight+"px";
}

function closeWin(flag)
{
var o=new Array("winbg","winbg2","newwin","newwin2");
for (var i=0;i<o.length;i++)
{
if(document.getElementById(o[i]))
document.getElementById(o[i]).style.display=(flag==true?'none':'');
}
}

//��ק
//�ԡ��϶��㡱���壺onMousedown="StartDrag(this)" onMouseup="StopDrag(this)" onMousemove="Drag(this)"����
/*
function startDrag(a,e) 
{var obj=a.parentNode;
	e=e||event;
if(e.which||e.button==1) 
{
oPos=getObjPos(obj);
cPos=getCurPos(e);
moveable = true;
document.onmouseup = function (e){
			moveable=false;
			document.onmousemove = null;
			document.onmouseup = null;}
}//end if
} 
//�϶�; 
function drag(a,e) 
{ 
var obj=a.parentNode;
e=e||event;
if(moveable) 
{ 
var win = document.getElementById("newwin");
var Pos = getCurPos(e);
obj.style.left = Pos.x - cPos.x + oPos.x + 'px';
obj.style.top = Pos.y - cPos.y + oPos.y + 'px';
win.style.left=Pos.x - cPos.x + oPos.x +5+ 'px';
win.style.top=Pos.y - cPos.y + oPos.y +5+ 'px';
a.style.cursor='move';
} 
} 
//ֹͣ�϶�; 
function stopDrag(obj,e) 
{ e=e||event;
if(moveable)
{
var win = document.getElementById("newwin");
moveable=false; 
obj.style.cursor='default';
} 
} 
*/
function popwindow(documentSource,width,height,bgColor)
{
    var str="<iframe id=\"newWindow\" src=\""+documentSource+"\" frameborder=\"0\" width=\""+width+"\" height=\""+height+"\">";
    popwin(str,width,height,bgColor);
}

