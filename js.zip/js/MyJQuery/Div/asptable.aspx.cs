﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Div_asptable : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
        //if (!IsPostBack)
        //{
            TableRow row = new TableRow();
            TableCell cell = new TableCell();
            TextBox tb=new TextBox();
            tb.Text="kylin";
            cell.Controls.Add(tb);
            row.Cells.Add(cell);
            kylin.Rows.Add(row);

            tb = new TextBox();
            cell = new TableCell();
            tb.Text = "";
            cell.Controls.Add(tb);
            row.Cells.Add(cell);
            
            kylin.Rows.Add(row);

            myid.Text = "sfsfsf";



             row = new TableRow();
            cell = new TableCell();
             tb = new TextBox();
             Table table = new Table();
            tb.Text = "mykylin";
            cell.Controls.Add(tb);
            row.Cells.Add(cell);
            table.Rows.Add(row);

            tb = new TextBox();
            cell = new TableCell();
            tb.Text = "";
            cell.Controls.Add(tb);
            row.Cells.Add(cell);

            table.Rows.Add(row);

            mydiv.Controls.Add(table);





            TextBox a = (TextBox)kylin.Rows[0].Cells[1].Controls[0];
            string s = a.Text;

            TextBox b = (TextBox)jack.Rows[0].Cells[1].Controls[0];
            s = b.Text;
       // }
    }

    protected override void OnPreRenderComplete(EventArgs e)
    {
        base.OnPreRenderComplete(e);

        TextBox a = (TextBox)kylin.Rows[0].Cells[1].Controls[0];
        string s = a.Text;

        TextBox b = (TextBox)jack.Rows[0].Cells[1].Controls[0];
         s = b.Text;
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        TextBox a = (TextBox)kylin.Rows[0].Cells[1].Controls[0];
        string s = a.Text;

        TextBox b = (TextBox)jack.Rows[0].Cells[1].Controls[0];
        s = b.Text;
    }
}
