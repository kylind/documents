﻿
function step1() {
//    var exitTime = (new Date()).getTime() + 2000;
//    while ((new Date()).getTime() < exitTime) { }
}

function step2() {
    console.trace();
    setTimeout(function() {

        var exitTime = (new Date()).getTime() + 3000;
        while ((new Date()).getTime() < exitTime) { }
    }, 5000);

}

function step3() {

//    var exitTime = (new Date()).getTime() + 1000;
//    while ((new Date()).getTime() < exitTime) { }

}

function process() {
    console.time('processTime');
    step1();
    step2();
    console.timeEnd('processTime');

    console.profile('processProfile');
    step1();
   // step2();
    step3();
    console.profileEnd();

    console.group('i am father');
    console.log('i am son');
    console.groupEnd();

}

$(function() {

    $('#lick').click(function() {
        console.log('clike');
        var exitTime = (new Date()).getTime() + 5000;
        while ((new Date()).getTime() < exitTime) { }
    });
    process();
})