﻿///<reference path="jquery-1.3.2-vsdoc2.js"/>
$(function(){
 var txts= txt.split(',');
 var vals=val.split(',');
 
 for(var i=0;i<txts.length;i++)
 {
  $('#mySelect').append("<option value='"+vals[i]+"'>"+txts[i]+"</option>");
 }
 
});

