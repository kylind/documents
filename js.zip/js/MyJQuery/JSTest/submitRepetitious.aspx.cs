﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class JSTest_submitRepetitious : System.Web.UI.Page
{
    public static int s = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        //string s="this.disabled=true;" + this.ClientScript.GetPostBackEventReference(Button2, "");
        //Button2.Attributes.Add("onclick", s);
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        s++;
        System.Threading.Thread.Sleep(5000);
        TextBox1.Text = s+string.Empty;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        s++;
        TextBox1.Text = s+string.Empty;
        System.Threading.Thread.Sleep(5000);
    }
}
