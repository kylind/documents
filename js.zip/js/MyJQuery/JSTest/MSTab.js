﻿(function($) {

    var options;
    //extend jquery object
    $.fn.msTab = function(setting) {
        options = $.extend(true, {}, $.fn.msTab.defaultSetting, setting);
        initTab.call(this);
    };
    //publish defaultSetting
    $.fn.msTab.defaultSetting = {
        customtd: "",
        beforeClick: null,
        afterClick: null
    };

    //private function,init tab
    function initTab() {
        var currentindex = options.openIndex;
        var tabs = options.tabs;
        generateTab.call(this, tabs, currentindex);
        //Handler click event
        var self;
        $("td[tindex]").click(function(e) {
            self = this;
            if ($.isFunction(options.beforeClick)) {
                options.beforeClick(e, function() {
                    tabClicking();
                    if ($.isFunction(options.afterClick)) {
                        options.afterClick(e);
                    }
                });
            } else {
                tabClicking();
                if ($.isFunction(options.afterClick)) {
                    options.afterClick(e);
                }
            }
        });

        //internal  clicking handler function
        function tabClicking() {
            var tabIndex = $(self).attr("tindex");
            if (tabIndex != currentindex) {
                //Hanlder tab clicked previous
                var clicked = $("td[tindex='" + currentindex + "']");
                toggleClass(clicked, currentindex);
                showorHide(tabs[currentindex].panels, false);
                //Handler tab clicked currently
                currentindex = tabIndex;
                toggleClass($(self), currentindex);
                showorHide(tabs[currentindex].panels, true);
            }
        }
    }

//generate table
    function generateTab(tabs, currentindex) {
        //Init AutoTab
        var tabtd = '';
        for (var i = 0; i < tabs.length; i++) {
            if (i == 0) {
                tabtd = tabtd.concat('<td class="off_left"></td>', '<td class="off_line" tindex="' + i + '">' + tabs[i].name + "</td>", '<td class="off_off"></td>');
            } else if (i == tabs.length - 1) {
                tabtd = tabtd.concat('<td class="off_line" tindex="' + i + '">' + tabs[i].name + '</td>', '<td class="off_right></td>');
            } else {
                tabtd = tabtd.concat('<td class="off_line" tindex="' + i + '">' + tabs[i].name + '</td>', '<td class="off_off"></td>');
            }
            showorHide(tabs[i].panels, false);
        }
        if (options.customtd != "")
            tabtd = tabtd.concat(options.customtd);

        var tabtr = $('<table id="tabgroup"><tr></tr></table>').find("tr").append(tabtd).end();
        var currentTab = tabtr.find("td[tindex='" + currentindex + "']")
        toggleClass(currentTab, currentindex);
        this.html(tabtr);
        showorHide(tabs[currentindex].panels, true);
    }


    function showorHide(panels, op) {
        var p = null;
        if (panels instanceof Array) {
            for (var i = 0; i < panels.length; i++) {
                p = $("#" + panels[i]);
                op ? p.show() : p.hide();
            }
        } else {
            p = $("#" + panels);
            op ? p.show() : p.hide();
        }
    }

    function toggleClass(currentTab, currentindex) {
        var prev = currentTab.prev();
        var next = currentTab.next();
        if (currentindex == 0) {
            prev.toggleClass("on_left");
            next.toggleClass("on_off");

        } else if (currentindex == options.tabs.length - 1) {
            prev.toggleClass("off_on");
            next.toggleClass("on_right");

        } else {
            prev.toggleClass("off_on");
            next.toggleClass("on_off");
        }
        currentTab.toggleClass("on_line");

    }
    //end wrap package
})(jQuery);