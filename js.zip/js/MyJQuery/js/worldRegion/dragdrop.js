/**
 * @author achen2
 */
Chart.Common.Controls.IDragControl = function(){
    this.getContainer = function(){
    };
    this.isInDragArea = function(pt){
    };
    this.dragTo = function(pt){
    };
    
    var me = this;
    var _draging = false;
    var _dragPoint = {
        x: 0,
        y: 0
    };
    
    var onBeginDrag = function(e){
        var pt = $.getPosition(me.getContainer, e);
        if (me.isInDragArea(pt)) {
            _dragPoint.x = pt.x;
            _dragPoint.y = pt.y;
            _draging = true;
            $('body').bind("selectstart", function(){
                return false;
            });
            //_controlContainer.CaptureMouse();
        }
    };
    var onEndDrag = function(e){
        _draging = false;
    };
    var onDraging = function(e){
        if (_draging) {
            var pt = $.getPosition(me.getContainer, e);
            pt.x -= _dragPoint.x;
            pt.y -= _dragPoint.y;
            me.dragTo(targetPoint);
        }
    };
    var initializeEx = function(){
        var container = $(me.getContainer());
        if (container && container.length > 0) {
            container.mousemove();
            container.mouseup();
            container.mousedown();
        }
    };
    intializeEx();
};

$.extend({
    dragger: {
		cover: null, //use to prevent the other event when draging.
		helper: null,
		draggerIndex: 1,
		draggerOptions: new Dictionary()	//Key:index, Value:options
	}
});

$.fn.extend({
    undrag: function(o){
    
    },
	dragOption: function(o){
		var index = parseInt(this.attr('draggerIndex'),10) || 0;
		if (index && $.dragger.draggerOptions.containsKey(index)) {
			$.extend($.dragger.draggerOptions.item(index), o);
		}
	},
    drag: function(o){
        var options = {
            rect: {
                x: 0,
                y: 0,
                width: 0,
                height: 0
            },
            isInDragArea: function(pt){
                return true;
            },
            onBeginDrag: function(e){
            },
            onEndDrag: function(e){
            },
            onDraging: function(e){
            }
        };
        var pointer = {
            x: 0,
            y: 0
        };
        var draging = false;
        var element = null;
        var me = this;
		var index = $.dragger.draggerIndex;
        $.extend(options, o);
		$.dragger.draggerIndex++;
		$.dragger.draggerOptions.updateItem(index,options);
        
        var dragStart = function(e){
            var pt = $.getPosition(this, e);
            if (options.isInDragArea(pt)) {
                //createCover();
                createHelper();
                
				var abspt = $.getPosition(null,e);
                var doc = $(document);
                element = {
                    object: this,
                    ref: $(this),
                    width: $(this).width(),
                    height: $(this).height(),
                    parentOffset: $(this).parent().offset()
                };
                draging = true;
                pointer.x = pt.x;
                pointer.y = pt.y;
                
                $.dragger.helper.empty();
                $.dragger.helper.css({
					"display": "block",
					width: element.width + 2,
					height: element.height + 2,
					left: abspt.x - pt.x,
					top: abspt.y - pt.y
				});
                /*
                 $.dragger.cover.css({
                 "display": "block",
                 width: doc.width() + 2,
                 height: doc.height() + 2
                 })
                 */
                element.ref.clone(true).appendTo($.dragger.helper).css({
                    left: 0,
                    top: 0
                });
                
                doc.bind("mousemove", dragmove).bind("mouseup", dragStop);
				document.onselectstart = function(){return false;};
                if (options.onBeginDrag) {
					options.onBeginDrag.apply(me, [e]);
				}
            }
        };
        var dragStop = function(e){
            draging = false;
            $.dragger.helper.empty();
            $.dragger.helper.css({
                display: "none"
            });
            /*
             $.dragger.cover.css({
             display: "none"
             });
             */
            var pt = $.getPosition(element.ref.parent().get(0), e);
            pt.x -= pointer.x;
            pt.y -= pointer.y;
            pt.x = options.rect.width > 0 && (pt.x + element.width) > options.rect.width ? options.rect.width - element.width : pt.x;
            pt.y = options.rect.height > 0 && (pt.y + element.height) > options.rect.height ? options.rect.height - element.height : pt.y;
            pt.x = pt.x > options.rect.x ? pt.x : options.rect.x;
            pt.y = pt.y > options.rect.y ? pt.y : options.rect.y;
            element.ref.css({
                left: pt.x,
                top: pt.y
            });
            
            element = null;
            $(document).unbind('mousemove', dragmove).unbind('mouseup', dragStop);
			document.onselectstart = null;
            if (options.onEndDrag) {
				options.onEndDrag.apply(me, [e]);
			}
        };
        var dragmove = function(e){
            if (draging) {
                var pt = $.getPosition(null, e);
                //var ptoffset = $.getPosition(element.parentNode, e);
                //eleRef.html(String.format("{0},{1}", pt.x, pt.y));
                pt.x -= pointer.x;
                pt.y -= pointer.y;
                pt.x = options.rect.width > 0 && (pt.x + element.width - element.parentOffset.left) > options.rect.width ? options.rect.width - element.width + element.parentOffset.left : pt.x;
                pt.y = options.rect.height > 0 && (pt.y + element.height - element.parentOffset.top) > options.rect.height ? options.rect.height - element.height + element.parentOffset.top : pt.y;
                pt.x = pt.x > options.rect.x + element.parentOffset.left ? pt.x : options.rect.x + element.parentOffset.left;
                pt.y = pt.y > options.rect.y + element.parentOffset.top ? pt.y : options.rect.y + element.parentOffset.top;
                $.dragger.helper.css({
                    left: pt.x,
                    top: pt.y
                });
                if (options.onDraging) {
					options.onDraging.apply(me, [e]);
				}
            }
        };
        var selectstart = function(){
            return false;
        };
        
        var createCover = function(){
            if (!$.dragger.cover) {
                $.dragger.cover = $('<div id="dragCover"></div>').appendTo(jQuery('body', document));
                $.dragger.cover.css({
                    "position": "absolute",
                    "display": "none",
                    "overflow": "hidden",
                    //"background-color": "#FFFFFF",
                    "margin-left": 0,
                    "margin-top": 0,
                    "margin-bottom": 0,
                    "margin-rigth": 0
                });
            }
        };
        var createHelper = function(){
            if (!$.dragger.helper) {
                $.dragger.helper = $('<div id="dragHelper"></div>').appendTo(jQuery('body', document));
				$.dragger.helper.addClass("drag-panel");
                $.dragger.helper.css({
                    "position": "absolute",
                    "display": "none",
                    "cursor": "move",
                    "listStyle": "none",
                    "overflow": "hidden",
                    "margin-left": 0,
                    "margin-top": 0,
                    "margin-bottom": 0,
                    "margin-rigth": 0
                });
                $.dragger.helper.onselectstart = function(){
                    return false;
                };
                $.dragger.helper.ondragstart = function(){
                    return false;
                };
                if (window.ActiveXObject) {
                    $.dragger.helper.each(function(){
                        this.unselectable = "on";
                    });
                }
                else {
                    $.dragger.helper.css({
                        '-moz-user-select': 'none',
                        'user-select': 'none',
                        '-khtml-user-select': 'none'
                    });
                }
            }
        };
        
        this.each(function(){
			//capture mouse
			if (window.ActiveXObject) {
				this.onselectstart = function(){
					return false;
				};
				this.ondragstart = function(){
					return false;
				};
			}
			var el = this;
			var dhe = options.handle ? $(this).find(options.handle) : $(this);
			if ($.browser.msie) {
				dhe.each(function(){
					this.unselectable = "on";
				});
			}
			else {
				dhe.css({
					'-moz-user-select': 'none',
					'user-select': 'none',
					'-khtml-user-select': 'none'
				});
			}
			
			dhe.bind('mousedown', dragStart);
			dhe.attr('draggerIndex', index);
		});
		
		return index;
    }
});
