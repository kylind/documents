function Dictionary() {
    var me = this; 		//closure

    this.compareMode = 1; 	//compare mode for equal,0=binary;1=text

    this.count = 0; 		//length

    this.arrKeys = new Array(); //Keys

    this.arrValues = new Array(); //Values

    this.throwException = true; //will throw exception or not

    this.item = function(key)		//Get item by key, will throw exception when key don't exist
    {
        var idx = _getElementIndexInArray(me.arrKeys, key);
        if (idx != -1) {
            return me.arrValues[idx];
        }
        else {
            if (me.throwException)
                throw "Exception when tring to match key, special key may not exist";
        }
    };

    this.keys = function()		//Get all keys
    {
        return me.arrKeys;
    };

    this.values = function()		//Get all values
    {
        return me.arrValues;
    };

    this.updateItem = function(key, value) {  //Update item by key, will create it when key is not found.
        var idx = _getElementIndexInArray(me.arrKeys, key);
        if (idx != -1) {
            return me.arrValues.splice(idx, 1, value);
        }
        else {
            this.add(key, value);
        }
    };

    this.add = function(key, value)	//Add a new key value pair, will throw exception when key exist.
    {
        if (_checkKey(key)) {
            me.arrKeys[me.count] = key;
            me.arrValues[me.count] = value;
            me.count++;
        }
        else {
            if (me.throwException)
                throw "Exception when tring to add key, special key exist";
        }
    };

    this.batchAdd = function(keys, values)	//return false when don't make any change
    {
        var bSuccessed = false;
        if (keys != null && keys != undefined && values != null && values != undefined) {
            if (keys.length == values.length && keys.length > 0)	//key list and value list should have the same length
            {
                var allKeys = me.arrKeys.concat(keys);
                if (!_isArrayElementRepeat(allKeys))
                {
                    me.arrKeys = allKeys;
                    me.arrValues = me.arrValues.concat(values);
                    me.count = me.arrKeys.length;
                    bSuccessed = true;
                }
            }
        }
        return bSuccessed;
    };

    this.clear = function()
    {
        if (me.count != 0) {
            me.arrKeys.splice(0, me.count);
            me.arrValues.splice(0, me.count);
            me.count = 0;
        }
    };

    this.containsKey = function(key)
    {
        return _getElementIndexInArray(me.arrKeys, key) != -1;
    };

    this.containsValue = function(value)
    {
        return _getElementIndexInArray(me.arrValues, value) != -1;
    };

    this.remove = function(key)
    {
        var idx = _getElementIndexInArray(me.arrKeys, key);
        if (idx != -1) {
            me.arrKeys.splice(idx, 1);
            me.arrValues.splice(idx, 1);
            me.count--;
            return true;
        }
        else
            return false;
    };

    this.tryGetValue = function(key, defaultValue)	//Try to find value in dictionay, will return defaultValue when key not found
    {
        var idx = _getElementIndexInArray(me.arrKeys, key);
        if (idx != -1) {
            return me.arrValues[idx];
        }
        else
            return defaultValue;
    };

    this.toString = function()	//tostring, format as "keys;values"
    {
        if (me.count == 0)
            return "";
        else
            return me.arrKeys.toString() + ";" + me.arrValues.toString();
    };

    function _checkKey(key)	//private
    {
        if (key == null || key == undefined || key == "" || key == NaN)
            return false;
        return !me.containsKey(key);
    };

    function _getElementIndexInArray(arr, e)	//private: get element index, return -1 if element not found.
    {
        var idx = -1;
        var i;
        if (!(arr == null || arr == undefined || typeof (arr) != "object")) {
            try {
                for (i = 0; i < arr.length; i++) {
                    var bEqual;
                    if (me.compareMode == 0)
                        bEqual = (arr[i] === e);	//binary
                    else
                        bEqual = (arr[i] == e);		//text
                    if (bEqual) {
                        idx = i;
                        break;
                    }
                }
            }
            catch (err) {
            }
        }
        return idx;
    };

    function _isArrayElementRepeat(arr)	//private
    {
        var bRepeat = false;
        if (arr != null && arr != undefined && typeof (arr) == "object") {
            var i;
            for (i = 0; i < arr.length - 1; i++) {
                var bEqual;
                if (me.compareMode == 0)
                    bEqual = (arr[i] === arr[i + 1]);	//binary mode
                else
                    bEqual = (arr[i] == arr[i + 1]);	//text mode
                if (bEqual) {
                    bRepeat = true;
                    break;
                }
            }
        }
        return bRepeat;
    };
}
