/**----------------------------------WorldRegion-------------------------**/
Chart.WorldRegion = function(containerDOM, displayStyle){
	this.cId = +new Date();	
	this.container = containerDOM;
	this.displayStyle = 0;
	
	this.dataSource = null;
	this.graph = null;
	
	this.graphCanvas = null;
	this.floatCanvas = null;
	
	this.canvasWidth = 0;
	this.canvasHeight = 0;
	
	if (displayStyle !== null && parseInt(displayStyle,10) >= 0) {
		this.displayStyle = displayStyle;
	}
	
	if (containerDOM) {
		this._initialize();
	}
	return this;
};
Chart.WorldRegion.prototype = $.extend(new Chart.Common.Graphic.GraphElement(), {
	/*
	 * override
	 */
	resizeComponents: function(width, height){
		this.canvasWidth = width;
		this.canvasHeight = height;
		
		this.graphCanvas.css({
			width: width,
			height: height
		});
		
		this.graph.resize(width, height);
	},

	/*
	 * override
	 */
	refresh: function(){
		var me = this;
		this.displayStyle = Math.floor(Math.random()+0.5);
		this.graph.setDisplayStyle(this.displayStyle);
		this.dataSource.refresh(function(){
			me.dataSource.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.REFRESH_PRESENTATION, null));
		});
	},
	/*
	 * interface for push data mode
	 * @param jsonStr {string} data string, in JSON format.
	 * @return null;
	 */
	setData: function(jsonStr){
		this.dataSource.setData(jsonStr);
	},
	/*
	 * another interface for push data mode, call refresh directly.
	 */
	draw: function(){
		this.dataSource.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.REFRESH_PRESENTATION, null));
	},

	/*
	 * interface for update culture
	 * @param cultureName {string} culture name string, such as "en_GB"
	 * @return null;
	 */
	setCulture: function(cultureName){
		var me = this;
		LocalizationManager.instance.setCurrentCulture(cultureName, function(){
			me.dataSource.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.SET_CULTURE, null));
		});
	},

	_initialize: function(){
		this.canvas = this.container.get(0);
		this.canvasWidth = this.container.width();
		this.canvasHeight = this.container.height();
		
		this._createElements();
		this._createComponents();
	},
	_createComponents: function(){
		this.dataSource = new Chart.Component.WorldRegionData();
		this.graph = new Chart.Component.WorldRegionGraph(this.graphCanvas, this.displayStyle);
		this.graph.setDataSource(this.dataSource);
		this.graph.collectionChildren();
		
		this.dataSource.collectionChildren();
		this.dataSource.addChild(this.graph);
		this.dataSource.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.INITIALIZE, null));
	},
	_createElements: function(){
		this.container.attr({
			"cid": this.cId
		});
		this.container.addClass("worldregion");
		this.graphCanvas = $($.Canvas.createDiv(this.container, "relative", 0, 0, this.canvasWidth, this.canvasHeight)).attr({
			"cid": this.cId
		});
		/*
		this.floatCanvas = $($.Canvas.createDiv(this.container, "absolute", 0, 0, 0, 0)).attr({
			"id": "phTip" + this.cId,
			"cid": this.cId
		});
		*/
		this.floatCanvas = $("<div></div>").appendTo(this.container).attr({
			"id": "phTip" + this.cId,
			"cid": this.cId
		});
	}
});

Chart.WorldRegion.DisplayStyle = {
	AmericaCenter: 0,
	EuropeCenter: 1,
	AsiaCenter: 2
};

Chart.WorldRegion.RegionDefinitions = {
    USA: {
        code: "R00",
        name: "USA"
    },
    CAN: {
        code: "R01",
        name: "Canada"
    },
    SouthAmerica: {
        code: "R1",
        name: "Latin American"
    },
    UK: {
        code: "R2",
        name: "United Kingdom"
    },
    DevelopedEuro: {
        code: "R3",
        name: "Europe Developed"
    },
    EmergingEuro: {
        code: "R4",
        name: "Europe Emerging"
    },
    Africa: {
        code: "R5",
        name: "Africa/Middle East"
    },
    Japan: {
        code: "R6",
        name: "Japan"
    },
    Australia: {
        code: "R7",
        name: "Australia"
    },
    DevelopedAsia: {
        code: "R8",
        name: "Asia Developed"
    },
    EmergingAsia: {
        code: "R9",
        name: "Asia Emerging"
    },

    RegionNA: {
        code: "N/A",
        name: "N/A"
    },
    getRegionByCode: function(code) {
        switch (code) {
            case "R00":
                return this.USA;
            case "R01":
                return this.CAN;
            case "R1":
                return this.SouthAmerica;
            case "R2":
                return this.UK;
            case "R3":
                return this.DevelopedEuro;
            case "R4":
                return this.EmergingEuro;
            case "R5":
                return this.Africa;
            case "R6":
                return this.Japan;
            case "R7":
                return this.Australia;
            case "R8":
                return this.DevelopedAsia;
            case "R9":
                return this.EmergingAsia;
            default:
                return this.RegionNA;
        }
    }
};

Chart.WorldRegion.RegionData = function(){
	this.code = "";
	this.color = "";
	this.value = 0;
	this.label = "";
};

Chart.WorldRegion.LegendBar = function(){
	this.color = "#FFFFFF";
	this.label = "";
};

Chart.Interface.WorldRegionInterface = function(){
};
Chart.Interface.WorldRegionInterface.prototype = {
    /*
     * get region data dictionary.
     * @param none
     * @return {Dictionary<Chart.WorldRegion.RegionDefinitions, Chart.WorldRegion.RegionData>}
     */
    getRegionData: function(){
        return null;
    },
    /*
     * get legend
     * @param none
     * @return {List<LegendBar>}
     * @require no
     */
    getLegendItems: function(){
        return null;
    }
};
/*-------------------------------------------------------WorldRegionData-------------------------------*/
Chart.Component.WorldRegionData = function(){
	var today = new Date();
	today = new Date(today.getFullYear(), today.getMonth(), today.getDate());
	this._rawData = new Dictionary();
	this._legendBars = [];
	
	var me = this;
	
//	var data = new Chart.WorldRegion.RegionData();
//	data.code = Chart.WorldRegion.RegionDefinitions.NorthAmerica;
//	data.color = "#999966";
//	data.value = 20;
//	data.label = "North American";
//	this._rawData.add(Chart.WorldRegion.RegionDefinitions.NorthAmerica, data);
};
Chart.Component.WorldRegionData.prototype = $.extend(new Chart.Common.Command.CommandHandler(), new Chart.Interface.WorldRegionInterface(),{
	/*
	 * set data and option
	 * @param {string} in JSON format.
	 */
	setData: function(jsonStr){
		var d = +new Date();
		this.reset();
		
		var data = $.evalJSON(jsonStr);
		if (!data) {
			return;
		}

		if (data.Regions) {
			var length = data.Regions.length;
			for (var i = 0; i < length; i++) {
				var regionData = new Chart.WorldRegion.RegionData();
				regionData.code = Chart.WorldRegion.RegionDefinitions.getRegionByCode(data.Regions[i].Code);
				regionData.value = data.Regions[i].Value;
				regionData.color = data.Regions[i].Color;
				var labelName = data.Regions[i].Label ? data.Regions[i].Label.Name : "";
				regionData.label = StrFormatter.getFormattedLabel(data.Regions[i].Code, labelName);
				this._rawData.add(regionData.code, regionData);
			}
		}

		if(data.LegendBars){
			var barlength = data.LegendBars.length;
			for (var j = 0; j < barlength; j++) {
				var bar = new Chart.WorldRegion.LegendBar();
				bar.color = data.LegendBars[j].Color;
				bar.label = data.LegendBars[j].Label ? data.LegendBars[j].Label.Name : "";
				this._legendBars.push(bar);
			}
		}
		
		//parse chart setting.
		var setting = {
			chart: {
				option: {}
			}
		};
		
		if (data.Type != null && parseInt(data.Type, 10) >= 0) {
			setting.chart.option.displaystyle = data.Type;
		}
		
		if (data.BGColor) {
			Chart.Setting.Presentation.BG.serialize(setting, Chart.Setting.SettingItem.Chart, {
				color: data.BGColor
			});
		}
		
		this.executeCommand(
			new Chart.Common.Command.CommandArgs(
				null, 
				Chart.Common.Command.Commands.APPLY_CHART_SETTING, 
				{setting:setting}));
		
		ChartLogger.instance.write("[time-consuming] time consuming of set data interface: " + (new Date() - d));
	},
	/*
	 * hook function
	 */
	refresh: function(callback){
		if(callback && typeof(callback)== "function"){
			callback();
		}
	},
	/*
	 * clear all cache data.
	 */
	reset: function(){
		this._rawData.clear();
		this._legendBars = [];
	},
	/*
     * override. filter commands.
     * @param arg {Chart.Common.Command.CommandArgs} content.
     * @return the handler event of target command.
     */
	getHandler: function(args){
		switch (args.command) {
			case Chart.Common.Command.Commands.ADD_INVESTMENT:
			case Chart.Common.Command.Commands.DELETE_ITEM:
			case Chart.Common.Command.Commands.REFRESH_PRESENTATION:
			case Chart.Common.Command.Commands.RESIZE:
			case Chart.Common.Command.Commands.INITIALIZE:
			case Chart.Common.Command.Commands.COMPONENT_STATUS_UPDATE:
				return this.defaultHandler;
			default:
				return this.defaultHandler;
		}
		return this.defaultHandler;
	},
	/*
     * default command handler, the purpose of this is the enable all commmand will be passed to children.
     * @param arg {Chart.Common.Command.CommandArgs} content.
     * @return null.
     */
	defaultHandler: function(args){
		//do nothing here.
	},
	/*
     * get region data dictionary.
     * @param none
     * @return {Dictionary<Chart.WorldRegion.RegionDefinitions, Chart.WorldRegion.RegionData>}
     */
    getRegionData: function(){
        return this._rawData;
    },
	getLegendItems: function(){
        return this._legendBars;
    }
});
/*----------------------WorldRegionGraph-------------------------------- */
Chart.Component.WorldRegionGraph = function(target, displayStyle) {
    this._displayStyle = displayStyle;
    this._placeHolder = target;
    this._placeHolder.css({
        "position": "relative",
        "background-color": "transparent",
        "cursor": "default"
    });
    this._margin = {
        left: 0,
        top: 0,
        right: 0,
        bottom: 25
    };
    this._defaultColor = "#ffffff";
    this._defaultLegendBars = [
		{ color: this._defaultColor, label: "N/C" },
		{ color: "#bdc4d6", label: "0-10" },
		{ color: "#a6acc2", label: "10-20" },
		{ color: "#8695ac", label: "20-50" },
		{ color: "#64739c", label: "50-90" },
		{ color: "#213a73", label: ">90%" }
	];
    this._regionCoordinate = new Dictionary();
    this._datasource = null;
    this._tooltipFactory = new Chart.Common.Controls.BasicTipFactory(target.attr("cid"));
    this._tooltip = null;

    this._headerCanvas = null;
    this._graphCanvas = null;
    this._legendCanvas = null;
    this._tooltipCanvas = null;
    this._messageCanvas = null;

    var mainGraph = this;
    /*----------------------presentation belongs to WorldRegion Graph's property-------------------------------- */
    this.Presentation = function() {
    };

    this.Presentation.GraphElement = function() {
    };
    this.Presentation.GraphElement.prototype = $.extend(new Chart.Common.Graphic.GraphElement(), {});

    this.Presentation.LegendArea = function() {
        this.canvas = mainGraph._legendCanvas;
        this.canvasRef = $(this.canvas);
        this.ctx = null;
        this._graphics = null;
        this.barLayer = null;
        this.labelLayer = null;

        this.BAR_HEIGHT = 5;
        this.LABEL_OFFSET = 2;

        var me = this;

        var _createElement = function() {
            var graphSize = {
                width: me.getWidth(),
                height: me.getHeight()
            };
            me.barLayer = $.Canvas.create(me.canvasRef, "absolute", 0, 0, graphSize.width, graphSize.height);
            me.labelLayer = $.Canvas.createDiv(me.canvasRef, "absolute", 0, 0, graphSize.width, graphSize.height);
            me.ctx = me.barLayer.getContext("2d");
            me._graphics = new $.Graphics(me.ctx);
        };

        _createElement();
    };
    this.Presentation.LegendArea.prototype = $.extend(new this.Presentation.GraphElement(), {
        getRange: function(xrange, yrange) {

        },
        resizeComponents: function(width, height) {
            this.barLayer.width = width;
            this.barLayer.height = height;
            this.labelLayer.width = width;
            this.labelLayer.height = height;
            $(this.barLayer).css({
                width: width,
                height: height
            });
            $(this.labelLayer).css({
                width: width,
                height: height
            });
        },
        refresh: function() {
            var d = +new Date();
            this._dragLegend();
            ChartLogger.instance.write("[time-consuming] time consuming of drawing legend area: " + (new Date() - d));
        },
        reset: function() {
            this.ctx.clearRect(0, 0, this.getWidth(), this.getHeight());
            $(this.labelLayer).html("");
        },
        _dragLegend: function() {
            this.reset();

            var legend = mainGraph._datasource.getLegendItems();
            if (!legend || legend.length <= 0) {
                legend = mainGraph._defaultLegendBars;
            }

            var length = legend.length, left = 0, unitWidth = Math.floor(this.getWidth() / length);
            for (var i = 0; i < length; i++) {
                var item = legend[i];
                this._graphics.setLineStyle(1,"#bdc4dc");
                this._graphics.setNormalFill(item.color);
                this._graphics.begin();
                this._graphics.drawRectangle(left, 0, unitWidth, this.BAR_HEIGHT);
                this._graphics.end();
                this._graphics.setLineStyle(0);
                $.TextStudio.create(item.label, this.labelLayer, "absolute", left, this.LABEL_OFFSET + this.BAR_HEIGHT, null, null, "coordinate");
                left += unitWidth;
            }
        }
    });

    this.Presentation.GraphArea = function() {
        this.canvas = mainGraph._graphCanvas;
        this.ctx = this.canvas.getContext("2d");
        this._graphics = new $.Graphics(this.ctx);
        this._margin = {
            left: 0,
            right: 0,
            top: 5,
            bottom: 5
        };

        /*
        $.ajax({
        type: "GET",
        url: uri,
        success: function(msg){
        callback(true, msg);
        ChartLogger.instance.write("[download-resource] success to download resource: " + uri);
        },
        error: function(msg){
        ChartLogger.instance.write("[download-resource] failed to download resource: " + uri);
        downloadFileEx(fileUri, callback);
        return;
        }
        });
        */


        this.RegionCoordination = {
            StandardSize: [370, 188],

            AsiaBorder: [0, 117],
            AmericaBorder: [130, 243],
            EuroBorder: [279, 370],

            //Americas: North America
           // NorthAmerica: [172, 0, 207, 0, 203, 4, 203, 6, 221, 24, 212, 32, 228, 47, 228, 50, 227, 52, 225, 52, 218, 60, 211, 60, 211, 68, 203, 75, 203, 82, 201, 84, 199, 84, 199, 79, 197, 76, 188, 76, 188, 88, 176, 76, 165, 76, 160, 69, 160, 52, 148, 39, 140, 48, 136, 48, 136, 43, 140, 39, 130, 30, 130, 15, 137, 8, 164, 8],
            CAN: [172, 0, 207, 0, 203, 4, 203, 6, 221, 24, 212, 32, 228, 47, 228, 50, 227, 52, 225, 52, 220, 58, 207, 58, 201, 63, 201, 58, 200, 58, 200, 54, 160, 54, 148, 39, 140, 48, 136, 48, 136, 43, 140, 39, 130, 30, 130, 15, 137, 8, 164, 8],
            USA: [160, 54, 200, 54, 200, 58, 201, 58, 201, 63, 207, 58, 220, 58, 218, 60, 211, 60, 211, 68, 203, 75, 203, 82, 201, 84, 199, 84, 199, 79, 197, 76, 188, 76, 188, 88, 176, 76, 165, 76, 160, 69, 160, 52 ],
            
            NorthAmericaSpace1: [192, 14, 207, 14, 207, 16, 200, 22, 200, 40, 186, 27, 186, 24, 192, 18],
            NorthAmericaSpace2: [195, 47, 197, 47, 207, 58, 201, 63, 201, 58, 200, 58, 200, 54, 189, 54],
            // 220, 58 , 207, 58, 201, 63, 201, 58, 200, 58, 200, 54, 160,54, 
       
            //Americas: Latin America
            SourceAmerica: [160, 69, 165, 76, 176, 76, 188, 88, 188, 93, 192, 93, 196, 88, 196, 98, 206, 98, 208, 96, 218, 96, 243, 121, 243, 137, 229, 150, 229, 154, 213, 167, 213, 175, 209, 175, 209, 188, 204, 188, 198, 182, 198, 159, 202, 156, 202, 138, 194, 130, 194, 113, 202, 104, 187, 104, 161, 78],
            //Americas: N/A
            America: [200, 85, 208, 85, 208, 89, 200, 89],

            //Greater Europe: United Kingdom
            UK: [295, 28, 295, 43, 288, 36],
            //Greater Europe: Europe Developed
            WestEuro: [316, 10, 340, 10, 347, 18, 294, 71, 292, 71, 284, 62, 284, 59, 306, 36, 298, 29, 298, 27],
            WestEuro1: [288, 36, 288, 40, 284, 40],
            //Greater Europe: Europe Emerging
            EmergingEuro: [359, 5, 361, 5, 370, 14, 370, 71, 328, 71, 318, 62, 316, 62, 310, 69, 308, 69, 302, 63],
            EmergingEuroSpace1: [356, 52, 358, 52, 362, 56, 358, 59, 358, 70, 353, 66, 353, 56],

            //Greater Europe: Africa/Middle East
            Africa: [292, 71, 370, 71, 370, 84, 365, 84, 347, 102, 347, 104, 349, 105, 349, 107, 339, 116, 339, 134, 330, 142, 330, 150, 311, 169, 309, 169, 309, 126, 298, 114, 286, 114, 279, 107, 279, 84],
            AfricaSpace1: [328, 79, 346, 96, 346, 101, 328, 84],
            Africa1: [343, 135, 356, 135, 345, 147, 343, 147],
            AfricaSpace2: [303, 63, 308, 69, 310, 69, 317, 62, 328, 71, 294, 71],

            //Greater Asia: Japan
            Japan: [92, 55, 94, 55, 94, 67, 84, 77, 72, 77, 72, 75],
            //Greater Asia: Australia
            Australia: [57, 129, 79, 129, 90, 140, 90, 162, 78, 173, 68, 162, 41, 162, 41, 145],
            Australia1: [105, 155, 107, 155, 107, 167, 100, 174, 97, 174, 92, 168],
            //Greater Asia: Four Tiger/Asia Developed
            Tiger1: [59, 73, 64, 73, 64, 78],
            Tiger2: [63, 85, 63, 91, 57, 91],
            Tiger3: [55, 90, 50, 90, 50, 95],
            Tiger4: [33, 109, 39, 109, 39, 114, 37, 114],
            //Greater Asia: Asia Emerging
            EmergingAsia: [0, 82, 38, 44, 82, 44, 82, 46, 64, 63, 64, 73, 59, 73, 55, 70, 55, 90, 50, 90, 45, 90, 45, 91, 39, 91, 45, 97, 45, 99, 35, 109, 32, 109, 20, 97, 0, 117],
            EmergingAsia1: [39, 115, 55, 115, 48, 124],
            EmergingAsia2: [55, 116, 69, 101, 69, 116],
            EmergingAsia3: [70, 115, 93, 115, 82, 126, 80, 126],
            //Greater Asia: N/A
            Asia: [14, 0, 56, 0, 63, 8, 81, 8, 88, 16, 117, 16, 117, 24, 95, 44, 93, 44, 80, 32, 78, 32, 75, 35, 75, 37, 81, 44, 38, 44, 0, 82, 0, 14],

            /*
            * convert a coordinate array to a point collection.
            * @param regionArray {[]} coordinate array, which has even length;
            * @param offset {{x:0,y:0}} point offset
            * @param scale {{x:1,y:1}} scale rate, default as 1, value >0
            * @return [{x: y:},...]
            */
            getCoordinate: function(regionArray, offset, scale, margin) {
                if (!offset) {
                    offset = {
                        x: 0,
                        y: 0
                    };
                }
                if (!scale) {
                    scale = {
                        x: 1,
                        y: 1
                    };
                }

                size = {
                    x: this.StandardSize[0] * scale.x,
                    y: this.StandardSize[1] * scale.y
                };

                var pts = [], x = 0, y = 0;
                var length = regionArray.length;
                if (length % 2 == 1) {
                    length--;
                }
                for (var i = 0; i < length; i = i + 2) {
                    x = regionArray[i] * scale.x + offset.x;
                    x = x < 0 ? size.x + x : x;
                    x = x > size.x ? x - size.x : x;
                    y = regionArray[i + 1] * scale.y + offset.y;
                    y = y < 0 ? size.y + y : y;
                    y = y > size.y ? y - size.y : y;
                    pts.push({
                        x: x + margin.left,
                        y: y + margin.top
                    });
                }
                return pts;
            }
        };
    };
    this.Presentation.GraphArea.prototype = $.extend(new this.Presentation.GraphElement(), {
        resizeComponents: function(width, height) {
        },
        refresh: function() {
            var d = +new Date();
            this._drawAreaGraph();
            ChartLogger.instance.write("[time-consuming] time consuming of drawing graph area: " + (new Date() - d));
        },
        reset: function() {
            this.ctx.clearRect(0, 0, this.getWidth(), this.getHeight());
            mainGraph._regionCoordinate.clear();
        },
        _drawAreaGraph: function() {
            this.reset();

            var scale = {
                x: (this.getWidth() - this._margin.right - this._margin.left) / this.RegionCoordination.StandardSize[0],
                y: (this.getHeight() - this._margin.top - this._margin.bottom) / this.RegionCoordination.StandardSize[1]
            }, offset = {
                x: 0,
                y: 0
            };

            switch (mainGraph._displayStyle) {
                case Chart.WorldRegion.DisplayStyle.EuropeCenter:
                    offset.x = -this.RegionCoordination.AmericaBorder[0] * scale.x;
                    break;
                case Chart.WorldRegion.DisplayStyle.AsiaCenter:
                    //offset.x = -this.RegionCoordination.AmericaBorder[0] * scale.x
                    break;
            }

            var regionData = mainGraph._datasource.getRegionData();
            var data = null;
            var ptsArray = null;


            ptsArray = [];
            ptsArray.push(this.RegionCoordination.getCoordinate(this.RegionCoordination.America, offset, scale, this._margin));
            ptsArray.push(this.RegionCoordination.getCoordinate(this.RegionCoordination.Asia, offset, scale, this._margin));
            mainGraph._regionCoordinate.add(Chart.WorldRegion.RegionDefinitions.RegionNA, ptsArray);
            
            data = regionData.tryGetValue(Chart.WorldRegion.RegionDefinitions.RegionNA, null);
            if(data.color=="#ffffff")
                this._graphics.setLineStyle(1, "#bdc4d6");
            else
                this._graphics.setLineStyle(0);
            this._graphics.setNormalFill(data && data.color ? data.color : mainGraph._defaultColor);
            this._graphics.begin();
            //America N/A
            this._graphics.drawPolygon(ptsArray[0]);
            //Asia N/A
            this._graphics.drawPolygon(ptsArray[1]);
            this._graphics.end();

            //North America
            //			ptsArray = [];
            //			ptsArray.push(this.RegionCoordination.getCoordinate(this.RegionCoordination.NorthAmerica, offset, scale, this._margin));
            //			mainGraph._regionCoordinate.add(Chart.WorldRegion.RegionDefinitions.NorthAmerica, ptsArray);
            //			
            //			data = regionData.tryGetValue(Chart.WorldRegion.RegionDefinitions.NorthAmerica, null);
            //			this._graphics.setNormalFill(data && data.color ? data.color : mainGraph._defaultColor);
            //			
            //			this._graphics.begin();
            //			this._graphics.drawPolygon(ptsArray[0]);
            //			this._graphics.end();
            //USA
            ptsArray = [];
            ptsArray.push(this.RegionCoordination.getCoordinate(this.RegionCoordination.USA, offset, scale, this._margin));
            mainGraph._regionCoordinate.add(Chart.WorldRegion.RegionDefinitions.USA, ptsArray);
            data = regionData.tryGetValue(Chart.WorldRegion.RegionDefinitions.USA, null);
            if (data.color == "#ffffff")
                this._graphics.setLineStyle(1, "#bdc4d6");
            else
                this._graphics.setLineStyle(0);
            this._graphics.setNormalFill(data && data.color ? data.color : mainGraph._defaultColor);
            this._graphics.begin();
            this._graphics.drawPolygon(ptsArray[0]);
            this._graphics.end();
            //CAN
            ptsArray = [];
            ptsArray.push(this.RegionCoordination.getCoordinate(this.RegionCoordination.CAN, offset, scale, this._margin));
            mainGraph._regionCoordinate.add(Chart.WorldRegion.RegionDefinitions.CAN, ptsArray);
            data = regionData.tryGetValue(Chart.WorldRegion.RegionDefinitions.CAN, null);
            if (data.color == "#ffffff")
                this._graphics.setLineStyle(1, "#bdc4d6");
            else
                this._graphics.setLineStyle(0);
            this._graphics.setNormalFill(data && data.color ? data.color : mainGraph._defaultColor);
            this._graphics.begin();
            this._graphics.drawPolygon(ptsArray[0]);
            this._graphics.end();
            //Latin America
            ptsArray = [];
            ptsArray.push(this.RegionCoordination.getCoordinate(this.RegionCoordination.SourceAmerica, offset, scale, this._margin));
            mainGraph._regionCoordinate.add(Chart.WorldRegion.RegionDefinitions.SouthAmerica, ptsArray);
            data = regionData.tryGetValue(Chart.WorldRegion.RegionDefinitions.SouthAmerica, null);
            if (data.color == "#ffffff")
                this._graphics.setLineStyle(1, "#bdc4d6");
            else
                this._graphics.setLineStyle(0);
            this._graphics.setNormalFill(data && data.color ? data.color : mainGraph._defaultColor);
            this._graphics.begin();
            this._graphics.drawPolygon(ptsArray[0]);
            this._graphics.end();
            //UK
            ptsArray = [];
            ptsArray.push(this.RegionCoordination.getCoordinate(this.RegionCoordination.UK, offset, scale, this._margin));
            mainGraph._regionCoordinate.add(Chart.WorldRegion.RegionDefinitions.UK, ptsArray);
            data = regionData.tryGetValue(Chart.WorldRegion.RegionDefinitions.UK, null);
            if (data.color == "#ffffff")
                this._graphics.setLineStyle(1, "#bdc4d6");
            else
                this._graphics.setLineStyle(0);
            this._graphics.setNormalFill(data && data.color ? data.color : mainGraph._defaultColor);
            this._graphics.begin();
            this._graphics.drawPolygon(ptsArray[0]);
            this._graphics.end();
            //Europe Developed
            ptsArray = [];
            ptsArray.push(this.RegionCoordination.getCoordinate(this.RegionCoordination.WestEuro, offset, scale, this._margin));
            ptsArray.push(this.RegionCoordination.getCoordinate(this.RegionCoordination.WestEuro1, offset, scale, this._margin));
            mainGraph._regionCoordinate.add(Chart.WorldRegion.RegionDefinitions.DevelopedEuro, ptsArray);
            data = regionData.tryGetValue(Chart.WorldRegion.RegionDefinitions.DevelopedEuro, null);
            if (data.color == "#ffffff")
                this._graphics.setLineStyle(1, "#bdc4d6");
            else
                this._graphics.setLineStyle(0);
            this._graphics.setNormalFill(data && data.color ? data.color : mainGraph._defaultColor);
            this._graphics.begin();
            this._graphics.drawPolygon(ptsArray[0]);
            this._graphics.drawPolygon(ptsArray[1]);
            this._graphics.end();
            //Europe Emerging
            ptsArray = [];
            ptsArray.push(this.RegionCoordination.getCoordinate(this.RegionCoordination.EmergingEuro, offset, scale, this._margin));
            mainGraph._regionCoordinate.add(Chart.WorldRegion.RegionDefinitions.EmergingEuro, ptsArray);
            data = regionData.tryGetValue(Chart.WorldRegion.RegionDefinitions.EmergingEuro, null);
            if (data.color == "#ffffff")
                this._graphics.setLineStyle(1, "#bdc4d6");
            else
                this._graphics.setLineStyle(0);
            this._graphics.setNormalFill(data && data.color ? data.color : mainGraph._defaultColor);
            this._graphics.begin();
            this._graphics.drawPolygon(ptsArray[0]);
            this._graphics.end();
            //Europe Africa
            ptsArray = [];
            ptsArray.push(this.RegionCoordination.getCoordinate(this.RegionCoordination.Africa, offset, scale, this._margin));
            ptsArray.push(this.RegionCoordination.getCoordinate(this.RegionCoordination.Africa1, offset, scale, this._margin));
            mainGraph._regionCoordinate.add(Chart.WorldRegion.RegionDefinitions.Africa, ptsArray);
            data = regionData.tryGetValue(Chart.WorldRegion.RegionDefinitions.Africa, null);
            if (data.color == "#ffffff")
                this._graphics.setLineStyle(1, "#bdc4d6");
            else
                this._graphics.setLineStyle(0);
            this._graphics.setNormalFill(data && data.color ? data.color : mainGraph._defaultColor);
            this._graphics.begin();
            this._graphics.drawPolygon(ptsArray[0]);
            this._graphics.drawPolygon(ptsArray[1]);
            this._graphics.end();
            //Asia Japan
            ptsArray = [];
            ptsArray.push(this.RegionCoordination.getCoordinate(this.RegionCoordination.Japan, offset, scale, this._margin));
            mainGraph._regionCoordinate.add(Chart.WorldRegion.RegionDefinitions.Japan, ptsArray);
            data = regionData.tryGetValue(Chart.WorldRegion.RegionDefinitions.Japan, null);
            if (data.color == "#ffffff")
                this._graphics.setLineStyle(1, "#bdc4d6");
            else
                this._graphics.setLineStyle(0);
            this._graphics.setNormalFill(data && data.color ? data.color : mainGraph._defaultColor);
            this._graphics.begin();
            this._graphics.drawPolygon(ptsArray[0]);
            this._graphics.end();
            //Asia Australia
            ptsArray = [];
            ptsArray.push(this.RegionCoordination.getCoordinate(this.RegionCoordination.Australia, offset, scale, this._margin));
            ptsArray.push(this.RegionCoordination.getCoordinate(this.RegionCoordination.Australia1, offset, scale, this._margin));
            mainGraph._regionCoordinate.add(Chart.WorldRegion.RegionDefinitions.Australia, ptsArray);
            data = regionData.tryGetValue(Chart.WorldRegion.RegionDefinitions.Australia, null);
            if (data.color == "#ffffff")
                this._graphics.setLineStyle(1, "#bdc4d6");
            else
                this._graphics.setLineStyle(0);
            this._graphics.setNormalFill(data && data.color ? data.color : mainGraph._defaultColor);
            this._graphics.begin();
            this._graphics.drawPolygon(ptsArray[0]);
            this._graphics.drawPolygon(ptsArray[1]);
            this._graphics.end();
            //Asia Emerging
            ptsArray = [];
            ptsArray.push(this.RegionCoordination.getCoordinate(this.RegionCoordination.EmergingAsia, offset, scale, this._margin));
            ptsArray.push(this.RegionCoordination.getCoordinate(this.RegionCoordination.EmergingAsia1, offset, scale, this._margin));
            ptsArray.push(this.RegionCoordination.getCoordinate(this.RegionCoordination.EmergingAsia2, offset, scale, this._margin));
            ptsArray.push(this.RegionCoordination.getCoordinate(this.RegionCoordination.EmergingAsia3, offset, scale, this._margin));
            mainGraph._regionCoordinate.add(Chart.WorldRegion.RegionDefinitions.EmergingAsia, ptsArray);
            data = regionData.tryGetValue(Chart.WorldRegion.RegionDefinitions.EmergingAsia, null);
            if (data.color == "#ffffff")
                this._graphics.setLineStyle(1, "#bdc4d6");
            else
                this._graphics.setLineStyle(0);
            this._graphics.setNormalFill(data && data.color ? data.color : mainGraph._defaultColor);
            this._graphics.begin();
            this._graphics.drawPolygon(ptsArray[0]);
            this._graphics.drawPolygon(ptsArray[1]);
            this._graphics.drawPolygon(ptsArray[2]);
            this._graphics.drawPolygon(ptsArray[3]);
            this._graphics.end();
            //Asia Developed
            ptsArray = [];
            ptsArray.push(this.RegionCoordination.getCoordinate(this.RegionCoordination.Tiger1, offset, scale, this._margin));
            ptsArray.push(this.RegionCoordination.getCoordinate(this.RegionCoordination.Tiger2, offset, scale, this._margin));
            ptsArray.push(this.RegionCoordination.getCoordinate(this.RegionCoordination.Tiger3, offset, scale, this._margin));
            ptsArray.push(this.RegionCoordination.getCoordinate(this.RegionCoordination.Tiger4, offset, scale, this._margin));
            mainGraph._regionCoordinate.add(Chart.WorldRegion.RegionDefinitions.DevelopedAsia, ptsArray);
            data = regionData.tryGetValue(Chart.WorldRegion.RegionDefinitions.DevelopedAsia, null);
            if (data.color == "#ffffff")
                this._graphics.setLineStyle(1, "#bdc4d6");
            else
                this._graphics.setLineStyle(0);
            this._graphics.setNormalFill(data && data.color ? data.color : mainGraph._defaultColor);
            this._graphics.begin();
            this._graphics.drawPolygon(ptsArray[0]);
            this._graphics.drawPolygon(ptsArray[1]);
            this._graphics.drawPolygon(ptsArray[2]);
            this._graphics.drawPolygon(ptsArray[3]);
            this._graphics.end();

            //draw space
            this._graphics.setNormalFill("#ffffff");
            this._graphics.begin();
            this._graphics.drawPolygon(this.RegionCoordination.getCoordinate(this.RegionCoordination.NorthAmericaSpace1, offset, scale, this._margin));
            this._graphics.drawPolygon(this.RegionCoordination.getCoordinate(this.RegionCoordination.NorthAmericaSpace2, offset, scale, this._margin));
            this._graphics.drawPolygon(this.RegionCoordination.getCoordinate(this.RegionCoordination.EmergingEuroSpace1, offset, scale, this._margin));
            this._graphics.drawPolygon(this.RegionCoordination.getCoordinate(this.RegionCoordination.AfricaSpace1, offset, scale, this._margin));
            this._graphics.drawPolygon(this.RegionCoordination.getCoordinate(this.RegionCoordination.AfricaSpace2, offset, scale, this._margin));
            this._graphics.end();
        }
    });

    this.Presentation.MessagePanel = function() {
        this.canvas = mainGraph._messageCanvas;
    };
    this.Presentation.MessagePanel.prototype = $.extend(new this.Presentation.GraphElement(), {});

    this.Presentation.TooltipLayer = function() {
        this.canvas = mainGraph._tooltipCanvas;

        var me = this;

        var _addEventHandler = function() {
            target.mousemove(_onMouseMove);
            target.mouseout(_onMouseLeave);
        };
        var _initializeEx = function() {
            mainGraph._tooltipFactory.setActiveRegion({
                x: 0,
                y: 0,
                width: me.getWidth(),
                height: me.getHeight()
            });
        };
        var _onMouseLeave = function(e) {
            me._hideTip(e);
        };
        var _onMouseMove = function(e) {
            var pt = $.getPosition(me.canvas, e);

            var regionId = null;
            var values = mainGraph._regionCoordinate.values();
            for (var i = 0; i < values.length; i++) {
                for (var j = 0; j < values[i].length; j++) {
                    var arr = values[i][j];
                    if (Chart.Common.Graphic.GraphicUtil.inPolygon(arr, arr.length, pt)) {
                        regionId = mainGraph._regionCoordinate.keys()[i];
                        break;
                    }
                }
            }


            if (regionId) {
                var regionData = mainGraph._datasource.getRegionData();
                var data = regionData.tryGetValue(regionId, null);
                var msg = regionId.name;
                if (data) {

                    var dataLabel = StrFormatter.getFormattedLabel(regionId.code, data.label);
                    if (data.value && data.label) {
                        msg = String.format("{0}: {1}%", dataLabel, LocalizationManager.instance.formatDecimal(data.value, 2));
                    }
                    else {
                        if (data.value) {
                            msg = String.format("{0}%", LocalizationManager.instance.formatDecimal(data.value, 2));
                        }
                        else
                            if (data.label) {
                            msg = dataLabel;
                        }
                    }
                }
                if (msg) {
                    me._showTip(msg, e);
                    return;
                }
            }

            me._hideTip(e);

        };
        _addEventHandler();
        _initializeEx();
    };
    this.Presentation.TooltipLayer.prototype = $.extend(new this.Presentation.GraphElement(), {
        resizeComponents: function(width, height) {
            mainGraph._tooltipFactory.setActiveRegion({
                x: 0,
                y: 0,
                width: width,
                height: height
            });
        },
        reset: function() {
            this._hideTip(null);
        },
        _showTip: function(context, e) {
            if (!mainGraph._tooltip) {
                mainGraph._tooltip = mainGraph._tooltipFactory.create();
            }
            mainGraph._tooltip.setContent([context]);
            mainGraph._tooltip.popupAt($.getPosition(target.get(0), e));
        },
        _hideTip: function(e) {
            if (mainGraph._tooltip) {
                mainGraph._tooltip.hide();
            }
        }
    });

    this.Presentation.PresentationManager = function() {
        this._legendArea = null;
        this._graphArea = null;
        this._messagePanel = null;
        this._tooltipLayer = null;
        this.canvas = mainGraph._placeHolder.get(0);

        var me = this;

        var createElement = function() {
            var totalSize = {
                width: mainGraph._placeHolder.width(),
                height: mainGraph._placeHolder.height()
            };
            var graphSize = {
                width: totalSize.width - mainGraph._margin.left - mainGraph._margin.right,
                height: totalSize.height - mainGraph._margin.top - mainGraph._margin.bottom
            };
            mainGraph._headerCanvas = $.Canvas.createDiv(mainGraph._placeHolder, "absolute", 0, 0, graphSize.width, mainGraph._margin.top);
            mainGraph._graphCanvas = $.Canvas.create(mainGraph._placeHolder, "absolute", 0, mainGraph._margin.top, graphSize.width, graphSize.height);
            mainGraph._legendCanvas = $.Canvas.createDiv(mainGraph._placeHolder, "absolute", 0, mainGraph._margin.top + graphSize.height, graphSize.width, mainGraph._margin.bottom);
            mainGraph._tooltipCanvas = $.Canvas.createDiv(mainGraph._placeHolder, "absolute", mainGraph._margin.left, mainGraph._margin.top, graphSize.width, graphSize.height);
            //mainGraph._messageCanvas = $.Canvas.create(mainGraph._placeHolder, "absolute", 0, 0, canvasWidth, canvasHeight);

            //$(mainGraph._headerCanvas).css({"background-color":"#CCCCCC"});
            //$(mainGraph._graphCanvas).css({"background-color":"#FF0000"});
            //$(mainGraph._legendCanvas).css({"background-color":"#EEEEEE"});
        };

        createElement();
    };
    this.Presentation.PresentationManager.prototype = $.extend(new Chart.Common.Command.CommandHandler(), new this.Presentation.GraphElement(), {
        initailizeCoordinateMapping: function() {

        },
        applySetting: function(setting) {
            if (setting && setting.chart && setting.chart.option && setting.chart.option.displaystyle != null) {
                mainGraph._displayStyle = setting.chart.option.displaystyle;
            }
            var bgSetting = {};
            if (Chart.Setting.Presentation.BG.tryDeSerialize(setting, Chart.Setting.SettingItem.Chart, bgSetting)) {
                mainGraph._placeHolder.css({
                    "background-color": bgSetting.color
                });
            }
            this._legendArea.applySetting(setting);
            this._graphArea.applySetting(setting);
            this._tooltipLayer.applySetting(setting);
        },
        refresh: function() {
            var me = this;
            setTimeout(function() {
                me.initailizeCoordinateMapping();
                me._legendArea.refresh();
                me._graphArea.refresh();
                //me._tooltipLayer.refresh();
            }, 10);
        },
        clearAll: function() {
            //this._legendArea.reset();
            this._graphArea.reset();
            this._tooltipLayer.reset();
            //this._messagePanel.onClearAll();
        },
        resizeComponents: function(width, height) {
            $(mainGraph._legendCanvas).css({
                top: height - mainGraph._margin.bottom
            });
            this._legendArea.resize(width - mainGraph._margin.left - mainGraph._margin.right, mainGraph._margin.bottom);
            this._graphArea.resize(width - mainGraph._margin.left - mainGraph._margin.right, height - mainGraph._margin.top - mainGraph._margin.bottom);
            this._tooltipLayer.resize(width - mainGraph._margin.left - mainGraph._margin.right, height - mainGraph._margin.top - mainGraph._margin.bottom);
        },
        getHandler: function(args) {
            switch (args.command) {
                case Chart.Common.Command.Commands.APPLY_CHART_SETTING:
                    return this._onApplyChartSetting;
                case Chart.Common.Command.Commands.REFRESH_PRESENTATION:
                    return this.onRefreshPresentation;
                case Chart.Common.Command.Commands.RESIZE:
                    return this.onResize;
                case Chart.Common.Command.Commands.INITIALIZE:
                    return this.onInitialize;
                case Chart.Common.Command.Commands.COMPONENT_STATUS_UPDATE:
                    return this.onComponentStatusUpdate;
                case Chart.Common.Command.Commands.SET_CULTURE:
                    return this.onSetCulture;
                default:
                    return null;
            }
        },
        _onApplyChartSetting: function(args) {
            if (args && args.data && args.data.setting) {
                this.applySetting(args.data.setting);
                //this.refresh();
            }
        },
        onSetCulture: function(args) {
            if (args) {
                this.refresh();
            }
        },
        onInitialize: function(args) {
            this._legendArea = new mainGraph.Presentation.LegendArea();
            this._graphArea = new mainGraph.Presentation.GraphArea();
            //this._messagePanel = new mainGraph.Presentation.MessagePanel();
            this._tooltipLayer = new mainGraph.Presentation.TooltipLayer();
        },
        onRefreshPresentation: function(args) {
            this.refresh();
        },
        onResize: function(args) {
            if (args && args.data && args.data.width && args.data.height) {
                this.resize(args.data.width, args.data.height);
            }
            this.refresh();
        },
        onComponentStatusUpdate: function(args) {
            if (args && args.data && args.data.status) {
                switch (args.data.status) {
                    case Chart.Common.Command.ComponentStatus.ClearAll:
                        this.clearAll();
                        break;
                    default:
                        break;
                }
            }
        }
    });

    var initializeEx = function() {
        mainGraph._presentation = new mainGraph.Presentation.PresentationManager();
    };

    initializeEx();
};
Chart.Component.WorldRegionGraph.prototype = $.extend(new Chart.Common.Command.CommandHandler(), {
    defaultHandler: function(args){
        //do nothing here.
    },
    getHandler: function(args){
        return this.defaultHandler;
    },
    collectionChildren: function(){
        this.interactiveChildren = [this._presentation];
    },
    setDataSource: function(datasource){
        this._datasource = datasource;
    },
	setDisplayStyle: function(style){
		this._displayStyle = style;
	},
    resize: function(width, height){
        this._presentation.resize(width, height);
        this._presentation.refresh();
    }
});

