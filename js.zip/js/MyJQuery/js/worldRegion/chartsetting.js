Chart.Setting = function(){
};

Chart.Setting.SettingItem = {
	Chart: "chart",
	ToolTip: "tooltip"
};

Chart.Setting.Presentation = function(){
};

Chart.Setting.Presentation.BG = function(){
};
Chart.Setting.Presentation.BG.deSerialize = function(setting, key){
	if(!setting || 
		!setting.presentation || 
		!setting.presentation.background || 
		setting.presentation.background.length<=0){
		return false;
	}
	
	var len = setting.presentation.background.length, item = null;
	for (var i = 0; i < len; i++) {
		item = setting.presentation.background[i];
		if(item.type && item.type == key){
			var bgSetting = {};
			bgSetting.color = $.color.parse(item.color).toString();
			return bgSetting;
		}
	}
	
	return null;
};
Chart.Setting.Presentation.BG.tryDeSerialize = function(setting, key, bgSetting){
	if(!setting || 
		!setting.presentation || 
		!setting.presentation.background || 
		setting.presentation.background.length<=0){
		return false;
	}
	
	var len = setting.presentation.background.length, item = null;
	for (var i = 0; i < len; i++) {
		item = setting.presentation.background[i];
		if(item.type && item.type == key){
			bgSetting.color = $.color.parse(item.color).toString();
			return true;
		}
	}
	
	return false;
};
Chart.Setting.Presentation.BG.serialize = function(setting, key, bgSetting){
	if (setting) {
		if (!setting.presentation) {
			setting.presentation = {};
		}
		if (!setting.presentation.background) {
			setting.presentation.background = [];
		}
		
		var len = setting.presentation.background.length, temp = null, target = null;
		for (var i = 0; i < len; i++) {
			temp = setting.presentation.background[i];
			if (temp.type && temp.type == key) {
				target = temp;
				break;
			}
		}
		if (!target) {
			target = {};
			setting.presentation.background.push(target);
		}
		
		target.type = key;
		target.color = $.color.parse(bgSetting.color).toString();
	}
};

Chart.Setting.Presentation.Coordinate = function(){
};
Chart.Setting.Presentation.Coordinate.deSerializeXAxisSuffix = function(setting){
	if(!setting || 
		!setting.presentation || 
		!setting.presentation.coordinate ||
		typeof(setting.presentation.coordinate.xsuffix) == "undefined"){
		return null;
	}
	
    return setting.presentation.coordinate.xsuffix;
};
Chart.Setting.Presentation.Coordinate.deSerializeYAxisSuffix = function(setting){
	if(!setting || 
		!setting.presentation || 
		!setting.presentation.coordinate ||
		typeof(setting.presentation.coordinate.ysuffix) == "undefined"){
		return null;
	}
	
    return setting.presentation.coordinate.ysuffix;
};
Chart.Setting.Presentation.Coordinate.tryDeSerializeShowXLine = function(setting, showXLine){
	if(!setting || 
		!setting.presentation || 
		!setting.presentation.coordinate ||
		typeof(setting.presentation.coordinate.showxline) == "undefined"){
		return false;
	}

	
};
Chart.Setting.Presentation.Coordinate.tryDeSerializeShowYLine = function(setting, showYLine){
	if(!setting || 
		!setting.presentation || 
		!setting.presentation.coordinate ||
		typeof(setting.presentation.coordinate.showyline) == "undefined"){
		return false;
	}
	
	
};
Chart.Setting.Presentation.Coordinate.serializeShowXLine = function(setting, showXLine){
	if (setting) {
		if (!setting.presentation) {
			setting.presentation = {};
		}
		if (!setting.presentation.coordinate) {
			setting.presentation.coordinate = {};
		}
		
		setting.presentation.coordinate.showxline = showXLine;
	}
};
Chart.Setting.Presentation.Coordinate.serializeShowYLine = function(setting, showYLine){
	if (setting) {
		if (!setting.presentation) {
			setting.presentation = {};
		}
		if (!setting.presentation.coordinate) {
			setting.presentation.coordinate = {};
		}
		
		setting.presentation.coordinate.showyline = showYLine;
	}
};
Chart.Setting.Presentation.Coordinate.serializeXAxisSuffix = function(setting, suffix){
	if (setting) {
		if (!setting.presentation) {
			setting.presentation = {};
		}
		if (!setting.presentation.coordinate) {
			setting.presentation.coordinate = {};
		}
		
		setting.presentation.coordinate.xsuffix = suffix;
	}
};
Chart.Setting.Presentation.Coordinate.serializeYAxisSuffix = function(setting, suffix){
	if (setting) {
		if (!setting.presentation) {
			setting.presentation = {};
		}
		if (!setting.presentation.coordinate) {
			setting.presentation.coordinate = {};
		}
		
		setting.presentation.coordinate.ysuffix = suffix;
	}
};

Chart.Setting.Presentation.NumSetting = function(){
	this.unit = "";
	this.decimalCount = 2;
	this.shortened = false;
};
Chart.Setting.Presentation.NumSetting.tryDeSerialize = function(setting, key, numSetting){
	if(!setting || 
		!setting.presentation || 
		!setting.presentation.format || 
		!setting.presentation.format.number || 
		setting.presentation.format.number.length<=0){
		return false;
	}
	
	var len = setting.presentation.format.number.length, item = null;
	for (var i = 0; i < len; i++) {
		item = setting.presentation.format.number[i];
		if (item.type && item.type == key) {
			numSetting.unit = !$.isNull(item.unit) ? item.unit : "";
			numSetting.decimalCount = !$.isNull(item.decimalcount) ? item.decimalcount : 0;
			numSetting.shortened = !$.isNull(item.shortened) ? item.shortened : false;
			return true;
		}
	}
	
	return false;
};
Chart.Setting.Presentation.NumSetting.serialize = function(setting, key, numSetting){
	if (setting) {
		if (!setting.presentation) {
			setting.presentation = {};
		}
		if (!setting.presentation.format) {
			setting.presentation.format = {};
		}
		if (!setting.presentation.format.number) {
			setting.presentation.format.number = [];
		}
		
		var len = setting.presentation.format.number.length, temp = null, target = null;
		for (var i = 0; i < len; i++) {
			temp = setting.presentation.format.number[i];
			if (temp.type && temp.type == key) {
				target = temp;
				break;
			}
		}
		if (!target) {
			target = {};
			setting.presentation.format.number.push(target);
		}
		
		target.type = key;
		target.unit = !$.isNull(numSetting.unit) ? numSetting.unit : "";
		target.decimalcount = !$.isNull(numSetting.decimalCount) && numSetting.decimalCount >= 0 ? numSetting.decimalCount : 0;
		target.shortened = !$.isNull(numSetting.shortened) ? numSetting.shortened : false;
	}
};
