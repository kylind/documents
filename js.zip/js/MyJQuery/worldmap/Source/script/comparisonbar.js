Chart.ComparisonBarChart = function(containerDOM){
	this.cId = +new Date();	
	this.container = containerDOM;
	
	this.dataSource = null;
	this.graph = null;
	
	this.graphCanvas = null;
	this.floatCanvas = null;
	
	this.canvasWidth = 0;
	this.canvasHeight = 0;
	
	if (containerDOM) {
		this._initialize();
	}
	return this;
};
Chart.ComparisonBarChart.prototype = $.extend(new Chart.Common.Graphic.GraphElement(), {
	/*
	 * override
	 */
	resizeComponents: function(width, height){
		this.canvasWidth = width;
		this.canvasHeight = height;
		
		this.graphCanvas.css({
			width: width,
			height: height
		});
		
		this.graph.resize(width, height);
	},
	/*
	 * override
	 */
	refresh: function(){
		var me = this;
		this.dataSource.refresh(function(){
			me.dataSource.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.REFRESH_PRESENTATION, null));
		});
	},
	/*
	 * interface for push data mode
	 * @param jsonStr {string} data string, in JSON format.
	 * @return null;
	 */
	setData: function(jsonStr){
		this.dataSource.setData(jsonStr);
	},
	/*
	 * another interface for push data mode, call refresh directly.
	 */
	draw: function(){
		this.dataSource.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.REFRESH_PRESENTATION, null));
	},
	setCulture: function(cultureName){
		var me = this;
		LocalizationManager.instance.setCurrentCulture(cultureName, function(){
			me.dataSource.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.SET_CULTURE, null));
		});
	},
	_initialize: function(){
		this.canvas = this.container.get(0);
		this.canvasWidth = this.container.width();
		this.canvasHeight = this.container.height();
		
		this._createElements();
		this._createComponents();
	},
	_createComponents: function(){
		this.dataSource = new Chart.Component.ComparisonBarData();
		this.graph = new Chart.Component.ComparisonBarGraph(this.graphCanvas);
		this.graph.setDataSource(this.dataSource);
		this.graph.collectionChildren();
		
		this.dataSource.collectionChildren();
		this.dataSource.addChild(this.graph);
		this.dataSource.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.INITIALIZE, null));
	},
	_createElements: function(){
		this.container.attr({
			"cid": this.cId
		});
		this.container.addClass("comparisonbar");
		this.graphCanvas = $($.Canvas.createDiv(this.container, "relative", 0, 0, this.canvasWidth, this.canvasHeight)).attr({
			"cid": this.cId
		});
		/*
		this.floatCanvas = $($.Canvas.createDiv(this.container, "absolute", 0, 0, 0, 0)).attr({
			"id": "phTip" + this.cId,
			"cid": this.cId
		});
		*/
		this.floatCanvas = $("<div></div>").appendTo(this.container).attr({
			"id": "phTip" + this.cId,
			"cid": this.cId
		});
	}
});

Chart.Interface.ComparisonBarChartInterface = function(){
};
Chart.Interface.ComparisonBarChartInterface.prototype = {
    /*
     * get investment group data dictionary.
     * @param none
     * @return {Dictionary<string, Pair<double>>} {first: weight, second: ytd}
     */
    getInvGroupData: function(){
        return null;
    },
	/*
	 * get investment group name by id
	 * @param invGroupId {string}
	 * @return {string}
	 */
	getInvGroupName: function(invGroupId){
		return "";		
	},
	/*
	 * get context that will display in tooltip
	 * @param invGroupId {string}
	 * @return {[string, string,...,string]}
	 */
	getFloatingTipContext: function(invGroupId, type, index){
		return null;
	}
};

Chart.Component.ComparisonBarData = function(){
	var today = new Date();
	today = new Date(today.getFullYear(), today.getMonth(), today.getDate());
	this._rawData = new Dictionary();
	this._investmentGroupInfo = new Dictionary();
	
	var me = this;
	
	this._rawData.add("group1",{bars: [24], index: 47, cat:33, color: "#66B502", ocolor: "#E7E7E7"});
	this._rawData.add("group2",{bars: [44.88], index: 10, cat:40.88, color: "#28366D", ocolor: "#E7E7E7"});
	this._rawData.add("group3",{bars: [18.15], index: 12.15, cat:6, color: "#A20126", ocolor: "#E7E7E7"});
	this._rawData.add("group4",{bars: [55.5], index: 5, cat:12.5, color: "#F36615", ocolor: "#E7E7E7"});
	this._rawData.add("group5",{bars: [10], index: 20, cat:30, color: "#7B95B9", ocolor: "#E7E7E7"});
	
	//this._investmentGroupInfo.add("group1", {name: "Cash"});
	//this._investmentGroupInfo.add("group2", {name: "U.S. Stocks"});
	//this._investmentGroupInfo.add("group3", {name: "Non U.S. Stocks"});
	//this._investmentGroupInfo.add("group4", {name: "Bond"});
	//this._investmentGroupInfo.add("group5", {name: "Other"});
};
Chart.Component.ComparisonBarData.prototype = $.extend(new Chart.Common.Command.CommandHandler(), new Chart.Interface.ComparisonBarChartInterface(),{
	/*
	 * set data and option
	 * @param {string} in JSON format.
	 */
	setData: function(jsonStr){
		var d = +new Date();
       
		this.reset();
		
		var data = $.evalJSON(jsonStr);
		if (!data) {
			return;
		}
		
		if (data.Bars && data.Bars.length > 0) {
			var len = data.Bars.length;
			var groupId = "", group = null, temp = null;
			for (var i = 0; i < len; i++) {
				groupId = "group" + i.toString();
				group = data.Bars[i];
				temp = {
					bars: [group.V ? group.V : 0],
					index: group.VInd ? group.VInd : 0,
					cat: group.VCat ? group.VCat : 0,
					color: group.Color ? group.Color : "#FFFFFF",
					ocolor: group.OWColor ? group.OWColor : "#FFFFFF",
					icolor: group.IndColor ? group.IndColor : "",
					ccolor: group.CatColor ? group.CatColor : ""
				};
				this._rawData.add(groupId, temp);
			}
		}
		
		//parse chart setting.
		var setting = {
			chart: {
				option: {}
			}
		};
		
		if (data.Height && parseFloat(data.Height)) {
			setting.chart.option.barheight = parseFloat(data.Height);
		}
		
		if (data.BarMargin && parseFloat(data.BarMargin)) {
			setting.chart.option.barmargin = parseFloat(data.BarMargin);
		}
		
		if (data.HeightInd && parseFloat(data.HeightInd)) {
			setting.chart.option.indexindicatorheight = parseFloat(data.HeightInd);
		}
		
		if (data.WidthInd && parseFloat(data.WidthInd)) {
			setting.chart.option.indexindicatorwidth = parseFloat(data.WidthInd);
		}
		
		if (data.HeightCat && parseFloat(data.HeightCat)) {
			setting.chart.option.catindicatorheight = parseFloat(data.HeightCat);
		}
		//Indicator
		
		if (data.TickLength && parseFloat(data.TickLength) && parseFloat(data.TickLength) > 0) {
			setting.chart.option.scalarlength = parseFloat(data.TickLength);
		}
		
		if (data.Maximum && parseFloat(data.Maximum) && parseFloat(data.Maximum)>0) {
			setting.chart.option.minvalue = 0;
			setting.chart.option.maxvalue = parseFloat(data.Maximum);
		}
		
		if (data.BGColor) {
			Chart.Setting.Presentation.BG.serialize(setting, Chart.Setting.SettingItem.Chart, {
				color: data.BGColor
			});
		}
		
		this.executeCommand(
			new Chart.Common.Command.CommandArgs(
				null, 
				Chart.Common.Command.Commands.APPLY_CHART_SETTING, 
				{setting:setting}));
		
		ChartLogger.instance.write("[time-consuming] time consuming of set data interface: " + (new Date() - d));
	},
	/*
	 * hook function
	 */
	refresh: function(callback){
		if(callback && typeof(callback)== "function"){
			callback();
		}
	},
	/*
	 * clear all cache data.
	 */
	reset: function(){
		this._rawData.clear();
		this._investmentGroupInfo.clear();
	},
	/*
     * override. filter commands.
     * @param arg {Chart.Common.Command.CommandArgs} content.
     * @return the handler event of target command.
     */
	getHandler: function(args){
		switch (args.command) {
			case Chart.Common.Command.Commands.ADD_INVESTMENT:
			case Chart.Common.Command.Commands.DELETE_ITEM:
			case Chart.Common.Command.Commands.REFRESH_PRESENTATION:
			case Chart.Common.Command.Commands.RESIZE:
			case Chart.Common.Command.Commands.INITIALIZE:
			case Chart.Common.Command.Commands.COMPONENT_STATUS_UPDATE:
				return this.defaultHandler;
			default:
				return this.defaultHandler;
		}
		return this.defaultHandler;
	},
	/*
     * default command handler, the purpose of this is the enable all commmand will be passed to children.
     * @param arg {Chart.Common.Command.CommandArgs} content.
     * @return null.
     */
	defaultHandler: function(args){
		//do nothing here.
	},
	/*
     * get investment group data dictionary.
     * @param none
     * @return {Dictionary<string, Pair<double>>} {first: weight, second: ytd}
     */
    getInvGroupData: function(){
        return this._rawData;
    },
	/*
	 * get investment group name by id
	 * @param invGroupId {string}
	 * @return {string}
	 */
	getInvGroupName: function(invGroupId){
		var info = this._investmentGroupInfo.tryGetValue(invGroupId, null);
		return info && info.name ? info.name : "";
	},
	/*
	 * get context that will display in tooltip
	 * @param invGroupId {string}
	 * @return {[string, string,...,string]}
	 */
	getFloatingTipContext: function(invGroupId, type, index){
		var ret = [], 
			data = this._rawData.tryGetValue(invGroupId,null);
		if (data) {
			if (type == 0) {
				if (data.bars && data.bars.length > index) {
					ret.push(String.format("{0}: {1}%",LocalizationManager.instance.getLabel('fund',"Fund"), LocalizationManager.instance.formatDecimal(data.bars[index], 2)));
				}
			}
			else if(type == 1){
				ret.push(String.format("{0}: {1}%",LocalizationManager.instance.getLabel('index',"Index"), LocalizationManager.instance.formatDecimal(data.index, 2)));
			}
			else if(type == 2){
				ret.push(String.format("{0}: {1}%",LocalizationManager.instance.getLabel('category',"Category"), LocalizationManager.instance.formatDecimal(data.cat, 2)));
			}
		}
		return ret;
	}
});

Chart.Component.ComparisonBarGraph = function(target){
    this._placeHolder = target;
    this._placeHolder.css({
        "position": "relative",
        "background-color": "transparent",
        "cursor": "default"
    });
    this._margin = {
        left: 0,
        top: 0,
        right: 0,
        bottom: 0
    };
	this.IND_HEIGHT = 5;
	this.FOOTER_HEIGHT = 24;
	
	this._groupBar = {
		margin: 3,
		height: 8,
		scalar: 0
	};
	this._indexBar = {
		height: 16,
		width: 4
	};
	this._valRange = {
		min: 0,
		max: 50
	};
		
	this._barInfo = [];
    this._datasource = null;
    this._tooltipFactory = new Chart.Common.Controls.BasicTipFactory(target.attr("cid"));
	this._tooltip = null;
    
	this._coordinateCanvas = null;
    this._graphCanvas = null;
    this._tooltipCanvas = null;
    this._messageCanvas = null;
	
	this.xAxisMapping = new Chart.Common.Coordinate.Double2DoubleLinearMapping();
    this.yAxisMapping = new Chart.Common.Coordinate.Double2DoubleLinearMapping();
    
    var mainGraph = this;
    
    this.Presentation = function(){
    };
    
    this.Presentation.GraphElement = function(){
    };
    this.Presentation.GraphElement.prototype = $.extend(new Chart.Common.Graphic.GraphElement(), {});
        
	this.Presentation.CoordinateArea = function(){
		this.canvas = mainGraph._coordinateCanvas;
		this.canvasRef = $(this.canvas);
		this.ctx = null;
		this._graphics = null;
		this.lineLayer = null;
		this.labelLayer = null;
		this.labelRef = null;
		
		this.LABEL_OFFSET = 4;
		this.GRIDLINE_EX = 6;
		this.SCALAR_UNIT = 10;
		
		this._strokeThickness = 1;
        this._strokeColor = "#CCCCCC";
		//this._backgroudColor = "#FDFDFD";
		
		this._numberSetting = { decimalCount: 2, shortened: true };
		
		var me = this;
		
		var _createElement = function(){
			var graphSize = {
				width: me.getWidth(),
				height: me.getHeight()
			};
			//me.canvasRef.css({"background-color": $.color.parse(me._backgroudColor).toString()});
			me.lineLayer = $.Canvas.create(me.canvasRef, "absolute", 0, 0, graphSize.width, graphSize.height);
			me.labelLayer = $.Canvas.createDiv(me.canvasRef, "absolute", 0, 0, graphSize.width, graphSize.height);
			me.labelRef = $(me.labelLayer);
			me.ctx = me.lineLayer.getContext("2d");
			me._graphics = new $.Graphics(me.ctx);
		};
		
		_createElement();
	};
    this.Presentation.CoordinateArea.prototype = $.extend(new this.Presentation.GraphElement(), {
        applySetting: function(setting){
			if (setting && setting.chart && setting.chart.option) {
				if (setting.chart.option.scalarlength && parseFloat(setting.chart.option.scalarlength)) {
					this.SCALAR_UNIT = parseFloat(setting.chart.option.scalarlength);
				}
			}
		},
		getRange: function(xrange, yrange){
		},
        resizeComponents: function(width, height){
            this.lineLayer.width = width;
            this.lineLayer.height = height;
			this.labelLayer.width = width;
            this.labelLayer.height = height;
            $(this.lineLayer).css({
                width: width,
                height: height
            });
            $(this.labelLayer).css({
                width: width,
                height: height
            });
        },
        refresh: function(){
            var d = +new Date();
            this._drawCoordinate();
            ChartLogger.instance.write("[time-consuming] time consuming of drawing coordinate area: " + (new Date() - d));
        },
        reset: function(){
            this.ctx.clearRect(0, 0, this.getWidth(), this.getHeight());
            $(this.labelLayer).html("");
        },
        _drawCoordinate: function(){
			this.reset();
			this._drawXMarks();
			this._drawYMarks();
		},
		_drawYMarks: function(){
			var mapping = mainGraph.yAxisMapping;
			var valueRange = mapping.getValueRange();
			var totalRange = valueRange.second - valueRange.first;
			var yValueSpace = totalRange / mainGraph._groupBar.scalar;
			
			this._graphics.begin();
			this._graphics.setLineStyle(this._strokeThickness, this._strokeColor);
			
			var adjust = this._strokeThickness % 2 == 1 ? 0.5 : 0;
			var currentValue = valueRange.first;
			var y = Math.floor(mapping.getCoordinate(currentValue)) + adjust;
			var lineLength = this.getWidth();
			this._graphics.drawLine(0, y, lineLength, y);
			
			for (var i = 0; i < mainGraph._groupBar.scalar; i++) {
				currentValue = currentValue + yValueSpace;
				if (Math.abs(currentValue) < 0.000001) {
					currentValue = 0;
				}
				
				y = Math.floor(mapping.getCoordinate(currentValue)) + adjust;
				this._graphics.drawLine(0, y, lineLength, y);
			}
			this._graphics.end();
		},
		_drawXMarks: function(){
			function _adjustLabel(labelRef, val, currentPos){
				if (Math.abs(val - valueRange.first) < 0.000001) {
					return;
				}
				if (Math.abs(val - valueRange.second) < 0.000001) {
					labelRef.css({
						left: currentPos - labelRef.width()
					});
					return
				}
				labelRef.css({
					left: currentPos - labelRef.width() / 2
				});
			}
			
			var mapping = mainGraph.xAxisMapping;
			var coordinateRange = mainGraph.yAxisMapping.getCoordinateRange();
			var valueRange = mapping.getValueRange();
			var totalRange = valueRange.second - valueRange.first;
			//var valueSpace = totalRange / this.SCALAR_UNIT;
			
			this._graphics.begin();
			this._graphics.setLineStyle(this._strokeThickness, this._strokeColor);
			
			var adjust = this._strokeThickness % 2 == 1 ? 0.5 : 0;
			var currentValue = 0;
			var x = Math.floor(mapping.getCoordinate(currentValue)) + adjust;
			var y1 = coordinateRange.second, y2 = y1 + this.GRIDLINE_EX;
			this._graphics.drawVDotLine(x, coordinateRange.first, y1, 1, 2);
			this._graphics.drawLine(x, y1, x, y2);
			var text = StrFormatter.getFormattedNumString(currentValue, totalRange, this._numberSetting.decimalCount, this._numberSetting.shortened);
			var textbox = $($.TextStudio.create(text, this.labelRef, "absolute", x, y2 + this.LABEL_OFFSET, null, null, "coordinate"));
			_adjustLabel(textbox, currentValue, x);
			
			currentValue = this.SCALAR_UNIT;
			while (currentValue <= valueRange.second) {
				x = Math.floor(mapping.getCoordinate(currentValue)) + adjust;
				this._graphics.drawVDotLine(x, coordinateRange.first, y1, 1, 2);
				this._graphics.drawLine(x, y1, x, y2);
				
				text = StrFormatter.getFormattedNumString(currentValue, totalRange, this._numberSetting.decimalCount, this._numberSetting.shortened);
				textbox = $($.TextStudio.create(text, this.labelRef, "absolute", x, y2 + this.LABEL_OFFSET, null, null, "coordinate"));
				_adjustLabel(textbox, currentValue, x);
				
				currentValue += this.SCALAR_UNIT;
			}
			currentValue = -this.SCALAR_UNIT;
			while (currentValue >= valueRange.first) {
				x = Math.floor(mapping.getCoordinate(currentValue)) + adjust;
				this._graphics.drawVDotLine(x, coordinateRange.first, y1, 1, 2);
				this._graphics.drawLine(x, y1, x, y2);
				
				text = StrFormatter.getFormattedNumString(currentValue, totalRange, this._numberSetting.decimalCount, this._numberSetting.shortened);
				textbox = $($.TextStudio.create(text, this.labelRef, "absolute", x, y2 + this.LABEL_OFFSET, null, null, "coordinate"));
				_adjustLabel(textbox, currentValue, x);
				
				currentValue -= this.SCALAR_UNIT;
			}
			this._graphics.end();
		}
    });
	
    this.Presentation.GraphArea = function(){
        this.canvas = mainGraph._graphCanvas;
        this.ctx = this.canvas.getContext("2d");
        this._graphics = new $.Graphics(this.ctx);
    };
    this.Presentation.GraphArea.prototype = $.extend(new this.Presentation.GraphElement(), {
        applySetting: function(setting){
			if (setting && setting.chart && setting.chart.option) {
				//value range
				if (setting.chart.option.minvalue != null && parseFloat(setting.chart.option.minvalue) != NaN) {
					mainGraph._valRange.min = parseFloat(setting.chart.option.minvalue);
				}
				if (setting.chart.option.maxvalue != null && parseFloat(setting.chart.option.maxvalue) != NaN) {
					mainGraph._valRange.max = parseFloat(setting.chart.option.maxvalue);
				}
				
				//graph parameters
				if (setting.chart.option.barheight && parseFloat(setting.chart.option.barheight)) {
					mainGraph._groupBar.height = parseFloat(setting.chart.option.barheight);
				}
				if (setting.chart.option.barmargin && parseFloat(setting.chart.option.barmargin)) {
					mainGraph._groupBar.margin = parseFloat(setting.chart.option.barmargin);
				}
				if (setting.chart.option.indexindicatorheight && parseFloat(setting.chart.option.indexindicatorheight)) {
					mainGraph._indexBar.height = parseFloat(setting.chart.option.indexindicatorheight);
				}
				if (setting.chart.option.indexindicatorwidth && parseFloat(setting.chart.option.indexindicatorwidth)) {
					mainGraph._indexBar.width = parseFloat(setting.chart.option.indexindicatorwidth);
				}
				if (setting.chart.option.catindicatorheight && parseFloat(setting.chart.option.catindicatorheight)) {
					mainGraph.IND_HEIGHT = parseFloat(setting.chart.option.catindicatorheight);
				}
			}
		},
		getRange: function(xrange, yrange){
			if (!mainGraph._datasource || !mainGraph._datasource.getInvGroupData) 
				return;
			var currentData = mainGraph._datasource.getInvGroupData();
			if (!currentData || currentData.count <= 0) 
				return;
			
			var scalar = currentData.count, 
				maxScalar = Math.floor(this.getHeight() / (Math.max(mainGraph._groupBar.height,mainGraph._indexBar.height) + mainGraph._groupBar.margin * 2));
			scalar = scalar > maxScalar ? maxScalar : scalar;
			mainGraph._groupBar.scalar = scalar;
			
			xrange.first = mainGraph._valRange.min;
			xrange.second = mainGraph._valRange.max;
			yrange.first = 0.5;
			yrange.second = scalar + 0.5;
		},
		resizeComponents: function(width, height){
        },
        refresh: function(){
            var d = +new Date();
            this._drawAreaGraph();
            ChartLogger.instance.write("[time-consuming] time consuming of drawing graph area: " + (new Date() - d));
        },
        reset: function(){
            this.ctx.clearRect(0, 0, this.getWidth(), this.getHeight());
			mainGraph._barInfo=[];
        },
        _drawAreaGraph: function(){
			this.reset();
			
			if (!mainGraph._datasource || !mainGraph._datasource.getInvGroupData) 
				return;
			var currentData = mainGraph._datasource.getInvGroupData();
			if (!currentData || currentData.count <= 0) 
				return;
			
			var keys = currentData.keys();
			var groups = currentData.values();
			var adjust = 0.5, 
				pos0 = Math.floor(mainGraph.xAxisMapping.getCoordinate(0)), 
				posmax = Math.floor(mainGraph.xAxisMapping.getCoordinate(mainGraph._valRange.max));
				posmin = Math.floor(mainGraph.xAxisMapping.getCoordinate(mainGraph._valRange.min));
				x = 0, y = 0, width = 0, pts = null;
			
			for (var i = 0; i < currentData.count; i++) {
				y = Math.ceil(mainGraph.yAxisMapping.getCoordinate(i + 1) - mainGraph._groupBar.height / 2);
				
				if (!groups[i].bars || groups[i].bars.length <= 0) {
					continue;
				}
				
				var overload = false;
				for (var j = 0; j < groups[i].bars.length; j++) {
					if (groups[i].bars[j] > mainGraph._valRange.max) {
						x = posmax;
						overload = true;
					}
					else 
						if (groups[i].bars[j] < mainGraph._valRange.min) {
							x = posmin;
							overload = true;
						}
						else {
							x = Math.floor(mainGraph.xAxisMapping.getCoordinate(groups[i].bars[j]));
							overload = false;
						}
					width = Math.abs(x - pos0);
					x = x > pos0 ? pos0 : x;
					mainGraph._barInfo.push({
						id: keys[i],
						type: 0,
						index: j,
						points: [{
							x: x,
							y: y
						}, {
							x: x + width,
							y: y
						}, {
							x: x + width,
							y: y + mainGraph._groupBar.height
						}, {
							x: x,
							y: y + mainGraph._groupBar.height
						}]
					});
					
					if (overload) {
						this._graphics.begin();
						this._graphics.setNormalFill(groups[i].ocolor);
						this._graphics.setLineStyle(1, groups[i].color);
						this._graphics.drawRectangle(x + adjust, y + adjust, width, mainGraph._groupBar.height);
						this._graphics.end();
					}
					else {
						this._graphics.begin();
						this._graphics.setLineStyle(0);
						this._graphics.setNormalFill(groups[i].color);
						this._graphics.drawRectangle(x, y, width, mainGraph._groupBar.height);
						this._graphics.end();
					}
				}
				
				//index
				y1 =  y-(mainGraph._indexBar.height - mainGraph._groupBar.height) / 2;
				x = Math.floor(mainGraph.xAxisMapping.getCoordinate(groups[i].index) - mainGraph._indexBar.width / 2) + adjust;
				mainGraph._barInfo.push({
					id: keys[i],
					type: 1,
					index: 0,
					points: [{
						x: x,
						y: y1
					}, {
						x: x + mainGraph._indexBar.width,
						y: y1
					}, {
						x: x + mainGraph._indexBar.width,
						y: y1 + mainGraph._indexBar.height
					}, {
						x: x,
						y: y1 + mainGraph._indexBar.height
					}]
				});
				
				this._graphics.begin();
				this._graphics.setNormalFill("#ffffff");
				this._graphics.setLineStyle(1, groups[i].icolor?groups[i].icolor: groups[i].color);
				this._graphics.drawRectangle(x, y1 + adjust, mainGraph._indexBar.width, mainGraph._indexBar.height);
				this._graphics.end();
				
				//category
				x = Math.floor(mainGraph.xAxisMapping.getCoordinate(groups[i].cat)) + adjust;
				pts = [{
					x: x,
					y: y
				}, {
					x: x - mainGraph.IND_HEIGHT,
					y: y - mainGraph.IND_HEIGHT
				}, {
					x: x + mainGraph.IND_HEIGHT,
					y: y - mainGraph.IND_HEIGHT
				}];
				mainGraph._barInfo.push({
					id: keys[i],
					type: 2,
					index: 0,
					points: pts
				});
				this._graphics.begin();
				this._graphics.setLineStyle(0);
				this._graphics.setNormalFill(groups[i].ccolor?groups[i].ccolor:groups[i].color);
				this._graphics.drawPolygon(pts);
				this._graphics.end();
			}
		}
    });
    
    this.Presentation.MessagePanel = function(){
        this.canvas = mainGraph._messageCanvas;
    };
    this.Presentation.MessagePanel.prototype = $.extend(new this.Presentation.GraphElement(), {});
    
    this.Presentation.TooltipLayer = function(){
		this.canvas = mainGraph._tooltipCanvas;
		this.highlightLayer = null;
		this.ctx = null;
        this._graphics = null;
		
		this._currentDatum = null;
		
		var me = this;
		
		var _addEventHandler = function(){
			//if (true) {
				target.mousemove(_onMouseMove);
				target.mouseout(_onMouseLeave);
			//}
		};
		var _onMouseLeave = function(e){
			me._hideTip(e);
		};
		var _onMouseMove = function(e){
			var pt = $.getPosition(me.canvas, e);
			
			var datum = _findDatum(pt);
			if (datum) {
				me._currentDatum = datum; 
					me._showTip(mainGraph._datasource.getFloatingTipContext(datum.id, datum.type,datum.index), e);
					return;
			}
			
			if (me._currentDatum) {
				me._hideTip(e);
				me._currentDatum = null;
			}
		};
		var _findDatum = function(pt){
			try {
				for(var i= mainGraph._barInfo.length-1;i>=0;i--){
					if (Chart.Common.Graphic.GraphicUtil.inPolygon(mainGraph._barInfo[i].points, mainGraph._barInfo[i].points.length, pt)) {
						return mainGraph._barInfo[i];
					}
				}
			} 
			catch (ex) {
			}
			
			return null;
		};
		var _pointInRect = function(pt, rect){
		    if(pt.x>= rect.x && pt.x <= rect.x+rect.width && pt.y >= rect.y && pt.y<=rect.y+rect.height){
		        return true;
		    }
		    return false;
		};
		var _createElement = function(){
			var graphSize = {
				width: me.getWidth(),
				height: me.getHeight()
			};
			me.highlightLayer = $.Canvas.create($(me.canvas), "absolute", 0, 0, graphSize.width, graphSize.height);
			me.ctx = me.highlightLayer.getContext("2d");
			me._graphics = new $.Graphics(me.ctx);
			
			mainGraph._tooltipFactory.setActiveRegion({
				x: 0,
				y: 0,
				width: graphSize.width,
				height: graphSize.height
			});
		};
		
		_createElement();
		_addEventHandler();
	};
    this.Presentation.TooltipLayer.prototype = $.extend(new this.Presentation.GraphElement(), {
		resizeComponents: function(width, height){
            this.highlightLayer.width = width;
            this.highlightLayer.height = height;
            $(this.highlightLayer).css({
                width: width,
                height: height
            });
			mainGraph._tooltipFactory.setActiveRegion({
				x: 0,
				y: 0,
				width: width,
				height: height
			});
        },
		reset: function(){
			this._hideTip(null);
		},
		_showTip: function(context, e){
			if (!mainGraph._tooltip) {
				mainGraph._tooltip = mainGraph._tooltipFactory.create();
			}
			if(context && context.length>0){
			    mainGraph._tooltip.setContent(context);
			    mainGraph._tooltip.popupAt($.getPosition(target.get(0), e));
			}
		},
		_hideTip: function(e){
			if (mainGraph._tooltip) {
				mainGraph._tooltip.hide();
			}
		}
	});
    
    this.Presentation.PresentationManager = function(){
        this._graphArea = null;
		this._coordinateArea = null;
        this._messagePanel = null;
        this._tooltipLayer = null;
        this.canvas = mainGraph._placeHolder.get(0);
        
        var me = this;
        
        var createElement = function(){
            var totalSize = {
                width: mainGraph._placeHolder.width() - mainGraph._margin.left - mainGraph._margin.right,
                height: mainGraph._placeHolder.height() - mainGraph._margin.top - mainGraph._margin.bottom
            };
            var graphSize = {
                width: totalSize.width,
                height: totalSize.height-mainGraph.FOOTER_HEIGHT
            };
			mainGraph._coordinateCanvas = $.Canvas.createDiv(mainGraph._placeHolder, "absolute", mainGraph._margin.left, mainGraph._margin.top, graphSize.width, totalSize.height);
			mainGraph._graphCanvas = $.Canvas.create(mainGraph._placeHolder, "absolute", mainGraph._margin.left, mainGraph._margin.top, graphSize.width, graphSize.height);
            mainGraph._tooltipCanvas = $.Canvas.createDiv(mainGraph._placeHolder, "absolute", mainGraph._margin.left, mainGraph._margin.top, graphSize.width, graphSize.height);
            //mainGraph._messageCanvas = $.Canvas.create(mainGraph._placeHolder, "absolute", 0, 0, canvasWidth, canvasHeight);
			
			//$(mainGraph._graphCanvas).css({"background-color":"#FF0000"});
        };
        
        createElement();
    };
    this.Presentation.PresentationManager.prototype = $.extend(new Chart.Common.Command.CommandHandler(), new this.Presentation.GraphElement(), {
        initailizeCoordinateMapping: function(){
			var xrange = {
				first: 0,
				second: 0
			};
			var yrange = {
				first: 0,
				second: 0
			};
			var xcoordinate = {
				first: 0,
				second: this._graphArea.getWidth() - 1
			};
			var ycoordinate = {
				first: 0,
				second: this._graphArea.getHeight() - 1
			};
			
			this._graphArea.getRange(xrange, yrange);
			this._coordinateArea.getRange(xrange, yrange);
			
			mainGraph.xAxisMapping.setCoordinateRange(xcoordinate);
			mainGraph.xAxisMapping.setValueRange(xrange);
			mainGraph.yAxisMapping.setCoordinateRange(ycoordinate);
			mainGraph.yAxisMapping.setValueRange(yrange);
		},
		applySetting: function(setting){
			var bgSetting = {};
			if (Chart.Setting.Presentation.BG.tryDeSerialize(setting, Chart.Setting.SettingItem.Chart, bgSetting)) {
				mainGraph._placeHolder.css({
					"background-color": bgSetting.color
				});
			}
			this._coordinateArea.applySetting(setting);
			this._graphArea.applySetting(setting);
			this._tooltipLayer.applySetting(setting);
		},
        refresh: function(){
            var me = this;
            setTimeout(function(){
                me.initailizeCoordinateMapping();
				me._coordinateArea.refresh();
                me._graphArea.refresh();
                //me._tooltipLayer.refresh();
            }, 10);
        },
        clearAll: function(){
            this._coordinateArea.reset();
            this._graphArea.reset();
            this._tooltipLayer.reset();
            //this._messagePanel.onClearAll();
        },
        resizeComponents: function(width, height){
			var graphSize = {
				width: width - mainGraph._margin.left - mainGraph._margin.right,
				height: height - mainGraph._margin.top - mainGraph._margin.bottom-mainGraph.FOOTER_HEIGHT
			};
			this._coordinateArea.resize(graphSize.width, height);
			this._graphArea.resize(graphSize.width, graphSize.height);
			this._tooltipLayer.resize(graphSize.width, graphSize.height);
		},
        getHandler: function(args){
            switch (args.command) {
				case Chart.Common.Command.Commands.APPLY_CHART_SETTING:
					return this._onApplyChartSetting;
                case Chart.Common.Command.Commands.REFRESH_PRESENTATION:
                    return this._onRefreshPresentation;
                case Chart.Common.Command.Commands.RESIZE:
                    return this._onResize;
                case Chart.Common.Command.Commands.INITIALIZE:
                    return this._onInitialize;
                case Chart.Common.Command.Commands.COMPONENT_STATUS_UPDATE:
                    return this._onComponentStatusUpdate;
		        case Chart.Common.Command.Commands.SET_CULTURE:
		            return this._onSetCulture;
                default:
                    return null;
            }
        },
		_onApplyChartSetting: function(args){
			if (args && args.data && args.data.setting) {
				this.applySetting(args.data.setting);
				//this.refresh();
			}
		},
        _onInitialize: function(args){
			this._coordinateArea = new mainGraph.Presentation.CoordinateArea();
            this._graphArea = new mainGraph.Presentation.GraphArea();
            //this._messagePanel = new mainGraph.Presentation.MessagePanel();
            this._tooltipLayer = new mainGraph.Presentation.TooltipLayer();
        },
        _onRefreshPresentation: function(args){
            this.refresh();
        },
		_onSetCulture: function(args){
			if (args) {
				this.refresh();
			}
		},
        _onResize: function(args){
            if (args && args.data && args.data.width && args.data.height) {
                this.resize(args.data.width, args.data.height);
            }
            this.refresh();
        },
        _onComponentStatusUpdate: function(args){
            if (args && args.data && args.data.status) {
                switch (args.data.status) {
                    case Chart.Common.Command.ComponentStatus.ClearAll:
                        this.clearAll();
                        break;
                    default:
                        break;
                }
            }
        }
    });
    
    var initializeEx = function(){
        mainGraph._presentation = new mainGraph.Presentation.PresentationManager();
    };
    
    initializeEx();
};
Chart.Component.ComparisonBarGraph.prototype = $.extend(new Chart.Common.Command.CommandHandler(), {
    defaultHandler: function(args){
        //do nothing here.
    },
    getHandler: function(args){
        return this.defaultHandler;
    },
    collectionChildren: function(){
        this.interactiveChildren = [this._presentation];
    },
    setDataSource: function(datasource){
        this._datasource = datasource;
    },
    resize: function(width, height){
        this._presentation.resize(width, height);
        this._presentation.refresh();
    }
});

