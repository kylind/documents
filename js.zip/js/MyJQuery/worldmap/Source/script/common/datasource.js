Chart.DataSource = function(){
};

/**
 * Chart.DataSource.IChartDataSource
 * @class Chart.DataSource.IChartDataSource.
 * @note define the common interface of all data source that can be used by chart.
 * @param null.
 * @return current object.
 * @abstract
 */
Chart.DataSource.IChartDataSource = function(){

};
Chart.DataSource.IChartDataSource.prototype = {
    /*
     * create a data scource instance.
     * @param callback {function}.
     * @return null.
     */
    createInstance: function(callback){
    
    },
    /*
     * get data which can be formated as a time series.
     * @param dataKey {object}, the identity object of a data request, depended on special data source
     * @param dataCallback {function(dataKey, data)}.
     * @return null.
     */
    getTSData: function(dataKey, dataCallback){
    
    },
    /*
     * get data which is a dictionay.
     * @param dataKey {object}, the identity object of a data request, depended on special data source
     * @param dataCallback {function(dataKey, data)}.
     * @return null.
     */
    getGroupData: function(dataKey, dataCallback){
    
    },
    /*
     * get data which is a single value.
     * @param dataKey {object}, the identity object of a data request, depended on special data source
     * @param dataCallback {function(dataKey, data)}.
     * @return null.
     */
    getSingleData: function(dataKey, dataCallback){
    
    }
};

Chart.DataSource.IRequestItem = function(){
    this.guid = "";
};
Chart.DataSource.IRequestItem.prototype = {
    cancel: function(){
    
    },
    onCompleted: function(){
    
    }
};

Chart.DataSource.IRequestQueue = function(){

};
Chart.DataSource.IRequestQueue.prototype = {
    enqueue: function(requestItem){
    
    },
    dequeque: function(requestItem){
    
    },
    reset: function(){
    
    },
    onQueueStart: function(){
    
    },
    onQueueCompleted: function(){
    
    },
    onProgressChanged: function(){
    
    },
    onReset: function(){
    
    }
};

Chart.DataSource.IChartDataService = function(){

};
Chart.DataSource.IChartDataService.prototype = {
    /*
     * cancel request.
     * @param requestInfo {object}, the details of a data request, depended on special request
     * @return null.
     */
    cancelRequest: function(requestInfo){
    
    },
    /*
     * get data which can be formated as a time series.
     * @param requestInfo {object}, the details of a data request, depended on special request
     * @param dataCallback {function(requestInfo, data)}.
     * @return null.
     */
    getTSData: function(requestInfo, dataCallback){
    
    },
    /*
     * get data which is a dictionay.
     * @param requestInfo {object}, the details of a data request, depended on special request
     * @param dataCallback {function(requestInfo, data)}.
     * @return null.
     */
    getGroupData: function(requestInfo, dataCallback){
    
    },
    /*
     * get data which is a single value.
     * @param requestInfo {object}, the details of a data request, depended on special request
     * @param dataCallback {function(requestInfo, data)}.
     * @return null.
     */
    getSingleData: function(requestInfo, dataCallback){
    
    }
}

Chart.DataSource.IRequestSatellite = function(){
    this.requestQueue = null; //IRequestQueue;
    this.dataSource = null; //IChartDataService;
}

/**
 * Chart.DataSource.IChartRequestManager
 * @class Chart.DataSource.IChartRequestManager.
 * @note.
 * @param null.
 * @return current object.
 * @abstract
 */
Chart.DataSource.IChartRequestManager = function(){

};
Chart.DataSource.IChartRequestManager.prototype = $.extend(new Chart.DataSource.IChartDataService(), {
    /*
     *
     * @param requestInfo {object}, the details of a data request, depended on special request
     * @param refCaps {IList<RMCapability>}, the details of a data request, depended on special request
     * @return null.
     */
    queryRequiredCaps: function(requestInfo, refCaps){
    
    }
});

Chart.DataSource.RMCapability = {
    None: 0,
    Calculation: 1,
    TimeSeries: 2,
    Single: 3,
    
    getCaps: function(requestInfo){
        var caps = [];
        if (this._checkCustomCalculation(requestInfo)) {
            caps.push(Calculation);
        }
    },
    _checkCustomCalculation: function(requestInfo){
        return requestInfo.calculationId &&
        requestInfo.itemKey &&
        requestInfo.itemKey.dataId &&
        parseInt(requestInfo.calculationId) != Number.NaN;
    }
};

/**
 * Chart.DataSource.PlanetGateway
 * @class Chart.DataSource.PlanetGateway.
 * @note recognize the characters of a request, and find a request handler for it
 * @param null.
 * @return current object.
 * @singleton
 */
Chart.DataSource.PlanetGateway = function(){
    this.requestManagers = []; //IList<IChartRequestManager>
    this._threadCount = 0;
};
Chart.DataSource.PlanetGateway.prototype = $.extend(new Chart.DataSource.IChartDataService(), {
    /*
     * find a request manager which most satisfy to a request.
     * @param requestInfo {object}, the details of a data request.
     * @return IChartRequestManager
     */
    getRequestManager: function(requestInfo){
        var refCaps = Chart.DataSource.RMCapability.getCaps(requestInfo);
        
        for (var i = 0; i < this.requestManagers.length; i++) {
            var caps = this.requestManagers[i].queryRequiredCaps(requestInfo, refCaps);
            if (caps && caps.length > 0) {
                return this.requestManagers[i];
            }
        }
        
        return null;
    },
    /*
     * override
     */
    getTSData: function(requestInfo, dataCallback){
        this._getData(requestInfo, function(rm){
            rm.getTSData(requestInfo, dataCallback)
        }, function(){
            dataCallback(requestInfo, null)
        })
    },
    /*
     * override
     */
    getGroupData: function(requestInfo, dataCallback){
        this._getData(requestInfo, function(rm){
            rm.getGroupData(requestInfo, dataCallback)
        }, function(){
            dataCallback(requestInfo, null)
        })
    },
    /*
     * override
     */
    getSingleData: function(requestInfo, dataCallback){
        this._getData(requestInfo, function(rm){
            rm.getSingleData(requestInfo, dataCallback)
        }, function(){
            dataCallback(requestInfo, null)
        })
    },
    /*
     * private function
     * @param requestInfo {object}, the details of a data request.
     * @param action {function(requestManager)}
     * @param callback {function()}
     */
    _getData: function(requestInfo, action, callback){
        this._threadCount++;
        setTimeout(function(){
            var guid = ""
            if (requestInfo.guid) 
                guid = requestInfo.guid;
            ChartLogger.instance.write(String.format("operation {0} start.", guid));
            ChartLogger.instance.write("dispatcher thread count: " + this._threadCount);
            
            var rm = null;
            try {
                rm = this.getRequestManager(requestInfo);
            } 
            catch (ex) {
                ChartLogger.instance.write(ex.description);
            }
            
            if (rm) {
                ChartLogger.instance.write(String.format("success to get a request handler for {0}", guid));
                action(rm);
            }
            else {
                ChartLogger.instance.write(String.format("fail to get a request handler for {0}", guid));
                callback();
            }
            
            this._threadCount--;
            ChartLogger.instance.write(String.format("operation {0} end.", guid));
        });
    }
});

/**
 * Chart.DataSource.ChartDataRequest
 * @class Chart.DataSource.ChartDataRequest.
 * @note the data source object used by charts directly.
 * @param null.
 * @return current object.
 */
Chart.DataSource.ChartDataRequest = function(){

};
Chart.DataSource.ChartDataRequest.prototype = $.extend(new Chart.DataSource.IRequestSatellite(), new Chart.DataSource.IChartDataService(), {
	/*
     * override
     */
    getTSData: function(requestInfo, dataCallback){
    	requestInfo.guid = ""	//to do: should create a new guid here
    	var item = this._prepareRequestItem(requestInfo);
		
		if(this.dataSource)
			this.dataSource.getTSData(requestInfo, this._getRequestCallback(dataCallback,item));
    },
    /*
     * override
     */
    getGroupData: function(requestInfo, dataCallback){
    	requestInfo.guid = ""	//to do: should create a new guid here
    	var item = this.prepareRequestItem(requestInfo);
		
		if(this.dataSource)
			this.dataSource.getGroupData(requestInfo, this._getRequestCallback(dataCallback,item));
    },
    /*
     * override
     */
    getSingleData: function(requestInfo, dataCallback){
    	requestInfo.guid = ""	//to do: should create a new guid here
    	var item = this.prepareRequestItem(requestInfo);
		
		if(this.dataSource)
			this.dataSource.getSingleData(requestInfo, this._getRequestCallback(dataCallback,item));
    },
	_prepareRequestItem: function(requestInfo){
		var item = new Chart.DataSource.RequestItem(requestInfo.guid);
		
		if (this.requestQueue) 
			this.requestQueue.enqueue(item);
		
		item.onCancelled = function(sender, e){
			if (this.dataSource) 
				this.dataSource.cancelRequest(requestInfo);
		};
		
		return item;
	},
	_getRequestCallback: function(originalCallback, requestItem){
		return function(requestInfo, data){
			try {
				if (originalCallback) {
					originalCallback(requestInfo, data);
				}
			} 
			catch (ex) {
			//to do: write log here
			}
			finally {
				if (this.requestQueue) 
					this.requestQueue.dequeue(requestItem);
			}
		};
	}
});

/**
 * Chart.DataSource.RequestItem
 * @class Chart.DataSource.RequestItem.
 * @note the common attribute and behavior of all requests
 * @param null.
 * @return current object.
 */
Chart.DataSource.RequestItem = function(guid){
    this.guid = guid;
};
Chart.DataSource.RequestItem.prototype = $.extend(new Chart.DataSource.IRequestItem(), {
	/*
	 * override
	 */
    cancel: function(){
    	if(this.onCancelled)
			this.onCancelled(this, null);
    },
	onCancelled : function(){
		
	}
});

/**
 * Chart.DataSource.RequestQueue
 * @class Chart.DataSource.RequestQueue.
 * @note manage a requestItem list
 * @param null.
 * @return current object.
 */
Chart.DataSource.RequestQueue = function(){
    this.items = [];
};
Chart.DataSource.RequestQueue.prototype = $.extend(new Chart.DataSource.IRequestQueue(), {
    enqueue: function(requestItem){
        var oldCount = this.items.length;
        this._doAddItem(requestItem);
        var newCount = this.items.length;
        
        if (newCount > oldCount) {
            if (oldCount == 0) 
                this.onQueueStart();
            else 
                this.onProgressChanged();
        }
    },
    dequeque: function(requestItem){
        var oldCount = this.items.length;
        this._doRemoveItem(requestItem);
        var newCount = this.items.length;
        
        if (newCount < oldCount) {
            if (newCount == 0) 
                this.onQueueCompleted();
            else 
                this.onProgressChanged();
        }
    },
    reset: function(){
        while (this.items.length > 0) {
            var item = this.items.pop();
            item.cancel();
        }
        
        this.onReset();
    },
    _onRequestCompleted: function(sender, e){
        if (sender instanceof Chart.DataSource.IRequestItem) {
            dequeque(sender);
        }
    },
    _doAddItem: function(requestItem){
        if ($.inArray(requestItem, this.items) < 0) {
            requestItem.onCompleted = this._onRequestCompleted;
            this.items.push(requestItem);
        }
    },
    _doRemoveItem: function(requestItem){
        var index = $.inArray(requestItem, this.items);
        if (index >= 0) {
            this.items.splice(index, 1);
        }
    }
});

Chart.DataSource.RequestManagerBase = function(){
	/*
	 * @param guid {string} the key value.
	 * @param action {function(callback)}
	 */
	var RequestItem = function(guid, action){
		this.timeOut = 300000;
		this.guid = guid;
		this.action = action;
		
		var _timer = null;
		var me = this;
		
		this.runAsync = function(){
			if (this.action) {
				setTimeout(function(){
					_timer = setTimeout(function(){
						me.cancel();
					}, me.timeOut);
					
					try {
						me.action(_onCompleted);
					} 
					catch (ex) {
					//to do: write exception log here.
					}
				}, 10);
			}
			else {
				if (this.onCompleted) 
					this.onCompleted(this, null);
			}
		};
		
		this.cancel = function(){
			if (this.onCompleted) 
				this.onCompleted(this, null);
		};
		
		this.onCompleted = function(sender, e){
			
		};
		
		var _onCompleted = function(){
			if (_timer) 
				clearTimeout(_timer);
			
			if (me.onCompleted) 
				me.onCompleted(me, null);
		}
	};
	/*
	 * 
	 */
	var RequestQueue = function(){
		this.maxRequest = 0;
		
		var TIMER_INTERVAL = 1000;
		
		var _requestingQueue = [];
		var _waitingQueue = [];
		
		var _timer = null;
		var me = this;
		
		this.newRequest = function(requestItem){
			if (!tryStartJob(requestItem)) {
				if (_waitingQueue.length == 0) 
					this.onQueueStart();
				
				_waitingQueue.push(requestItem);
				ChartLogger.instance.write(String.format("request {1} entered wait queue, currently {0} waiting", _waitingQueue.length, requestItem.guid));
			}
		};
		this.cancelRequest = function(guid){
			ChartLogger.instance.write("cancelling request " + guid);
			
			if (_waitingQueue.length > 0) {
				for (var i = 0; i < _waitingQueue.length; i++) {
					if (_waitingQueue[i].guid == guid) {
						_waitingQueue.splice(i, 1);
						break;
					}
				}
				if (_waitingQueue.length == 0) 
					this.onQueueCompleted();
			}
			
			for (var j = 0; j < _requestingQueue.length; j++) {
				if(_requestingQueue[j].guid = guid){
					_requestingQueue[j].cancel();
					_requestingQueue.splice(j,1);
					break;
				}
			}
			
			pumpRequestOnTimer();
		};
		this.onQueueStart = function(){
			
		};
		this.onQueueCompleted = function(){
			
		};
		this.setTimer = function(){
			_timer = setInterval(function(){
				pumpRequestOnTimer();
			}, TIMER_INTERVAL);
		};
		this.removeTimer = function(){
			clearInterval(_timer);
		};		
		
		var pumpRequestOnTimer = function(){
			while (_waitingQueue.length > 0) {
				var item = null;
				var waitCount = 0;
				
				if (_waitingQueue.length == 0) 
					break;
					
				item = _waitingQueue.pop();
				waitCount = _waitingQueue.length;
				
				if (tryStartJob(item)) {
					if (waitCount == 0) {
						me.onQueueCompleted();
					}
				}
				else {
					_waitingQueue.splice(0, 0, item);
					break;
				}
			}
		};
		var tryStartJob = function(requestItem){
			var canStart = false;
			var runCount = 0;	
			if(_requestingQueue.length < me.maxRequest){
				_requestingQueue.push(requestItem);
				runCount = _requestingQueue.length;
				requestItem.onCompleted = function(sender,e){
					removeRequestItem(requestItem.guid);
				};
				
				canStart = true;
			}
			
			if (canStart) {
				ChartLogger.instance.write(String.format("request {1} start to run, total {0} running.", runCount, requestItem.guid));
				requestItem.runAsync();
			}
			
			return canStart;
		};
		var removeRequestItem = function(guid){
			for(var i=0;i<_requestingQueue.length;i++){
				if (_requestingQueue[i].guid == guid) {
					_requestingQueue.splice(i, 1);
					break;
				}
			}
			pumpRequestOnTimer();
		};
	};
	
	this.dataSource = null;
	this.caps =[];
	this.maxRequest = 100;
	var _queue= null;
	var me = this;
	
	var initializeEx = function(){
		_queue = new RequestQueue();
		_queue.maxRequest = me.maxRequest;
		_queue.onQueueStart = function(){
			_queue.setTimer();
		};
		_queue.onQueueCompleted = function(){
			_queue.removeTimer();
		};
	};
	
	initializeEx();
};
Chart.DataSource.RequestManagerBase.prototype = {
	
};

Chart.DataSource.ConfigureDataSource = {
	setupDataSource: function(satellite, datasource){
		satellite.dataSource = datasource;
	}
};
Chart.DataSource.ConfigureRequestQueue = {
	setupRequestQueue: function(satellite, queue){
		satellite.requestQueue = queue;
	}
};
Chart.DataSource.ConfigureRequestManager = {
	setupRequestManager: function(gateway, requestManager){
		gateway.requestManagers.push(requestManager);
	}
};
Chart.DataSource.DataSourceHelper = function(){
	this._datasource = new Chart.DataSource.PlanetGateway();
	
	//Chart.DataSource.ConfigureRequestManager.setupRequestManager(this._dataSource, new UserFundRequestManager());
    //Chart.DataSource.ConfigureRequestManager.setupRequestManager(this._dataSource, new DACRequestManager());
};
Chart.DataSource.DataSourceHelper.prototype = {
	getDataSource: function(){
		return this._datasource;
	},
	getRequestQueue: function(){
		return new Chart.DataSource.RequestQueue();
	},
	getSatellite: function(requestQueue){
		var satellite = new Chart.DataSource.ChartDataRequest();
		Chart.DataSource.ConfigureRequestQueue.setupRequestQueue(satellite, requestQueue);
		Chart.DataSource.ConfigureDataSource.setupDataSource(satellite, this.getDataSource());
		return satellite;
	}
};
Chart.DataSource.DataSourceHelper.instance = new Chart.DataSource.DataSourceHelper();
