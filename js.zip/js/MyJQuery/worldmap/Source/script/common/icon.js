var Icon = function() { };

Icon.IconType = {
    Rect: 0,
    Area: 1,
    Square: 2,
    Circle: 3,
    Triangle: 4,
    Cross: 5,
    LineSmall: 6,
    LineMedium: 7,
    LineThick: 8,
    CharDividend: 9,
    CharCapitalGain: 10,
    CharSplits: 11,
    TipBox: 12,
    LoadingIcon: 13,
    Ellipse: 14,
    DotSmall: 15,
    DotMedium: 16,
    DotLarge: 17,
    Menu: 18,
    Diamond: 19,
    Pentagon: 20,
    TriangleDown: 21,
    TriangleLeft: 22,
    TriangleRight: 23,
    CircleFrame: 24,
    SquareFrame: 25,
    TriangleFrame: 26,
    TriangleDownFrame: 27,
    TriangleLeftFrame: 28,
    TriangleRightFrame: 29,
    DiamondFrame: 30,
    PentagonFrame: 31,
    Warning: 97,
    Error: 98,
    None: 99
};

Icon.TriangleDirection = {
    UP: 0,
    DOWN: 1,
    LEFT: 2,
    RIGHT: 3
};

Icon.HorizontalAlign = {
    Left: 0,
    Center: 1,
    Right: 2,
    Stretch: 3
};

Icon.VerticalAlign = {
    Top: 0,
    Center: 1,
    Bottom: 2,
    Stretch: 3
};

Icon.Setting = function() {
    this.iconType = Icon.IconType.None;
    this.position = { x: 0, y: 0 };
    this.region = { width: 0, height: 0 };
    this.size = { width: 0, height: 0 };
    this.align = Icon.HorizontalAlign.Left;
    this.valign = Icon.VerticalAlign.Center;
    this.color = "#FFFFFF";
    this.cross = false;
};

Icon.Drawer = function(container){
	//RECT
	var RECT_WIDTH = 14;
	var RECT_HEIGHT = 7;
	
	//SQUARE
	var SIDE_LEN = 8;
	
	//CIRCLE
	var RADIUS = 3.5;
	
	//TRIANGLE
	var TRIANGLE_HEIGHT = 8;
	//CROSS
	
	//LINE:SMALL_LINE, MEDIUM_LINE, THICK_lINE
	var LINE_LEN = 10;
	var SMALL_LINE_WIDTH = 1;
	var MEDIUM_LINE_WIDTH = 2;
	var THICK_LINE_WIDTH = 3;
	
	var SMALL_DOT_RADIUS = 3;
	var MEDIUM_DOT_RADIUS = 4;
	var LARGE_DOT_RADIUS = 6;
	
	//LoadingIcon
	var LOADING_WIDTH = 12;
	var LOADING_HEIGHT = 12;
	
	//Cross
	var CROSS_WIDTH = 10;
	var CROSS_HEIGHT = 10;
	var CROSS_LINE_WIDTH = 2;
	
	var LEFT_MARGIN = 3;
	var RIGHT_MARGIN = 3;
	
	var FRAME_WIDTH = 1.5;
	
	var _container = null;
	var _isCanvas = false;
	var _iconSetting = null;
	var _graphics = null;
	
	var _zoomx = 1;
	var _zoomy = 1;
	
	this.setContainer = function(container){
		_container = container;
		_isCanvas = isCanvas(container);
		if (_isCanvas) {
			_graphics = new $.Graphics(_container.getContext("2d"));
		}
		else {
			_graphics = null;
		}
	};
	
	this.draw = function(iconSetting){
		if (!iconSetting) 
			return;
		_iconSetting = iconSetting;
		
		var canvas = null;
		if (!_isCanvas) {
			//the container is a div or the other container,
			//we will create a new canvas for this icon.
			canvas = $.Canvas.create($(_container), "relative", iconSetting.position.x, iconSetting.position.y, iconSetting.region.width, iconSetting.region.height);
			_graphics = new $.Graphics(canvas.getContext("2d"));
		}
		else {
			canvas = _container;
		}
		
		switch (iconSetting.iconType) {
			case Icon.IconType.Rect:
			case Icon.IconType.Area:
				//                DrawRect(false);
				break;
			case Icon.IconType.Square:
				//                DrawSquare(this._iconSetting.Cross, true);
				break;
			case Icon.IconType.SquareFrame:
				//                DrawSquare(this._iconSetting.Cross, false);
				break;
			case Icon.IconType.Circle:
				break;
			case Icon.IconType.CircleFrame:
				break;
			case Icon.IconType.Triangle:
				//                DrawTriangle(this._iconSetting.Cross, TriangleDirection.UP, true);
				break;
			case Icon.IconType.Cross:
				//                DrawCross();
				break;
			case Icon.IconType.LineSmall:
				drawLine(SMALL_LINE_WIDTH);
				break;
			case Icon.IconType.LineMedium:
				drawLine(MEDIUM_LINE_WIDTH);
				break;
			case Icon.IconType.LineThick:
				drawLine(THICK_LINE_WIDTH);
				break;
			case Icon.IconType.DotSmall:
				//                DrawCircle(this._iconSetting.Cross, SMALL_DOT_RADIUS * Math.Min(this._zoomx, this._zoomy), true);
				break;
			case Icon.IconType.DotMedium:
				//                DrawCircle(this._iconSetting.Cross, MEDIUM_DOT_RADIUS * Math.Min(this._zoomx, this._zoomy), true);
				break;
			case Icon.IconType.DotLarge:
				//                DrawCircle(this._iconSetting.Cross, LARGE_DOT_RADIUS * Math.Min(this._zoomx, this._zoomy), true);
				break;
			case Icon.IconType.Menu:
				//                DrawMenu();
				break;
			case Icon.IconType.Diamond:
				//                DrawDiamond(this._iconSetting.Cross, true);
				break;
			case Icon.IconType.DiamondFrame:
				//                DrawDiamond(this._iconSetting.Cross, false);
				break;
			case Icon.IconType.Pentagon:
				//                DrawPentagon(this._iconSetting.Cross, true);
				break;
			case Icon.IconType.PentagonFrame:
				//                DrawPentagon(this._iconSetting.Cross, false);
				break;
			case Icon.IconType.TriangleFrame:
				//                DrawTriangle(this._iconSetting.Cross, TriangleDirection.UP, false);
				break;
			case Icon.IconType.TriangleDown:
				drawTriangle(Icon.TriangleDirection.DOWN, true);
				break;
			case Icon.IconType.TriangleDownFrame:
				//                DrawTriangle(this._iconSetting.Cross, TriangleDirection.DOWN, false);
				break;
			case Icon.IconType.TriangleLeft:
				drawTriangle(Icon.TriangleDirection.LEFT, true);
				break;
			case Icon.IconType.TriangleLeftFrame:
				//                DrawTriangle(this._iconSetting.Cross, TriangleDirection.LEFT, false);
				break;
			case Icon.IconType.TriangleRight:
				drawTriangle(Icon.TriangleDirection.RIGHT, true);
				break;
			case Icon.IconType.TriangleRightFrame:
				//                DrawTriangle(this._iconSetting.Cross, TriangleDirection.RIGHT, false);
				break;           
			case Icon.IconType.Error:
				drawErrorCross();
				break;
		}
		
		if (!_isCanvas) {
			_graphics = null;
		};
		return canvas;
	};
	
	var drawLine = function(lineWidth){
		var length = _iconSetting.size.width;
		if (length <= 0) 
			length = LINE_LEN * _zoomx;
		
		var xpos = LEFT_MARGIN * _zoomx;
		var ypos = 0;
		if (lineWidth % 2 == 1) 
			ypos = 0.5;
		
		ypos = Math.floor(_iconSetting.region.height * 0.5) + ypos;
		
		if (isCanvas) {
			xpos += _iconSetting.position.x;
			ypos += _iconSetting.position.y;
		}
		
		_graphics.begin();
		_graphics.setLineStyle(lineWidth, _iconSetting.color);
		_graphics.drawLine(xpos, ypos, xpos + length, ypos);
		_graphics.end();
	};
	var drawErrorCross = function(){
		var width = _iconSetting.size.width;
		var height = _iconSetting.size.height;
		if (width == 0 && height == 0) {
			width = CROSS_WIDTH * Math.min(_zoomx, _zoomy);
			height = CROSS_HEIGHT * Math.min(_zoomx, _zoomy);
		}
		
		_graphics.begin();
		_graphics.setLineStyle(CROSS_LINE_WIDTH, _iconSetting.color);
		
		//default as HorizontalAlignment.Left and VerticalAlignment.Center
		var nx = LEFT_MARGIN * _zoomx;
		var ny = _iconSetting.region.height * 0.5 - height * 0.5;
		if (_iconSetting.align == Icon.HorizontalAlign.Center) {
			nx = _iconSetting.region.width * 0.5 - width * 0.5;
		}
		else 
			if (_iconSetting.align == Icon.HorizontalAlign.Right) {
				nx = _iconSetting.region.width - RIGHT_MARGIN * _zoomx - width;
			}
		
		if (_iconSetting.valign == Icon.VerticalAlign.Top) {
			ny = 0;
		}
		else 
			if (_iconSetting.valign == Icon.VerticalAlign.Bottom) {
				ny = _iconSetting.region.height - height;
			}
		
		if (isCanvas) {
			nx += _iconSetting.position.x;
			ny += _iconSetting.position.y;
		}
		
		_graphics.drawLine(nx, ny, nx + width, ny + height);
		_graphics.drawLine(nx, ny + height, nx + width, ny);
		_graphics.end();
	};
	var drawTriangle = function(direction, fill, cross){
		var width = _iconSetting.size.width;
		var height = _iconSetting.size.height;
		if (width == 0 && height == 0) {
			width = TRIANGLE_HEIGHT * Math.min(_zoomx, _zoomy);
			height = TRIANGLE_HEIGHT * Math.min(_zoomx, _zoomy);
		}
		
		var pointArray = null;
		switch (direction) {
			case Icon.TriangleDirection.UP:
				pointArray = constructTrangleUp(width, height);
				break;
			case Icon.TriangleDirection.DOWN:
				pointArray = constructTrangleDown(width, height);
				break;
			case Icon.TriangleDirection.LEFT:
				pointArray = constructTrangleLeft(width, height);
				break;
			case Icon.TriangleDirection.RIGHT:
				pointArray = constructTrangleRight(width, height);
				break;
		}
		_graphics.begin();
		if (fill) {
			_graphics.setLineStyle(0, _iconSetting.color);
			_graphics.setNormalFill(_iconSetting.color);
		}
		else {
			_graphics.setLineStyle(FRAME_WIDTH, _iconSetting.color);
			_graphics.setNoneFill();
		}
		_graphics.drawPolygon(pointArray);
		_graphics.end();
	};
	var constructTrangleUp = function(width, height){
		var pointArray = [];
		var x1, y1, x2, y2, x3, y3; // in order of top-right-bottom-left 
		switch (_iconSetting.align) {
			case Icon.HorizontalAlign.Left:
				x1 = width * 0.5;
				x2 = width;
				x3 = 0;
				break;
			case Icon.HorizontalAlign.Right:
				x1 = -width * 0.5;
				x2 = 0;
				x3 = -width;
				break;
			case Icon.HorizontalAlign.Center:
			default:
				x1 = 0;
				x2 = width * 0.5;
				x3 = -x2;
				break;
		}
		switch (_iconSetting.valign) {
			case Icon.VerticalAlign.Top:
				y1 = 0;
				y2 = height;
				y3 = y2;
				break;
			case Icon.VerticalAlign.Bottom:
				y1 = -height;
				y2 = 0;
				y3 = y2;
				break;
			case Icon.VerticalAlign.Center:
			default:
				y1 = -height * 0.5;
				y2 = height * 0.5;
				y3 = y2;
				break;
		}
		
		pointArray.push(adjustPointWithAlignment({
			x: x1,
			y: y1
		}));
		pointArray.push(adjustPointWithAlignment({
			x: x2,
			y: y2
		}));
		pointArray.push(adjustPointWithAlignment({
			x: x3,
			y: y3
		}));
		
		return pointArray;
	};
	var constructTrangleDown = function(width, height){
		var pointArray = [];
		var x1, y1, x2, y2, x3, y3; // in order of top-right-bottom-left 
		switch (_iconSetting.align) {
			case Icon.HorizontalAlign.Left:
                    x1 = 0;
                    x2 = width;
                    x3 = width * 0.5;
                    break;
                case Icon.HorizontalAlign.Right:
                    x1 = -width;
                    x2 = 0;
                    x3 = -0.5 * width;
                    break;
                case Icon.HorizontalAlign.Center:
                default:
                    x1 = -0.5 * width;
                    x2 = 0.5 * width;
                    x3 = 0;
                    break;
		}
		switch (_iconSetting.valign) {
			case Icon.VerticalAlign.Top:
				y1 = 0;
				y2 = y1;
				y3 = height;
				break;
			case Icon.VerticalAlign.Bottom:
				y1 = -height;
				y2 = y1;
				y3 = 0;
				break;
			case Icon.VerticalAlign.Center:
			default:
				y1 = -height * 0.5;
				y2 = y1;
				y3 = height * 0.5;
				break;
		}
		
		pointArray.push(adjustPointWithAlignment({
			x: x1,
			y: y1
		}));
		pointArray.push(adjustPointWithAlignment({
			x: x2,
			y: y2
		}));
		pointArray.push(adjustPointWithAlignment({
			x: x3,
			y: y3
		}));
		
		return pointArray;
	};
	var constructTrangleLeft = function(width, height){
		var pointArray = [];
		var x1, y1, x2, y2, x3, y3; // in order of top-right-bottom-left 
		switch (_iconSetting.align) {
			case Icon.HorizontalAlign.Left:
				x1 = width;
				x2 = x1;
				x3 = 0;
				break;
			case Icon.HorizontalAlign.Right:
				x1 = 0;
				x2 = x1;
				x3 = -width;
				break;
			case Icon.HorizontalAlign.Center:
			default:
				x1 = 0.5 * width;
				x2 = x1;
				x3 = -x1;
				break;
		}
		switch (_iconSetting.valign) {
			case Icon.VerticalAlign.Top:
				y1 = 0;
				y2 = height;
				y3 = 0.5 * height;
				break;
			case Icon.VerticalAlign.Bottom:
				y1 = -height;
				y2 = 0;
				y3 = -0.5 * height;
				break;
			case Icon.VerticalAlign.Center:
			default:
				y1 = -height * 0.5;
				y2 = height * 0.5;
				y3 = 0;
				break;
		}
		
		pointArray.push(adjustPointWithAlignment({
			x: x1,
			y: y1
		}));
		pointArray.push(adjustPointWithAlignment({
			x: x2,
			y: y2
		}));
		pointArray.push(adjustPointWithAlignment({
			x: x3,
			y: y3
		}));
		
		return pointArray;
	};
	var constructTrangleRight = function(width, height){
		var pointArray = [];
		var x1, y1, x2, y2, x3, y3; // in order of top-right-bottom-left 
		switch (_iconSetting.align) {
			case Icon.HorizontalAlign.Left:
				x1 = 0;
				x2 = width;
				x3 = x1;
				break;
			case Icon.HorizontalAlign.Right:
				x1 = -width;
				x2 = 0;
				x3 = x1;
				break;
			case Icon.HorizontalAlign.Center:
			default:
				x1 = -0.5 * width;
				x2 = 0.5 * width;
				x3 = x1;
				break;
		}
		switch (_iconSetting.valign) {
			case Icon.VerticalAlign.Top:
				y1 = 0;
				y2 = 0.5 * height;
				y3 = height;
				break;
			case Icon.VerticalAlign.Bottom:
				y1 = -height;
				y2 = -0.5 * height;
				y3 = 0;
				break;
			case Icon.VerticalAlign.Center:
			default:
				y1 = -height * 0.5;
				y2 = 0;
				y3 = height * 0.5;
				break;
		}
		
		pointArray.push(adjustPointWithAlignment({
			x: x1,
			y: y1
		}));
		pointArray.push(adjustPointWithAlignment({
			x: x2,
			y: y2
		}));
		pointArray.push(adjustPointWithAlignment({
			x: x3,
			y: y3
		}));
		
		return pointArray;
	};
	var adjustPointWithAlignment = function(pt){
		if (_iconSetting.align == Icon.HorizontalAlign.Center) {
			pt.x += _iconSetting.region.width * 0.5;
		}
		else 
			if (_iconSetting.align == Icon.HorizontalAlign.Right) {
				pt.x += _iconSetting.region.width - RIGHT_MARGIN * _zoomx;
			}
			else 
				if (_iconSetting.align == Icon.HorizontalAlign.Left) {
					pt.x += LEFT_MARGIN * _zoomx;
				}
		
		if (_iconSetting.valign == Icon.VerticalAlign.Center) {
			pt.y += _iconSetting.region.height * 0.5;
		}
		else 
			if (_iconSetting.valign == Icon.VerticalAlign.Bottom) {
				pt.y += _iconSetting.region.height;
			}
			
		if (_isCanvas) {
			pt.x += _iconSetting.position.x;
			pt.y += _iconSetting.position.y;
		}
		
		return pt;
	};
	
	var initializeEx = function(){
		_container = container;
		_isCanvas = isCanvas(container);
		_iconSetting = null;
		_graphics = _isCanvas ? new $.Graphics(_container.getContext("2d")) : null;
	};
	var isCanvas = function(container){
		if (container) 
			return container.nodeName.toLowerCase() == "canvas";
		return false;
	};
	initializeEx();
};



