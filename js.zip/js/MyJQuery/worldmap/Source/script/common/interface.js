var extend = function(dest, source) { //implement interface
    for (property in source) {
        if (!dest[property]) //copy functions from source to desc
            dest[property] = source[property];
    }
    return dest;
};

//test code;
//var IClassManager = {
//    hasClass: function(name) { return name },
//    addClass: function(name) { return name }
//};

//var IClassManager1 = function() {
//    this.abc = 123;
//};
//IClassManager1.prototype.hasClass = function(name) { return name };
//IClassManager1.prototype.addClass = function(name) { return name };

//var BaseClass = function() {
//    this._baseClass = 1;
//    var privateVar = 2;
//};
//BaseClass.prototype.addBaseClass = function() { return "addBaseClass" };

//var MenuItem = function() {
//    this._item1 = 0;
//    var item2 = 1;
//    this.setText = function() {
//        return "setText";
//    };
//};
//MenuItem.prototype = new BaseClass();
//debugger;
////extend(MenuItem.prototype, IClassManager);
//extend(MenuItem.prototype, new IClassManager1());

//var item = new MenuItem();
//item.hasClass("1");
//item.addClass("1");