/**
 * @author Nsu
 */
Chart.Eclipse = function(containerDOM, radius){
    this.dataSource = null;
    this.graph = null;
    this.container = null;
    this.canvas = null;
    this.radius = 0;
    this.optionals = {}; // callbacks or optionals parameters
    this.optionals.mouseover = function(dataIndex){}; //callback
    this.optionals.mouseout = function(dataIndex){}; //callback
    this.optionals.mousemove = function(dataIndex){}; //callback
    this.optionals.mouseup = function(dataIndex){}; //callback
    this.optionals.mousedown = function(dataIndex){}; //callback
    if (radius) {
        if (isNaN(parseFloat(radius))) {
            throw "invalid radius " + radius;
        }
        else {
            this.radius = radius;
        }
    }
    else {
        this.radius = 150;
    }
    
    if (containerDOM) {
        this.container = containerDOM;
        this.canvas = this.container.get(0);
    }
    this.dataSource = new Chart.Component.EclipseData();
    this.graph = new Chart.Component.EclipsGraph(containerDOM, this.radius, this.optionals);
    this.graph.setDataSource(this.dataSource);
    this.graph.collectionChildren();
    this.dataSource.collectionChildren();
    this.dataSource.addChild(this.graph);
    this.dataSource.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.INITIALIZE, null));
    this.draw = function(){
        this.dataSource.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.REFRESH_PRESENTATION, null));
    }
}

Chart.Eclipse.prototype = $.extend(new Chart.Common.Graphic.GraphElement(), {
    resizeComponents: function(width, height){
        this.graph.resize(width, height);
    },
    refresh: function(){
        var me = this;
        this.dataSource.refresh(function(){
            me.dataSource.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.REFRESH_PRESENTATION, null));
        });
    },
    setData: function(objArr){
        this.dataSource.setData(objArr);
    }
});

Chart.Component.EclipsGraph = function(containerDom, radius, optionals){
    this.radius = 0;
    this.outContainer = containerDom;
    this.dataSource = null;
    this.reservedPix = 10;
    this.optionals = optionals;
    var me = this;
    
    if (radius) {
        if (isNaN(parseFloat(radius))) {
            throw "invalid radius " + radius;
        }
        else {
            this.radius = radius;
        }
    }
    else {
        this.radius = 150;
    }
    
    canvasWidth = 2 * this.radius + this.reservedPix;
    this._canvasLayer = $.Canvas.create(this.outContainer, "relative", 0, 0, canvasWidth, canvasWidth);
	this._canvasRef = $(this._canvasLayer);
	this._ctx = this._canvasLayer.getContext("2d");
    this._graphics = new $.Graphics(this._ctx);
    
    this.getCenter = function(){
        return {
            x: this._canvasRef.width() / 2,
            y: this._canvasRef.height() / 2
        };
    }
    
    this.getEventIndex = function(ee){
        var ptCenter = this.getCenter();
        var ptPosition = $.getPosition(this._canvasLayer, ee);
        var distance = Math.sqrt((ptPosition.x - ptCenter.x) * (ptPosition.x - ptCenter.x) + (ptPosition.y - ptCenter.y) * (ptPosition.y - ptCenter.y))
        if (distance >= this.radius) {
            return -1;
        }
        
        
        var arcDegree = Math.asin((ptPosition.y - ptCenter.y) / distance);
        if ((ptPosition.x - ptCenter.x >= 0) && (ptPosition.y - ptCenter.y >= 0)) //1
        {
			arcDegree += Math.PI * 2; //[2PI, 2.5PI]
        }
        else 
            if ((ptPosition.x - ptCenter.x <= 0) && (ptPosition.y - ptCenter.y >= 0)) //2
            {
                arcDegree = Math.PI - arcDegree;
				arcDegree += Math.PI * 2;
            }
            else 
                if ((ptPosition.x - ptCenter.x >= 0) && (ptPosition.y - ptCenter.y <= 0)) // 4
                {
                    arcDegree = 2 * Math.PI + arcDegree
                    //self
                }
                else //3
                {
                    arcDegree = Math.PI - arcDegree
                    arcDegree = 2 * Math.PI + arcDegree
                }

        var ii = 0;
        for (; ii < this.dataSource.busiData.length; ++ii) {
            if ((me.dataSource.busiData[ii][3]< arcDegree) && (arcDegree < me.dataSource.busiData[ii][4])) {
                break;
            }
        }
        return ii;
    }
    
    var _onMouseOver = function(ee){
        if (me.optionals && me.optionals.mouseover && typeof(me.optionals.mouseover) == "function") {
            var index = me.getEventIndex(ee);
            if (index < 0) {
                return;
            }
            me.optionals.mouseover(index);
        }
    };
    var _onMouseOut = function(ee){
        if (me.optionals && me.optionals.mouseout && typeof(me.optionals.mouseout) == "function") {
            var index = me.getEventIndex(ee);
            if (index < 0) {
                return;
            }
            me.optionals.mouseout(index);
        }
    };
    var _onMouseMove = function(ee){
        if (me.optionals && me.optionals.mousemove && typeof(me.optionals.mousemove) == "function") {
            var index = me.getEventIndex(ee);
            if (index < 0) {
                return;
            }
            me.optionals.mousemove(index);
        }
    };
    var _onMouseUp = function(ee){
        if (me.optionals && me.optionals.mouseup && typeof(me.optionals.mouseup) == "function") {
            var index = me.getEventIndex(ee);
            if (index < 0) {
                return;
            }
            me.optionals.mouseup(index);
        }
    };
    var _onMouseDown = function(ee){
        if (me.optionals && me.optionals.mousedown && typeof(me.optionals.mousedown) == "function") {
            var index = me.getEventIndex(ee);
            if (index < 0) {
                return;
            }
            me.optionals.mousedown(index);
        }
    };
    
    var _addEventHandler = function(){
		var canvasRef = $(me._canvasLayer);
        canvasRef.mouseover(_onMouseOver);
        canvasRef.mouseout(_onMouseOut);
        canvasRef.mousemove(_onMouseMove);
        canvasRef.mouseup(_onMouseUp);
        canvasRef.mousedown(_onMouseDown);
    };
	
    _addEventHandler();
}

Chart.Component.EclipsGraph.prototype = $.extend(new Chart.Common.Command.CommandHandler(), {
    defaultHandler: function(args){
        //do nothing here.
    },
    getHandler: function(args){
        switch (args.command) {
            case Chart.Common.Command.Commands.REFRESH_PRESENTATION:
                return this._onRefreshPresentation;
            case Chart.Common.Command.Commands.APPLY_CHART_SETTING:
            case Chart.Common.Command.Commands.RESIZE:
            case Chart.Common.Command.Commands.INITIALIZE:
            case Chart.Common.Command.Commands.COMPONENT_STATUS_UPDATE:
            default:
                return this.defaultHandler;
        }
    },
    collectionChildren: function(){
        this.interactiveChildren = [];
    },
    setDataSource: function(datasource){
        this.dataSource = datasource;
    },
    resize: function(width, height){
    },
    _onRefreshPresentation: function() //do acutal draw
	{
		this._ctx.clearRect(0, 0, this._canvasRef.width(), this._canvasRef.height());
		
		var ptCenter = this.getCenter();
		var tmpBusiData = this.dataSource.busiData;
		var lines = [];
		for (var ii = 0; ii < tmpBusiData.length; ++ii) {
			this._graphics.begin();
			this._graphics.setLineStyle(0);
			this._graphics.setNormalFill(tmpBusiData[ii][2].toString());
			this._graphics.drawArc(ptCenter, this.radius, tmpBusiData[ii][3], tmpBusiData[ii][4]);
			this._graphics.end();
			
			lines.push([
				ptCenter.x, 
				ptCenter.y, 
				ptCenter.x + this.radius * Math.cos(tmpBusiData[ii][3] ), 
				ptCenter.y + this.radius * Math.sin(tmpBusiData[ii][3] )]);
		}
		
		this._graphics.begin();
		this._graphics.setLineStyle(1, "#cccccc");
		this._graphics.drawLines(lines);
		this._graphics.end();
	}
});

Chart.Component.EclipseData = function(){
    this.busiData = []; //[  ... ["institute1", 60, { r,g,b,a }, beginArc, endArc] ... ]
    this.radius = 150;
    /*
     var perData = [
     ["institute investor", 60, "#aa1212"],
     ["individual investor1", 10, "#12aa12"],
     ["individual investor2", 10, "#1212aa"],
     ["individual investor3", 10, "#aa1212"],
     ["individual investor4", 10, "#12aa12"] ];
     */
    this.setData = function(data){
        var beginArc = 1.5 * Math.PI;
        var endArc = 1.5 * Math.PI;
        var total = 0;
        this.busiData = [];
        var me = this;

        $.each(data, function(i, c){
            floatValue = parseFloat(data[i][1]);
            if (isNaN(floatValue)) {
                throw ("Invalid data, need numper")
            }
            data[i][1] = floatValue;
            total += data[i][1];
        });
        
        $.each(data, function(i, c){
            var arcDegree = c[1] / total * Math.PI * 2;
            endArc += arcDegree;
            me.busiData.push([data[i][0], data[i][1], $.color.parse(data[i][2]), beginArc, endArc]);
            beginArc = endArc;
        });
        
        this.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.APPLY_CHART_SETTING, this.busiData));
        
    }
    
    this.clear = function(){
        this.radius = 0;
        this.busiData = [];
    }
}
Chart.Component.EclipseData.prototype = $.extend(new Chart.Common.Command.CommandHandler(), {
    getHandler: function(args){
        switch (args.command) {
            case Chart.Common.Command.Commands.UPDATE_SELECTION:
            case Chart.Common.Command.Commands.RESIZE:
            case Chart.Common.Command.Commands.INITIALIZE:
            case Chart.Common.Command.Commands.COMPONENT_STATUS_UPDATE:
            case Chart.Common.Command.Commands.REFRESH_PRESENTATION:
            case Chart.Common.Command.Commands.ITEM_STATUS_UPDATE:
            case Chart.Common.Command.Commands.APPLY_CHART_SETTING:
            default:
                return this.defaultHandler;
        }
        return this.defaultHandler;
    },
    /*
     * default command handler, the purpose of this is the enable all commmand will be passed to children.
     * @param arg {Chart.Common.Command.CommandArgs} content.
     * @return null.
     */
    defaultHandler: function(args){
        //do nothing here.
    }
});
