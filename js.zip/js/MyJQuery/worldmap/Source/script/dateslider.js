Chart.Component.DateSlider = function(target) {
    this.SCROLLBAR_HEIGHT = 9;
    this.LEFT_MARGIN = 5;
    this.BORDER_RADIUS = 4;
    this._placeHolder = null;
    this._datasource = null;

    this._graphCanvas = null;
    this._coordinateCanvas = null;
    this._coordinateLabelCanvas = null;
    this._scrollbarCanvas = null;
    this._sliderCanvas = null;
    this._sliderLeftCanvas = null;
    this._sliderRightCanvas = null;
    this._eventCanvas = null;

    this.showSnapshot = false;
    this.isImmediately = false;

    this.xAxisMapping = new Chart.Common.Coordinate.Date2DoubleLinearMapping();
    //    this.yAxisMapping = new Chart.Common.Coordinate.Double2DoubleLinearMapping();

    var mainGraph = this;

    this.Presentation = function() { };

    this.Presentation.GraphElement = function() { };
    this.Presentation.GraphElement.prototype = new Chart.Common.Graphic.GraphElement();
    this.Presentation.GraphElement.prototype.updateSelection = function(sender, left, right) { };
	this.Presentation.GraphElement.prototype.resize = function(width,height){
        if (this.canvas) {
            this.canvas.width = width;
            this.canvas.height = height;
            $(this.canvas).css({
                width: width,
                height: height
            });
            _canvasWidth = width;
            _canvasHeight = height;
        }
		this.resizeComponents(width, height);
	};

    this.Presentation.GraphArea = function() {
        this.canvas = mainGraph._graphCanvas;
        this.ctx = this.canvas.getContext("2d");
    };
    this.Presentation.GraphArea.prototype = new this.Presentation.GraphElement();

    this.Presentation.CoordinateArea = function() {
        this.canvas = mainGraph._coordinateCanvas;
        this.labelContainer = mainGraph._coordinateLabelCanvas;
        this.ctx = this.canvas.getContext("2d");

        this.Y_LABLE_OFFSET = 1;
        this._xMinLabelSpace = this.getXMinLabelSpace();
        this._labelBottomMargin = 5;

        this._strokeThickness = 1;
        this._strokeColor = "#7E7E7E";

        this._numberSetting = { decimalCount: 2, shortened: true };
    };
    this.Presentation.CoordinateArea.prototype = new this.Presentation.GraphElement();
    this.Presentation.CoordinateArea.prototype.getXMinLabelSpace = function() {
        return $.TextStudio.getTextMeasure(
            LocalizationManager.instance.getDateFormat(
                Chart.Common.Util.DataFrequency.Daily,
                Globalization.DateFormatType.Normal),
            this.labelContainer, "dateslider").width * 1.2;
    };
    this.Presentation.CoordinateArea.prototype.getXMaxMarkCount = function() {
        return Math.floor(this.getWidth() / this._xMinLabelSpace);
    };
    this.Presentation.CoordinateArea.prototype.resizeComponents = function(width, height) {
        this.labelContainer.width = width;
        this.labelContainer.height = height;
        $(this.labelContainer).css({ width: width, height: height });
    };
    this.Presentation.CoordinateArea.prototype.refresh = function() {
        this.makeCoordinate();
    };
    this.Presentation.CoordinateArea.prototype.reset = function() {
        this.ctx.clearRect(0, 0, this.getWidth(), this.getHeight());
        $(this.labelContainer).html("");
    };
    this.Presentation.CoordinateArea.prototype.makeCoordinate = function() {
        this.reset();
        //// this should be recalculate every time because the component may be resized in runtime
        var maxLableCount = this.getXMaxMarkCount();

        var dateRange = mainGraph.xAxisMapping.getValueRange();

        var frequency = Chart.Common.Data.TimeSeries.TSDataSlicer.getSliceFrequency(
                    maxLableCount, dateRange.first.dateDiff("d", dateRange.second) + 1);
        var subScaleFrequency = this.getSubScaleFrequency(frequency);

        var xMarkData = Chart.Common.Data.TimeSeries.TSUtil.createDateTimeMarks(
                dateRange.first, dateRange.second, frequency);
        var markDataSubScale = subScaleFrequency == null ? null : Chart.Common.Data.TimeSeries.TSUtil.createDateTimeMarks(
                dateRange.first, dateRange.second, subScaleFrequency);

        if (xMarkData == null || xMarkData.length < 1) { return; }

        var graphics = new $.Graphics(this.ctx);
        graphics.begin();
        graphics.setLineStyle(this._strokeThickness, this._strokeColor);

        var dateFormat = LocalizationManager.instance.getDateFormat(
                frequency.frequency, Globalization.DateFormatType.Normal);

        var me = this;

        if (markDataSubScale != null) {
            $(markDataSubScale).each(function() {
                var x = Math.floor(mainGraph.xAxisMapping.getCoordinate(this)) + me._strokeThickness * 0.5;
                graphics.drawLine(x, me.getHeight() - 4, x, me.getHeight());
            });
        }

        var lastposition = 0;
        var textSize = $.TextStudio.getTextMeasure(
            LocalizationManager.instance.formatDate(xMarkData[0], dateFormat),
            me.labelContainer, "dateslider");
        var textTop = this.getHeight() - this._labelBottomMargin - textSize.height;
        $(xMarkData).each(function() {
            var x = Math.floor(mainGraph.xAxisMapping.getCoordinate(this)) + me._strokeThickness * 0.5;
            var text = LocalizationManager.instance.formatDate(this, dateFormat);
            if ((x - textSize.width - 4) > lastposition) {
                $.TextStudio.create(
                        text,
                        me.labelContainer,
                        "absolute",
                        x - textSize.width - 4,
                        textTop,
                        null,
                        null,
                        "dateslider");
            }
            graphics.drawLine(x, 0, x, me.getHeight());
            lastposition = x;
        });
        graphics.end();
    };
    this.Presentation.CoordinateArea.prototype.getSubScaleFrequency = function(frequencyEx) {
        if (frequencyEx.count > 1) { return new Chart.Common.Util.DataFrequencyEx(frequencyEx.frequency, 1); }
        switch (frequencyEx.frequency) {
            case Chart.Common.Util.DataFrequency.Annually:
                return new Chart.Common.Util.DataFrequencyEx(Chart.Common.Util.DataFrequency.Quarterly, 1);
            case Chart.Common.Util.DataFrequency.Quarterly:
                return new Chart.Common.Util.DataFrequencyEx(Chart.Common.Util.DataFrequency.Monthly, 1);
            case Chart.Common.Util.DataFrequency.Monthly:
                return new Chart.Common.Util.DataFrequencyEx(Chart.Common.Util.DataFrequency.Weekly, 1);
            case Chart.Common.Util.DataFrequency.Weekly:
                return new Chart.Common.Util.DataFrequencyEx(Chart.Common.Util.DataFrequency.Daily, 1);
            default:
                return null;
        }
    };

    this.Presentation.DragHandler = function() {
        this.canvas = mainGraph._scrollbarCanvas;

        this.MOUSE_MOVING_SENSITY = 1;
        this.TIMER_INTERVAL = 200;

        var _leftBorder = mainGraph._sliderLeftCanvas;
        var _rightBorder = mainGraph._sliderRightCanvas;
        var _middleArea = mainGraph._sliderCanvas;
        var _middleCtx = _middleArea ? _middleArea.getContext("2d") : null;
        var _middleGraphics = _middleCtx ? new $.Graphics(_middleCtx) : null;
        var _currentObject = null;

        var _leftArrow = null;
        var _rightArrow = null;

        var _isDragging = false;
        var _needUpdateSelection = false;
        var _lastPositionX;
        var _newPositionX;
        var _radius;
        var _virtualLeftBorder;
        var _virtualRightBorder;

        var _timer = null;

        var me = this;

        this.getLeft = function() { return Math.floor($(_leftBorder).position().left + mainGraph.BORDER_RADIUS); };
        this.getRight = function() { return Math.floor($(_rightBorder).position().left + mainGraph.BORDER_RADIUS); };
        this.setLeft = function(position) {
            if (position < 0)
                position = 0;
            if (position > this.getWidth())
                position = this.getWidth();

            $(_leftBorder).css({ left: position - mainGraph.BORDER_RADIUS });
            this.updateMiddleArea();
        };
        this.setRight = function(position) {
            if (position < 0)
                position = 0;
            if (position > this.getWidth())
                position = this.getWidth();

            $(_rightBorder).css({ left: position - mainGraph.BORDER_RADIUS });
            this.updateMiddleArea();
        };

        this.updateMiddleArea = function() {
            if (!_middleArea) return;
            var width = this.getRight() - this.getLeft();

            var arg = $(_middleArea);

            if (width < 0) {
                _middleArea.width = -width + 1;
                arg.css({ left: this.getLeft() + width, width: -width + 1 });
                //                _oMiddleAreaBackground.Width = _oMiddleArea.Width;
                //                this._oMiddleAreaTopLine.X1 = AdjustLinePos(this.Left + width);
                //                this._oMiddleAreaTopLine.X2 = AdjustLinePos(this.Left + width + this._oMiddleArea.Width);

                this.updateMiddleBorder();
            }
            else {
                _middleArea.width = width + 1;
                arg.css({ left: this.getLeft(), width: width + 1 });
                //                _oMiddleAreaBackground.Width = _oMiddleArea.Width;
                //                this._oMiddleAreaTopLine.X1 = AdjustLinePos(this.Left);
                //                this._oMiddleAreaTopLine.X2 = AdjustLinePos(this.Left + this._oMiddleArea.Width);

                this.updateMiddleBorder();
            }
        };
        this.updateMiddleBorder = function() {
            if (!_middleArea) return;
            var arg = $(_middleArea);
            var width = arg.width();
            var height = arg.height();
            var bottom = this.getHeight();
            var top = bottom - mainGraph.SCROLLBAR_HEIGHT;
            _middleCtx.clearRect(0, 0, width, height);

            //            _middleGraphics.setNormalFill($.color.parse("#44FFFFFF").toString());
            //            _middleGraphics.drawRectangle(0.5, 0.5, me.getWidth(), me.getHeight());

            _middleGraphics.setNormalFill("#FFFFFF");
            _middleGraphics.drawRectangle(0, top + 0.5, this.getWidth(), mainGraph.SCROLLBAR_HEIGHT - 1);
            _middleGraphics.setNoneFill();
            _middleGraphics.setLineStyle(0.4, "#A0A0A0");
            _middleGraphics.drawRectangle(0, top + 0.5, this.getWidth(), mainGraph.SCROLLBAR_HEIGHT - 1);

            _middleGraphics.begin();
            _middleGraphics.setLineStyle(1, "#000000");
            _middleGraphics.drawLine(0.5, 0, 0.5, height);
            //            _middleGraphics.setLineStyle(1, "#FF0000");
            _middleGraphics.drawLine(adjustLinePos(width - 1), 0, adjustLinePos(width - 1), height);
            _middleGraphics.end();
            _middleGraphics.begin();
            _middleGraphics.setLineStyle(1, "#D0D0D0");
            _middleGraphics.drawLine(1, 0.5, width - 1, 0.5);
            _middleGraphics.end();

            //$("#mouseTip").html(String.format("width: {0}, left: {1}, rightBorder: {2}", width, this.getLeft(), adjustLinePos(width - 1)));
        };
		this.updateHandlerPosition = function(width, height){
			_leftBorder.height = height;
			$(_leftBorder).css({
				height: height
			});
			
			_rightBorder.height = height;
			$(_rightBorder).css({
				height: height
			});
			
			_middleArea.height = height;
			$(_middleArea).css({
				height: height
			});
			
			_leftArrow.setArrowPosition(-2, height / 2 - mainGraph.LEFT_MARGIN / 2);
			_rightArrow.setArrowPosition(-2, height / 2 - mainGraph.LEFT_MARGIN / 2);
		};


        var savedhandlers = {};

        this.onBeginDrag = function(e) {
            _currentObject = getRectangleUnderMouse(e);
            if (_currentObject != null) {
                //_slider.LayoutRoot.CaptureMouse();
                _isDragging = true;
                //e.Handled = true;

                // cancel out any text selections
                document.body.focus();

                // prevent text selection and drag in old-school browsers
                if (document.onselectstart !== undefined && savedhandlers.onselectstart == null) {
                    savedhandlers.onselectstart = document.onselectstart;
                    document.onselectstart = function() { return false; };
                }
                if (document.ondrag !== undefined && savedhandlers.ondrag == null) {
                    savedhandlers.ondrag = document.ondrag;
                    document.ondrag = function() { return false; };
                }

                if (_currentObject == _middleArea) {
                    _lastPositionX = $.getPosition(this.canvas, e).x;
                    _virtualLeftBorder = this.getLeft();
                    _virtualRightBorder = this.getRight();
                }
                mainGraph._presentation.updateSelectionBegin(this, this.Left, this.Right);
                if (mainGraph.isImmediately)
                    _timer = setInterval(executeUpdateSelection, this.TIMER_INTERVAL);
            }
            //            else {
            //                $("#mouseTip").html("......");
            //            }
        };
        this.onEndDrag = function(e) {
            if (!_isDragging) { return; }
            _isDragging = false;
            // revert drag stuff for old-school browsers
            if (document.onselectstart !== undefined)
                document.onselectstart = savedhandlers.onselectstart;
            if (document.ondrag !== undefined)
                document.ondrag = savedhandlers.ondrag;

            //e.Handled = true;
            //_slider.LayoutRoot.ReleaseMouseCapture();
            if (mainGraph.isImmediately)
                clearInterval(_timer);
            executeUpdateSelection();
            mainGraph._presentation.updateSelectionEnd(this, this.Left, this.Right);
        };
        this.setCurrentHandlerPosition = function(e) {

            //var pos = $.getPosition(this.canvas, e);
            //$("#mouseTip").html(pos.x + ", " + pos.y);

            if (!_isDragging) { return; }
            _newPositionX = Math.floor($.getPosition(this.canvas, e).x);

            // drag the middle part
            if (_currentObject == _middleArea) {
                var offset = _newPositionX - _lastPositionX;
                if (Math.abs(offset) < this.MOUSE_MOVING_SENSITY) { return; }
                _virtualLeftBorder += offset;
                this.setLeft(_virtualLeftBorder);
                _virtualRightBorder += offset;
                if (_virtualRightBorder > this.getWidth() - 1) {
                    _virtualRightBorder = this.getWidth() - 1;
                }
                this.setRight(_virtualRightBorder);

                _lastPositionX = _newPositionX;
            }
            // drag one of the borders
            else {
                if (_newPositionX > this.getWidth() - 1) {
                    _newPositionX = this.getWidth() - 1;
                }
                if (_newPositionX < 0) {
                    _newPositionX = 0;
                }

                var currentPos = $(_currentObject).position().left;
                if (Math.abs(currentPos - (_newPositionX - mainGraph.BORDER_RADIUS)) < this.MOUSE_MOVING_SENSITY) { return; }
                $(_currentObject).css({ left: _newPositionX - mainGraph.BORDER_RADIUS });

                if (this.getLeft() > this.getRight()) {
                    var temp = this.getLeft();
                    this.setLeft(this.getRight());
                    this.setRight(temp);
                    _currentObject = _currentObject == _leftBorder
                        ? _rightBorder : _leftBorder;
                }
                this.updateMiddleArea();
            }

            //ChartLogger.write("_newPositionX = " + _newPositionX);

            //The timer will ask the presentation manager to refresh periodically. by Call ExecuteUpdateSelection
            _needUpdateSelection = true;
            //don't need this again, for all elements about slider are control in draghandler.
            //mainGraph._presentation.updateSelection(this, this.getLeft(), this.getRight());
        };

        function executeUpdateSelection() {
            if (_needUpdateSelection) {
                mainGraph._presentation.requireUpdateSelection(me, me.getLeft(), me.getRight());
                _needUpdateSelection = false;
            }
        }
        function getRectangleUnderMouse(e) {
            var ptA = $.getPosition(_leftBorder, e);
            var ptB = $.getPosition(_rightBorder, e);

            var leftObj = $(_leftBorder);
            var rightObj = $(_rightBorder);
            var midObj = $(_middleArea);

            if ((ptA.x > leftObj.width() && ptB.x < 0) || (ptA.x < 0 && ptB.x > rightObj.width())
                && ptA.y >= 0 && ptA.y <= midObj.height()) {
                return _middleArea;
            }

            if (ptA.x >= 0 && ptA.x <= leftObj.width() && ptA.y >= 0 && ptA.y <= leftObj.height()) {
                return _leftBorder;
            }

            var ptArrowA = $.getPosition(_leftArrow.getArrowCanvas(), e);
            if (ptArrowA.x >= 0 && ptArrowA.x <= _leftArrow.getArrowWidth() * 2 + _leftArrow.getArrowSpace() &&
                ptArrowA.y >= 0 && ptArrowA.y <= _leftArrow.getArrowHeight()) {
                return _leftBorder;
            }

            if (ptB.x >= 0 && ptB.x <= rightObj.width() && ptB.y >= 0 && ptB.y <= rightObj.height()) {
                return _rightBorder;
            }

            var ptArrowB = $.getPosition(_rightArrow.getArrowCanvas(), e);
            if (ptArrowB.x >= 0 && ptArrowB.x <= _rightArrow.getArrowWidth() * 2 + _rightArrow.getArrowSpace() &&
                ptArrowB.y >= 0 && ptArrowB.y <= _rightArrow.getArrowHeight()) {
                return _rightBorder;
            }

            return null;
        }
        function adjustLinePos(pos) {
            if (isNaN(pos)) { return NaN; }
            return Math.floor(pos) + 0.5;
        }
        function initializeEx() {
            _leftArrow = new doubleArrowControl(_leftBorder);
            _leftArrow.setArrowVisibility(arrowVisibilityType.OnlyLeft);
            _leftArrow.setArrowSize(mainGraph.LEFT_MARGIN, mainGraph.LEFT_MARGIN, _leftArrow.getArrowSpace());
            _leftArrow.setArrowPosition(-2, me.getHeight() / 2 - mainGraph.LEFT_MARGIN / 2);
            _rightArrow = new doubleArrowControl(_rightBorder);
            _rightArrow.setArrowVisibility(arrowVisibilityType.OnlyRight);
            _rightArrow.setArrowSize(mainGraph.LEFT_MARGIN, mainGraph.LEFT_MARGIN, _leftArrow.getArrowSpace());
            _rightArrow.setArrowPosition(-2, me.getHeight() / 2 - mainGraph.LEFT_MARGIN / 2);
            //$(_middleArea).css({ 'background-color': $.color.parse("#44FF0000").toString() });

            $(_leftBorder).css({ cursor: "w-resize" });
            $(_rightBorder).css({ cursor: "w-resize" });
        }

        initializeEx();
    };
    this.Presentation.DragHandler.prototype = new this.Presentation.GraphElement();
    this.Presentation.DragHandler.prototype.updateSelection = function(sender, left, right) {
        //        if (sender != this)
        //            {
        //                this._oLeftBorder.SetValue(Canvas.LeftProperty, Math.Max(-_radius, left - _radius));
        //                this._oRightBorder.SetValue(Canvas.LeftProperty, Math.Max(-_radius, right - _radius));
        //                
        //                double leftPos = Math.Max(0, left);
        //                this._oMiddleArea.SetValue(Canvas.LeftProperty, leftPos);
        //                this._oMiddleArea.Width = Math.Max(0, right - left);

        //                double rightPos = leftPos + this._oMiddleArea.Width;
        //                
        //                this._oMiddleAreaBackground.Width = this._oMiddleArea.Width;

        //                UpdateMiddleBorder();

        //                this._oMiddleAreaTopLine.X1 = AdjustLinePos(leftPos);
        //                this._oMiddleAreaTopLine.X2 = AdjustLinePos(rightPos);
        //            }
        if (sender != this) {
            this.setLeft(left);
            this.setRight(right);
        }
    };
    this.Presentation.DragHandler.prototype.resizeComponents = function(width, height){
		this.updateHandlerPosition(width, height);
	};
    this.Presentation.DragHandler.prototype.reset = function() {
        this.setLeft(0);
        this.setRight(this.getWidth());
    };

    this.Presentation.Scrollbar = function() {
        this.canvas = mainGraph._scrollbarCanvas;
        this.ctx = this.canvas.getContext("2d");

        this.drawSlot = function(width,height) {
            this.ctx.clearRect(0, 0, width, height);
            var graphics = new $.Graphics(this.ctx);
            var bottom = height;
            var top = bottom - mainGraph.SCROLLBAR_HEIGHT;
            var lingrad = this.ctx.createLinearGradient(0, top, 0, bottom);
            lingrad.addColorStop(0, $.color.parse("#7E7E7E").toString());
            lingrad.addColorStop(0.6, $.color.parse("#FFFFFF").toString());
            graphics.setGradientFill(lingrad);
            graphics.drawRectangle(0, top + 0.5, width, mainGraph.SCROLLBAR_HEIGHT - 1);
            graphics.setNoneFill();
            graphics.setLineStyle(0.4, $.color.parse("#A0A0A0").toString());
            graphics.drawRectangle(0, top + 0.5, width, mainGraph.SCROLLBAR_HEIGHT - 1);
            graphics.begin();
            graphics.setLineStyle(1, $.color.parse("#000000").toString());
            graphics.drawLine(0, 0.5, width, 0.5);
            graphics.end();
        };

        this.drawSlot(this.getWidth(),this.getHeight());
    };
    this.Presentation.Scrollbar.prototype = new this.Presentation.GraphElement();
    this.Presentation.Scrollbar.prototype.resizeComponents = function(width, height){
		this.drawSlot(width, height)
	};
    this.Presentation.Scrollbar.prototype.reset = function() { };

    this.Presentation.PresentationManager = function() {
        this._coordinate = null;
        this._graphArea = null;
        this._dragHandler = null;
        this._scrollbar = null;

        this._updateSelectionArgsData = new Chart.Common.Command.Args.UpdateSelectionArgs(0, 0);
        this._updateSelectionArgs = new Chart.Common.Command.CommandArgs(
            this,
            Chart.Common.Command.Commands.UPDATE_SELECTION,
            this._updateSelectionArgsData,
            Chart.Common.Command.CommandDirection.ToRoot);

        var createElement = function(){
			var canvasWidth = mainGraph._placeHolder.width();
			var canvasHeight = mainGraph._placeHolder.height();
			mainGraph._scrollbarCanvas = $.Canvas.create(mainGraph._placeHolder, "relative", 0, 0, canvasWidth, canvasHeight);
			mainGraph._graphCanvas = $.Canvas.create(mainGraph._placeHolder, "absolute", 0, 0, canvasWidth, canvasHeight - mainGraph.SCROLLBAR_HEIGHT);
			mainGraph._coordinateCanvas = $.Canvas.create(mainGraph._placeHolder, "absolute", 0, 0, canvasWidth, canvasHeight - mainGraph.SCROLLBAR_HEIGHT);
			mainGraph._coordinateLabelCanvas = $.Canvas.createDiv(mainGraph._placeHolder, "absolute", 0, 0, canvasWidth, canvasHeight - mainGraph.SCROLLBAR_HEIGHT);
			mainGraph._sliderCanvas = $.Canvas.create(mainGraph._placeHolder, "absolute", 0, 0, canvasWidth, canvasHeight);
			//mainGraph._eventCanvas = $.Canvas.create(
			//                mainGraph._placeHolder, "absolute", 0, 0, canvasWidth, canvasHeight);
			mainGraph._sliderLeftCanvas = $.Canvas.createDiv(mainGraph._placeHolder, "absolute", -mainGraph.BORDER_RADIUS, 0, mainGraph.BORDER_RADIUS * 2, canvasHeight);
			mainGraph._sliderRightCanvas = $.Canvas.createDiv(mainGraph._placeHolder, "absolute", -mainGraph.BORDER_RADIUS, 0, mainGraph.BORDER_RADIUS * 2, canvasHeight);
			//mainGraph._scrollbarCanvas
		};

        createElement();
        this.canvas = target.get(0);
    };
    this.Presentation.PresentationManager.prototype = $.extend(new Chart.Common.Command.CommandHandler(),new this.Presentation.GraphElement(),{
		addEventHandler: function(){
			var me = this;
			target.mousemove(function(e){
				me.onDragging.apply(me, [e]);
			});
			//target.mouseup(function(e) { me.onEndDrag.apply(me, [e]); });
			target.mousedown(function(e){
				me.onBeginDrag.apply(me, [e]);
			});
		},
		initailizeCoordinateMapping: function(){
			if (mainGraph.showSnapshot && this._graphArea) {
			
				var xrange = {
					first: new Date(1900, 0, 1),
					second: new Date(1900, 0, 1)
				};
				var yrange = {
					first: 0,
					second: 0
				};
				
				this._graphArea.getRange(xrange, yrange);
				
				mainGraph.yAxisMapping.setCoordinateRange({
					first: this._graphArea.getHeight() - 2,
					second: 2
				});
				mainGraph.yAxisMapping.setValueRange(yrange);
			}
			mainGraph.xAxisMapping.setCoordinateRange({
				first: 0,
				second: this._scrollbar.getWidth() - 1
			});
		},
		applySetting: function(setting){
			var bgSetting = {};
			if (Chart.Setting.Presentation.BG.tryDeSerialize(setting, Chart.Setting.SettingItem.Chart, bgSetting)) {
				mainGraph._placeHolder.css({
					"background-color": bgSetting.color
				});
			}
			this._coordinate.applySetting(setting);
			this._scrollbar.applySetting(setting);
			if (mainGraph.showSnapshot && this._graphArea) 
				this._graphArea.applySetting(setting);
		},
		refresh: function(){
			var me = this;
			this.initailizeCoordinateMapping();
			setTimeout(function(){
				me._coordinate.refresh();
				me._scrollbar.refresh();
				if (mainGraph.showSnapshot && me._graphArea) 
					me._graphArea.refresh();
			}, 10);
		},
		clearAll: function(){
			this._coordinate.reset();
			this._dragHandler.reset();
			this._scrollbar.reset();
			if (this._graphArea) 
				this._graphArea.reset();
		},
		resizeComponents: function(width, height){
			var actuallyWidth = width - 2 * mainGraph.LEFT_MARGIN;
			var contentHeight = height - mainGraph.SCROLLBAR_HEIGHT;
			mainGraph._placeHolder[0].width = actuallyWidth;
			mainGraph._placeHolder[0].height = height;
			mainGraph._placeHolder.css({
				width: actuallyWidth,
				height: height
			});
			this._dragHandler.resize(actuallyWidth, height);
			this._coordinate.resize(actuallyWidth, contentHeight);
			this._scrollbar.resize(actuallyWidth, height);
			if (this._graphArea) {
				this._graphArea.resize(actuallyWidth, contentHeight);
			}
		},
		updateSelection: function(sender, left, right){
			// make sure left/right has valid value.
			left = Math.max(0, left);
			left = Math.min(this.getWidth(), left);
			
			right = Math.max(0, right);
			right = Math.min(this.getWidth(), right);
			
			this._coordinate.updateSelection(sender, left, right);
			this._dragHandler.updateSelection(sender, left, right);
			this._scrollbar.updateSelection(sender, left, right);
			if (this._graphArea) {
				this._graphArea.updateSelection(sender, left, right);
			}
		},
		updateSelectionBegin: function(sender, left, right){
			var me = this;
			//target.mouseup(function(e) { me.onEndDrag.apply(me, [e]); });
			$(document).one("mouseup", function(e){
				me.onEndDrag.apply(me, [e]);
			});
			
		},
		updateSelectionEnd: function(sender, left, right){
		},
		requireUpdateSelection: function(sender, left, right){
			this.updateSelection(sender, left, right);
			
			this._updateSelectionArgsData.startIndex = Chart.Common.Util.DateUtil.getDateIndex(mainGraph.xAxisMapping.getDate(left));
			this._updateSelectionArgsData.endIndex = Chart.Common.Util.DateUtil.getDateIndex(mainGraph.xAxisMapping.getDate(right));
			this.executeCommand(this._updateSelectionArgs);
		},
		updateTimeRange: function(startDate, endDate){
			var range = mainGraph.xAxisMapping.getValueRange();
			if (range.first != startDate || range.second != endDate) {
				range.first = startDate;
				range.second = endDate;
				return true;
			}
			return false;
		},
		getCurrentSelection: function(startDate, endDate){
			var left = 0;
			var right = 0;
			var timeSelection = mainGraph._datasource.getCurrentSelection ? mainGraph._datasource.getCurrentSelection() : null;
			if (timeSelection && timeSelection.second >= timeSelection.first) {
				left = mainGraph.xAxisMapping.getCoordinate(timeSelection.first);
				right = mainGraph.xAxisMapping.getCoordinate(timeSelection.second);
			}
			else {
				var coorRange = mainGraph.xAxisMapping.getCoordinateRange();
				left = coorRange.first;
				right = coorRange.second;
			}
			this.updateSelection(this, left, right);
		},
		getHandler: function(args){
			switch (args.command) {
				case Chart.Common.Command.Commands.APPLY_CHART_SETTING:
					return this._onApplyChartSetting;
				case Chart.Common.Command.Commands.REFRESH_PRESENTATION:
					return this.onRefreshPresentation;
				case Chart.Common.Command.Commands.RESIZE:
					return this.onResize;
				case Chart.Common.Command.Commands.INITIALIZE:
					return this.onInitialize;
				case Chart.Common.Command.Commands.COMPONENT_STATUS_UPDATE:
					return this.onComponentStatusUpdate;
				case Chart.Common.Command.Commands.UPDATE_SELECTION:
					return this.onUpdateSelection;
				case Chart.Common.Command.Commands.UPDATE_TIME_RANGE:
					return this.onUpdateTimeRange;
				default:
					return null;
			}
		},
		_onApplyChartSetting: function(args){
			if (args && args.data && args.data.setting) {
				this.applySetting(args.data.setting);
				//this.refresh();
			}
		},
		onBeginDrag: function(e){
			this._dragHandler.onBeginDrag(e);
		},
		onEndDrag: function(e){
			this._dragHandler.onEndDrag(e);
		},
		onDragging: function(e){
			this._dragHandler.setCurrentHandlerPosition(e);
		},
		onInitialize: function(args){
			this._coordinate = new mainGraph.Presentation.CoordinateArea();
			this._dragHandler = new mainGraph.Presentation.DragHandler();
			this._scrollbar = new mainGraph.Presentation.Scrollbar();
			
			if (mainGraph.showSnapshot) 
				this._graphArea = new mainGraph.Presentation.GraphArea();
			
			this.addEventHandler();
		},
		onRefreshPresentation: function(args){
			if (args) {
				if (!mainGraph._datasource.getTimeRange) 
					return;
				var timeRange = mainGraph._datasource.getTimeRange();
				if (timeRange && timeRange.second >= timeRange.first) {
					this.updateTimeRange(timeRange.first, timeRange.second);
					// refresh the content
					this.refresh();
					// update the selection status
					this.getCurrentSelection();
				}
			}
		},
		onResize: function(args){
			if (args && args.data && args.data.width && args.data.height) {
				this.resize(args.data.width, args.data.height);
			}
			this.refresh();
		},
		onUpdateSelection: function(args){
			if (args && args.data && args.data.startIndex && args.data.endIndex) {
				var left = mainGraph.xAxisMapping.getCoordinate(Chart.Common.Util.DateUtil.getDateFromIndex(args.data.startIndex));
				var right = mainGraph.xAxisMapping.getCoordinate(Chart.Common.Util.DateUtil.getDateFromIndex(args.data.endIndex));
				this.updateSelection(args.sender, left, right);
			}
		},
		onUpdateTimeRange: function(args){
			if (args && args.data && args.data.startIndex && args.data.endIndex) {
				if (this.updateTimeRange(Chart.Common.Util.DateUtil.getDateFromIndex(args.data.startIndex), Chart.Common.Util.DateUtil.getDateFromIndex(args.data.endIndex))) {
					// refresh the content
					this.refresh();
				}
			}
		},
		onComponentStatusUpdate: function(args){
			if (args && args.data && args.data.status) {
				switch (args.data.status) {
					case Chart.Common.Command.ComponentStatus.ClearAll:
						this.clearAll();
						break;
					default:
						break;
				}
			}
		}	
	});
    
    var arrowVisibilityType = {
        None: 0x00,
        OnlyLeft: 0x01,
        OnlyRight: 0x02,
        Both: 0x01 | 0x02
    };

    var doubleArrowControl = function(target) {
        var _arrowHeight = 8;
        var _arrowWidth = 8;
        var _arrowSpace = 2;
        var _arrowVisibility = arrowVisibilityType.Both;

        this.getArrowWidth = function() { return _arrowWidth; };
        this.getArrowHeight = function() { return _arrowHeight; };
        this.getArrowSpace = function() { return _arrowSpace; };
        this.getArrowCanvas = function() { return _canvas; };

        this.setArrowVisibility = function(visibility) {
            if (_arrowVisibility != visibility) {
                _arrowVisibility = visibility;
                refresh();
            }
        };
        this.setArrowSize = function(width, height, space) {
            if (width)
                _arrowWidth = width;
            if (height)
                _arrowHeight = height;
            if (space)
                _arrowSpace = space;
            refresh();
        };
        this.setArrowPosition = function(x, y) {
            $(_canvas).css({ left: x, top: y });
        };

        var getWidth = function() { return _arrowWidth * 2 + _arrowSpace };
        var getHeight = function() { return _arrowHeight };
        var refresh = function() {
            //Points="6,0  6,8  0,4" 
            //        W,0  W,H  0,H/2
            //
            //Points="8,  0  8,  8  14,   4"
            //        W+S,0  W+S+W,H  W+S+W,H/2
            _canvas.width = getWidth();
            _canvas.height = getHeight();
            $(_canvas).css({ width: getWidth(), height: getHeight() });
            _ctx.clearRect(0, 0, getWidth(), getHeight());
            _graphics.begin();
            if ((_arrowVisibility & arrowVisibilityType.OnlyLeft) != 0) {
                var ptC = [];
                ptC.push({ x: 0, y: 0 });
                ptC.push({ x: 0, y: _arrowHeight });
                ptC.push({ x: _arrowWidth, y: _arrowHeight / 2 });
                _graphics.drawPolygon(ptC);
            }
            if ((_arrowVisibility & arrowVisibilityType.OnlyRight) != 0) {
                var ptC = [];
                ptC.push({ x: _arrowWidth + _arrowSpace + _arrowWidth, y: 0 });
                ptC.push({ x: _arrowWidth + _arrowSpace + _arrowWidth, y: _arrowHeight });
                ptC.push({ x: _arrowWidth + _arrowSpace, y: _arrowHeight / 2 });
                _graphics.drawPolygon(ptC);
            }
            _graphics.end();
        };

        var _canvas = $.Canvas.create(
            target, "relative", 0, 0, getWidth(), getHeight());
        var _ctx = _canvas.getContext("2d");
        var _graphics = new $.Graphics(_ctx);
        _graphics.setNormalFill($.color.make(0, 0, 0, 1));

        refresh();
        return this;
    };

    target.css({ "position": "relative", "background-color": "transparent", "cursor": "default" });
    this._placeHolder = $($.Canvas.createDiv(
            target, "relative",
            this.LEFT_MARGIN, 0,
            target.width() - this.LEFT_MARGIN * 2, target.height()));

    this._presentation = new this.Presentation.PresentationManager();
};
Chart.Component.DateSlider.prototype = $.extend(new Chart.Common.Command.CommandHandler(),{
	defaultHandler: function(args){
		//do nothing here.
	},
	getHandler: function(args){
		return this.defaultHandler;
	},
	collectionChildren: function(){
		this.interactiveChildren = [this._presentation];
		this._presentation.parentContainer = this;
	},
	setDataSource: function(datasource){
		this._datasource = datasource;
	},
	resize: function(width, height){
		this._presentation.resize(width, height);
		this._presentation.refresh();
		this._presentation.getCurrentSelection();
	}
});