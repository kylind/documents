Chart.Interface.HBSMInterface = function(){
};
Chart.Interface.HBSMInterface.prototype = {
    /*
     * get ownership zone date dictionary, the key value is the pid of funds.
     * @param none
     * @return {Dictionary<string, OwnerShipZoneRawData>}
     */
    getOwnerShipZoneRawData: function(){
        return null;
    },
    /*
     * get funds' holding weight list.
     * @param none
     * @return {Dictionary<string, Dictionary<string, SingleHoldingData>>}
     */
    getHoldingWeightData: function(){
        return null;
    },
    /*
     * get holding's position data
     * @param investmentId {string} target investment.
     * @param holdingId {string} target holding id.
     * @return {OwnerShipZoneRawData}
     */
    getHoldingOwnerShipZoneRawData: function(investmentId, holdingId){
        return null;
    },
    /*
     * get horizonal and vertical labels
     * @param none
     * @return {{h:[],v:[]}}
     * @require no
     */
    getGridLabels: function(){
        return null;
    }
};

Chart.Component.HBSMGraph = function(target, displayType){
    this._displayType = displayType;
    this._placeHolder = target;
    this._placeHolder.css({
        "position": "relative",
        "background-color": "transparent",
        "cursor": "default"
    });
    this._margin = {
        left: 0,
        top: 0,
        right: 20,
        bottom: 20
    };
    this._hLabels = ["Deep Value", "Value", "Blend", "Growth", "Deep Growth"];
    this._vLabels = ["Micro", "Small", "Medium", "Large", "Giant"];
    this._datasource = null;
    //this._tooltipFactory = new Chart.Common.Controls.GraphRectTipFactory(target.attr("cid"));
    
    this._graphCanvas = null;
    this._coordinateCanvas = null;
    this._tooltipCanvas = null;
    this._messageCanvas = null;
    
    this.xAxisMapping = new Chart.Common.Coordinate.Double2DoubleLinearMapping();
    this.yAxisMapping = new Chart.Common.Coordinate.Double2DoubleLinearMapping();
    
    var mainGraph = this;
    
    this.Presentation = function(){
    };
    
    this.Presentation.GraphElement = function(){
    };
    this.Presentation.GraphElement.prototype = $.extend(new Chart.Common.Graphic.GraphElement(), {});
    
    this.Presentation.CoordinateArea = function(){
		this.canvas = mainGraph._coordinateCanvas;
		this.canvasRef = $(this.canvas);
		this.outerRect = null;
		this.innerRect = null;
		this.lineLayer = null;
		this.labelLayer = null;
		this.ctx = null;
		
		this._bgColor = "#F2F2F2";
		this._bgInnerColor = "#FFFFFF";
		this._outerLineColor = "#D7D7D7";
		this._innerLineColor = "#969696";
		this._deg2radians = Math.PI * 2 / 360;
		
		this.LABEL_OFFSET = 4;
		
		var me = this;
		
		var _createElement = function(){
			var graphSize = {
				width: me.getWidth() - mainGraph._margin.left - mainGraph._margin.right,
				height: me.getHeight() - mainGraph._margin.top - mainGraph._margin.bottom
			};
			me.outerRect = $.Canvas.createDiv(me.canvasRef, "relative", mainGraph._margin.left, mainGraph._margin.top, graphSize.width, graphSize.height);
			me.innerRect = $.Canvas.createDiv($(me.outerRect), "absolute", 0, 0, graphSize.width, graphSize.height);
			me.lineLayer = $.Canvas.create($(me.outerRect), "absolute", 0, 0, graphSize.width, graphSize.height);
			me.labelLayer = $.Canvas.createDiv(me.canvasRef, "absolute", 0, 0, me.getWidth(), me.getHeight());
			me.ctx = me.lineLayer.getContext("2d");
			$(me.outerRect).css({
				"background-color": me._bgColor
			});
			$(me.innerRect).css({
				"background-color": me._bgInnerColor
			});
		};
		
		_createElement();
	};
    this.Presentation.CoordinateArea.prototype = $.extend(new this.Presentation.GraphElement(), {
        getRange: function(xrange, yrange){
            if (mainGraph._displayType == Chart.HBSMChart.DisplayType.Standard) {
                xrange.first = 0;
                xrange.second = 300;
                yrange.first = 0;
                yrange.second = 300;
            }
            else {
                xrange.first = -100;
                xrange.second = 400;
                yrange.first = -100;
                yrange.second = 400;
            }
        },
        resizeComponents: function(width, height){
            var graphSize = {
                width: width - mainGraph._margin.left - mainGraph._margin.right,
                height: height - mainGraph._margin.top - mainGraph._margin.bottom
            };
            this.labelLayer.width = width;
            this.labelLayer.height = height;
            this.outerRect.width = graphSize.width;
            this.outerRect.height = graphSize.height;
            this.lineLayer.width = graphSize.width;
            this.lineLayer.height = graphSize.height;
            $(this.labelLayer).css({
                width: width,
                height: height
            });
            $(this.outerRect).css({
                width: graphSize.width,
                height: graphSize.height
            });
            $(this.lineLayer).css({
                width: graphSize.width,
                height: graphSize.height
            });
        },
        refresh: function(){
            var d = +new Date();
            this._makeCoordinate();
            ChartLogger.instance.write("[time-consuming] time consuming of drawing ts coordinate: " + (new Date() - d));
        },
        reset: function(){
            this.ctx.clearRect(0, 0, this.getWidth(), this.getHeight());
            $(this.labelLayer).html("");
        },
        _makeCoordinate: function(){
            this.reset();
            if (mainGraph._displayType == Chart.HBSMChart.DisplayType.Standard) {
                this._makeStandardCoordinate();
            }
            else {
                this._makeExtendedCoordinate();
            }
        },
        _makeStandardCoordinate: function(){
			var xrange = mainGraph.xAxisMapping.getCoordinateRange();
            var yrange = mainGraph.yAxisMapping.getCoordinateRange();
            var xpos = {
                p1: Math.floor(mainGraph.xAxisMapping.getCoordinate(0)) + 0.5,
                p2: Math.floor(mainGraph.xAxisMapping.getCoordinate(100)) + 0.5,
                p3: Math.floor(mainGraph.xAxisMapping.getCoordinate(200)) + 0.5,
                p4: Math.floor(mainGraph.xAxisMapping.getCoordinate(300)) + 0.5
            };
            var ypos = {
                p1: Math.floor(mainGraph.yAxisMapping.getCoordinate(300)) + 0.5,
                p2: Math.floor(mainGraph.yAxisMapping.getCoordinate(200)) + 0.5,
                p3: Math.floor(mainGraph.yAxisMapping.getCoordinate(100)) + 0.5,
                p4: Math.floor(mainGraph.yAxisMapping.getCoordinate(0)) + 0.5
            };
            
            //update the size of inner rect.
            this.innerRect.width = xpos.p4 - xpos.p1;
            this.innerRect.height = ypos.p4 - ypos.p1;
            $(this.innerRect).css({
                left: xpos.p1,
                top: ypos.p1,
                width: (xpos.p4 - xpos.p1),
                height: (ypos.p4 - ypos.p1)
            });
            
            //draw inner grid line.
            var graphics = new $.Graphics(this.ctx);
            graphics.begin();
            graphics.setLineStyle(1, this._innerLineColor);
            graphics.drawLine(xpos.p1, ypos.p1, xpos.p4, ypos.p1);
            graphics.drawLine(xpos.p1, ypos.p2, xpos.p4, ypos.p2);
            graphics.drawLine(xpos.p1, ypos.p3, xpos.p4, ypos.p3);
            graphics.drawLine(xpos.p1, ypos.p4, xpos.p4, ypos.p4);
            graphics.drawLine(xpos.p1, ypos.p1, xpos.p1, ypos.p4);
            graphics.drawLine(xpos.p2, ypos.p1, xpos.p2, ypos.p4);
            graphics.drawLine(xpos.p3, ypos.p1, xpos.p3, ypos.p4);
            graphics.drawLine(xpos.p4, ypos.p1, xpos.p4, ypos.p4);
            graphics.end();
			
			
			
			//draw labels
			var hFormatted = [];
			var vFormatted = [];
			$(mainGraph._hLabels).each(function(){
				hFormatted.push(StrFormatter.getFormattedLabel(this, this)) 
				})
			$(mainGraph._vLabels).each(function(){
				vFormatted.push(StrFormatter.getFormattedLabel(this, this)) 
				} )

            var h = [hFormatted[1],
					 hFormatted[2],
					 hFormatted[3]];
            var v = [vFormatted[1],
					 vFormatted[2],
					 vFormatted[3]];
					 
            var labelObj = mainGraph._datasource.getGridLabels();
            if (labelObj) {
				h = (labelObj.h && labelObj.h.length > 2) ? labelObj.h : h;
				v = (labelObj.v && labelObj.v.length > 2) ? labelObj.v : v;
			}
            var left = mainGraph._margin.left;
            var top = mainGraph._margin.top +  Math.abs(yrange.second - yrange.first)+this.LABEL_OFFSET;
            var hlabelRef = $([
			$.TextStudio.create(h[0], this.labelLayer, "absolute", left, top, null, null, "coordinate"), 
			$.TextStudio.create(h[1], this.labelLayer, "absolute", xpos.p2 + left, top, null, null, "coordinate"), 
			$.TextStudio.create(h[2], this.labelLayer, "absolute", xpos.p3 + left, top, null, null, "coordinate")]);
            left = mainGraph._margin.left + Math.abs(xrange.second - xrange.first)+this.LABEL_OFFSET;
            top = mainGraph._margin.top + (ypos.p2-ypos.p1-hlabelRef.height())/2;
			var vlabelRef = $([
            $.TextStudio.create(v[2], this.labelLayer, "absolute", left, top, null, null, "coordinate1"),
            $.TextStudio.create(v[1], this.labelLayer, "absolute", left, ypos.p2 + top, null, null, "coordinate1"),
            $.TextStudio.create(v[0], this.labelLayer, "absolute", left, ypos.p3 + top, null, null, "coordinate1")]);
        },
        _makeExtendedCoordinate: function(){
            var xrange = mainGraph.xAxisMapping.getCoordinateRange();
            var yrange = mainGraph.yAxisMapping.getCoordinateRange();
            var xpos = {
                p1: Math.floor(mainGraph.xAxisMapping.getCoordinate(0)) + 0.5,
                p2: Math.floor(mainGraph.xAxisMapping.getCoordinate(100)) + 0.5,
                p3: Math.floor(mainGraph.xAxisMapping.getCoordinate(200)) + 0.5,
                p4: Math.floor(mainGraph.xAxisMapping.getCoordinate(300)) + 0.5
            };
            var ypos = {
                p1: Math.floor(mainGraph.yAxisMapping.getCoordinate(300)) + 0.5,
                p2: Math.floor(mainGraph.yAxisMapping.getCoordinate(200)) + 0.5,
                p3: Math.floor(mainGraph.yAxisMapping.getCoordinate(100)) + 0.5,
                p4: Math.floor(mainGraph.yAxisMapping.getCoordinate(0)) + 0.5
            };
            
            //update the size of inner rect.
            this.innerRect.width = xpos.p4 - xpos.p1;
            this.innerRect.height = ypos.p4 - ypos.p1;
            $(this.innerRect).css({
                left: xpos.p1,
                top: ypos.p1,
                width: (xpos.p4 - xpos.p1),
                height: (ypos.p4 - ypos.p1)
            });
            
            //draw background grid line.
            var graphics = new $.Graphics(this.ctx);
            graphics.begin();
            graphics.setLineStyle(1, this._outerLineColor);
            graphics.drawLine(xrange.first, ypos.p1, xrange.second, ypos.p1);
            graphics.drawLine(xrange.first, ypos.p2, xrange.second, ypos.p2);
            graphics.drawLine(xrange.first, ypos.p3, xrange.second, ypos.p3);
            graphics.drawLine(xrange.first, ypos.p4, xrange.second, ypos.p4);
            graphics.drawLine(xpos.p1, yrange.first, xpos.p1, yrange.second);
            graphics.drawLine(xpos.p2, yrange.first, xpos.p2, yrange.second);
            graphics.drawLine(xpos.p3, yrange.first, xpos.p3, yrange.second);
            graphics.drawLine(xpos.p4, yrange.first, xpos.p4, yrange.second);
            graphics.end();
            
            //draw inner grid line.
            graphics.begin();
            graphics.setLineStyle(1, this._innerLineColor);
            graphics.drawLine(xpos.p1, ypos.p1, xpos.p4, ypos.p1);
            graphics.drawLine(xpos.p1, ypos.p2, xpos.p4, ypos.p2);
            graphics.drawLine(xpos.p1, ypos.p3, xpos.p4, ypos.p3);
            graphics.drawLine(xpos.p1, ypos.p4, xpos.p4, ypos.p4);
            graphics.drawLine(xpos.p1, ypos.p1, xpos.p1, ypos.p4);
            graphics.drawLine(xpos.p2, ypos.p1, xpos.p2, ypos.p4);
            graphics.drawLine(xpos.p3, ypos.p1, xpos.p3, ypos.p4);
            graphics.drawLine(xpos.p4, ypos.p1, xpos.p4, ypos.p4);
            graphics.end();
            
            //draw labels
			var hFormatted = [];
			var vFormatted = [];
			$(mainGraph._hLabels).each(function(){
				hFormatted.push(StrFormatter.getFormattedLabel(this, this)) } )
			$(mainGraph._vLabels).each(function(){
				vFormatted.push(StrFormatter.getFormattedLabel(this, this)) } )
            var h = hFormatted;
            var v = vFormatted;


            var labelObj = mainGraph._datasource.getGridLabels();
            if (labelObj) {
				h = (labelObj.h && labelObj.h.length > 4) ? labelObj.h : h;
				v = (labelObj.v && labelObj.v.length > 4) ? labelObj.v : v;
			}
			//horizontal labels position: top
			//var left = mainGraph._margin.left;
            //var top = 2;
			//horizontal labels position: bottom
            var left = mainGraph._margin.left;
            var top = mainGraph._margin.top +  Math.abs(yrange.second - yrange.first)+this.LABEL_OFFSET;
            var hlabelRef = $([
			$.TextStudio.create(h[0], this.labelLayer, "absolute", left, top, null, null, "coordinate"), 
			$.TextStudio.create(h[1], this.labelLayer, "absolute", xpos.p1 + left, top, null, null, "coordinate"), 
			$.TextStudio.create(h[2], this.labelLayer, "absolute", xpos.p2 + left, top, null, null, "coordinate"), 
			$.TextStudio.create(h[3], this.labelLayer, "absolute", xpos.p3 + left, top, null, null, "coordinate"), 
			$.TextStudio.create(h[4], this.labelLayer, "absolute", xpos.p4 + left, top, null, null, "coordinate")]);
            //vertical labels postion: left
			//left = 2;
            //top = mainGraph._margin.top;
			//vertical labels postion: right
			left = mainGraph._margin.left + Math.abs(xrange.second - xrange.first)+this.LABEL_OFFSET;
            top = mainGraph._margin.top + (ypos.p2-ypos.p1-hlabelRef.height())/2;
			var vlabelRef = $([
			$.TextStudio.create(v[4], this.labelLayer, "absolute", left, top, null, null, "coordinate1"),
            $.TextStudio.create(v[3], this.labelLayer, "absolute", left, ypos.p1 + top, null, null, "coordinate1"),
            $.TextStudio.create(v[2], this.labelLayer, "absolute", left, ypos.p2 + top, null, null, "coordinate1"),
            $.TextStudio.create(v[1], this.labelLayer, "absolute", left, ypos.p3 + top, null, null, "coordinate1"),
            $.TextStudio.create(v[0], this.labelLayer, "absolute", left, ypos.p4 + top, null, null, "coordinate1")]);	
        }
    });
    
    this.Presentation.GraphArea = function(){
        this.canvas = mainGraph._graphCanvas;
        this.ctx = this.canvas.getContext("2d");
        this._graphics = new $.Graphics(this.ctx);
        
        this.CENTROID_OUT_RADIUS = 5;
        this.CENTROID_IN_RADIUS = 3;
        
        this.OwnerShipZoneGenerater = {
            createZonePoint: function(data){
                pts = [];
                
                var total = 500;
                var step = Math.PI * 2 / total;
                
                for (var i = 0; i < total; i++) {
                    var x1 = Math.sqrt(data.zonePercentile) * (data.styleVar * Math.cos(step * i) + data.rho * data.sizeVar * Math.sin(step * i)) + data.style;
                    var y1 = Math.sqrt(data.zonePercentile) * (Math.sqrt(1 - data.rho * data.rho) * data.sizeVar * Math.sin(step * i)) + data.size;
                    
                    if (isNaN(x1) || isNaN(y1)) {
                        continue;
                    }
                    
                    pts.push({
                        x: x1,
                        y: y1
                    });
                }
                
                return pts;
            }
        };
		this.RadiusCreator = {
			FIRST_RADIUS:5.35,
			SECOND_RADIUS:3.4,
			THIRD_RADIUS:2.4,
			getHoldingRadius: function(weight){
				var radius = this.FIRST_RADIUS;
				if (weight < 3) {
					radius = this.SECOND_RADIUS;
				}
				else {
					radius = this.THIRD_RADIUS;
				}
				return radius;
			}
		};
    };
    this.Presentation.GraphArea.prototype = $.extend(new this.Presentation.GraphElement(), {
        resizeComponents: function(width, height){
        
        },
        refresh: function(){
            var d = +new Date();
            this._drawAreaGraph();
            ChartLogger.instance.write("[time-consuming] time consuming of drawing ts graph area: " + (new Date() - d));
        },
        reset: function(){
            this.ctx.clearRect(0, 0, this.getWidth(), this.getHeight());
        },
        _drawAreaGraph: function(){
            this.reset();
            
            var rawData = mainGraph._datasource.getOwnerShipZoneRawData();
            if (!rawData || rawData.count < 0) {
                return;
            }
            
            var keys = rawData.keys();
            var values = rawData.values();
            for (var i = values.length - 1; i >= 0; i--) {
                this._drawZone(keys[i], values[i]);
                this._drawCentroid(keys[i], values[i]);
            }
			
			this._drawHolding();
        },
        _drawCentroid: function(investmentId, data){
            var setting = mainGraph._datasource.getInvestmentSetting(investmentId);
            if (setting) {
                var radius = {
                    o: this.CENTROID_OUT_RADIUS,
                    i: this.CENTROID_IN_RADIUS
                };
                var pos = {
                    x: mainGraph.xAxisMapping.getCoordinate(data.style),
                    y: mainGraph.yAxisMapping.getCoordinate(data.size)
                };
                if (setting.oradius && parseFloat(setting.oradisu)) {
                    radius.o = setting.oradius;
                }
                if (setting.iradius && parseFloat(setting.iradisu)) {
                    radius.i = setting.iradius;
                }
                //outer circle
                this._graphics.begin();
                this._graphics.setLineStyle(1, setting.color);
                this._graphics.setNoneFill();
                this._graphics.drawCircle(pos, radius.o);
                this._graphics.end();
                
                //inner plot
                this._graphics.begin();
				this._graphics.setLineStyle(0);
                this._graphics.setNormalFill(setting.color);
                this._graphics.drawCircle(pos, radius.i);
                this._graphics.end();
            }
        },
        _drawZone: function(investmentId, data){
            var setting = mainGraph._datasource.getInvestmentSetting(investmentId);
            if (setting) {
                var pts = this.OwnerShipZoneGenerater.createZonePoint(data);
                if (pts.length > 0) {
                    $(pts).each(function(){
                        this.x = mainGraph.xAxisMapping.getCoordinate(this.x);
                        this.y = mainGraph.yAxisMapping.getCoordinate(this.y);
                    });
                    
                    var color = $.color.parse(setting.zcolor ? setting.zcolor : setting.color);
                    color.a = 0.5;
                    this._graphics.begin();
					this._graphics.setLineStyle(0);
                    this._graphics.setNormalFill(color.toString());
                    this._graphics.drawPolygon(pts);
                    this._graphics.end();
                }
            }
        },
        _drawHolding: function(){
        	var weightData = mainGraph._datasource.getHoldingWeightData();
            if (!weightData || weightData.count < 0) {
                return;
            }
            
            var keys = weightData.keys();
            var values = weightData.values();
            for (var i = keys.length - 1; i >= 0; i--) {
				var setting = mainGraph._datasource.getInvestmentSetting(keys[i]);
				if (setting) {
					var holdingList = values[i].values();
					for (var j = 0; j < holdingList.length; j++) {
						var data = mainGraph._datasource.getHoldingOwnerShipZoneRawData(keys[i], holdingList[j].holdingId);
						if (!data) {
							continue;
						}
						var pos = {
							x: mainGraph.xAxisMapping.getCoordinate(data.style),
							y: mainGraph.yAxisMapping.getCoordinate(data.size)
						}, radius = holdingList[j].radius;
						if (!radius) {
							radius = this.RadiusCreator.getHoldingRadius(holdingList[j].weight);
						}
						this._graphics.begin();
						this._graphics.setLineStyle(0);
						this._graphics.setNormalFill(holdingList[j].color ? holdingList[j].color : setting.color);
						this._graphics.drawCircle(pos, radius);
						this._graphics.end();
					}
				}
			}
        }
    });
    
    this.Presentation.MessagePanel = function(){
        this.canvas = mainGraph._messageCanvas;
    };
    this.Presentation.MessagePanel.prototype = $.extend(new this.Presentation.GraphElement(), {});
    
    this.Presentation.TooltipLayer = function(){
        this.MOUSE_SENSITIVE_RADIUS = 5;
        this.MAX_TOOLTIP_FLOAT_WINDOW_COUNT = 15;
        this.canvas = mainGraph._tooltipCanvas;
        this._controlContainer = mainGraph._tooltipCanvas;
    };
    this.Presentation.TooltipLayer.prototype = $.extend(new this.Presentation.GraphElement(), {});
    
    this.Presentation.PresentationManager = function(){
        this._coordinate = null;
        this._graphArea = null;
        this._messagePanel = null;
        this._tooltipLayer = null;
        this.canvas = mainGraph._placeHolder.get(0);
        
        var me = this;
        
        var createElement = function(){
            var totalSize = {
                width: mainGraph._placeHolder.width(),
                height: mainGraph._placeHolder.height()
            };
            var graphSize = {
                width: totalSize.width - mainGraph._margin.left - mainGraph._margin.right,
                height: totalSize.height - mainGraph._margin.top - mainGraph._margin.bottom
            };
            mainGraph._coordinateCanvas = $.Canvas.createDiv(mainGraph._placeHolder, "absolute", 0, 0, totalSize.width, totalSize.height);
            mainGraph._graphCanvas = $.Canvas.create(mainGraph._placeHolder, "absolute", mainGraph._margin.left, mainGraph._margin.top, graphSize.width, graphSize.height);
            //mainGraph._tooltipCanvas = $.Canvas.createDiv(mainGraph._placeHolder, "absolute", 0, 0, canvasWidth, canvasHeight - mainGraph.FOOTER_HEIGHT);
            //mainGraph._messageCanvas = $.Canvas.create(mainGraph._placeHolder, "absolute", 0, 0, canvasWidth, canvasHeight);
        };
        
        createElement();
    };
    this.Presentation.PresentationManager.prototype = $.extend(new Chart.Common.Command.CommandHandler(), new this.Presentation.GraphElement(), {
        initailizeCoordinateMapping: function(){
            var xrange = {
                first: 0,
                second: 0
            };
            var yrange = {
                first: 0,
                second: 0
            };
            //this._graphArea.getRange(xrange, yrange);
            this._coordinate.getRange(xrange, yrange);
            
            mainGraph.xAxisMapping.setCoordinateRange({
                first: 0,
                second: this._graphArea.getWidth() - 1
            });
            mainGraph.xAxisMapping.setValueRange(xrange);
            mainGraph.yAxisMapping.setCoordinateRange({
                first: this._graphArea.getHeight() - 1,
                second: 0
            });
            mainGraph.yAxisMapping.setValueRange(yrange);
        },
        applySetting: function(setting){
			if (setting && setting.chart && setting.chart.option && setting.chart.option.displaystyle != null) {
				mainGraph._displayType = setting.chart.option.displaystyle;
			}
			var bgSetting = {};
			if (Chart.Setting.Presentation.BG.tryDeSerialize(setting, Chart.Setting.SettingItem.Chart, bgSetting)) {
				mainGraph._placeHolder.css({
					"background-color": bgSetting.color
				});
			}
			this._coordinate.applySetting(setting);
			this._graphArea.applySetting(setting);
			//this._tooltipLayer.applySetting(setting);
		},
		refresh: function(){
            var me = this;
            setTimeout(function(){
                me.initailizeCoordinateMapping();
                me._coordinate.refresh();
                me._graphArea.refresh();
                //me._tooltipLayer.refresh();
            }, 10);
        },
        clearAll: function(){
            //this._coordinate.reset();
            this._graphArea.reset();
            //this._tooltipLayer.reset();
            //this._messagePanel.onClearAll();
        },
        resizeComponents: function(width, height){
            this._coordinate.resize(width, height);
            this._graphArea.resize(width - mainGraph._margin.left - mainGraph._margin.right, height - mainGraph._margin.top - mainGraph._margin.bottom);
			//this._tooltipArea.resize();
			//this._messagePanel.resize();
        },
        getHandler: function(args){
            switch (args.command) {
				case Chart.Common.Command.Commands.APPLY_CHART_SETTING:
					return this._onApplyChartSetting;
                case Chart.Common.Command.Commands.REFRESH_PRESENTATION:
                    return this.onRefreshPresentation;
                case Chart.Common.Command.Commands.RESIZE:
                    return this.onResize;
                case Chart.Common.Command.Commands.INITIALIZE:
                    return this.onInitialize;
                case Chart.Common.Command.Commands.COMPONENT_STATUS_UPDATE:
                    return this.onComponentStatusUpdate;
                case Chart.Common.Command.Commands.SET_CULTURE:
                    return this.onSetCulture;
                default:
                    return null;
            }
        },
        _onApplyChartSetting: function(args){
			if (args && args.data && args.data.setting) {
				this.applySetting(args.data.setting);
				//this.refresh();
			}
		},
		onInitialize: function(args){
            this._coordinate = new mainGraph.Presentation.CoordinateArea();
            this._graphArea = new mainGraph.Presentation.GraphArea();
            //this._messagePanel = new mainGraph.Presentation.MessagePanel();
            //this._tooltipLayer = new mainGraph.Presentation.TooltipLayer();
        },
        onRefreshPresentation: function(args){
            this.refresh();
        },
        onResize: function(args){
            if (args && args.data && args.data.width && args.data.height) {
                this.resize(args.data.width, args.data.height);
            }
            this.refresh();
        },
        onComponentStatusUpdate: function(args){
            if (args && args.data && args.data.status) {
                switch (args.data.status) {
                    case Chart.Common.Command.ComponentStatus.ClearAll:
                        this.clearAll();
                        break;
                    default:
                        break;
                }
            }
        },
		onSetCulture: function(args){
			if (args) {
				this.refresh();
			}
		}
    });
    
    var initializeEx = function(){
        mainGraph._presentation = new mainGraph.Presentation.PresentationManager();
    };
    
    initializeEx();
};
Chart.Component.HBSMGraph.prototype = $.extend(new Chart.Common.Command.CommandHandler(), {
    defaultHandler: function(args){
        //do nothing here.
    },
    getHandler: function(args){
        return this.defaultHandler;
    },
    collectionChildren: function(){
        this.interactiveChildren = [this._presentation];
    },
    setDataSource: function(datasource){
        this._datasource = datasource;
    },
    resize: function(width, height){
        this._presentation.resize(width, height);
        this._presentation.refresh();
    }
});

