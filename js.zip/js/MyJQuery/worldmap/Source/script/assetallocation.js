Chart.AAChart = function(containerDOM, displayStyle){
	this.cId = +new Date();	
	this.container = containerDOM;
	this.displayStyle = 1;
	
	this.dataSource = null;
	this.graph = null;
	
	this.graphCanvas = null;
	this.floatCanvas = null;
	
	this.canvasWidth = 0;
	this.canvasHeight = 0;
	
	if (displayStyle !== null && parseInt(displayStyle,10) >= 0) {
		this.displayStyle = displayStyle;
	}
	
	if (containerDOM) {
		this._initialize();
	}
	return this;
};
Chart.AAChart.prototype = $.extend(new Chart.Common.Graphic.GraphElement(), {
	/*
	 * override
	 */
	resizeComponents: function(width, height){
		this.canvasWidth = width;
		this.canvasHeight = height;
		
		this.graphCanvas.css({
			width: width,
			height: height
		});
		
		this.graph.resize(width, height);
	},
	/*
	 * override
	 */
	refresh: function(){
		var me = this;
		this.dataSource.refresh(function(){
			me.dataSource.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.REFRESH_PRESENTATION, null));
		});
	},
	/*
	 * interface for push data mode
	 * @param jsonStr {string} data string, in JSON format.
	 * @return null;
	 */
	setData: function(jsonStr){
		this.dataSource.setData(jsonStr);
	},
	/*
	 * another interface for push data mode, call refresh directly.
	 */
	draw: function(){
		this.dataSource.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.REFRESH_PRESENTATION, null));
	},
	/*
	 * interface for update culture
	 * @param cultureName {string} culture name string, such as "en_GB"
	 * @return null;
	 */
	setCulture: function(cultureName){
		var me = this;
		LocalizationManager.instance.setCurrentCulture(cultureName, function(){
			me.dataSource.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.SET_CULTURE, null));
		});
	},
	_initialize: function(){
		this.canvas = this.container.get(0);
		this.canvasWidth = this.container.width();
		this.canvasHeight = this.container.height();
		
		this._createElements();
		this._createComponents();
	},
	_createComponents: function(){
		this.dataSource = new Chart.Component.AAData();
		this.graph = new Chart.Component.AAGraph(this.graphCanvas, this.displayStyle);
		this.graph.setDataSource(this.dataSource);
		this.graph.collectionChildren();
		
		this.dataSource.collectionChildren();
		this.dataSource.addChild(this.graph);
		this.dataSource.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.INITIALIZE, null));
	},
	_createElements: function(){
		this.container.attr({
			"cid": this.cId
		});
		this.container.addClass("assetallocation");
		this.graphCanvas = $($.Canvas.createDiv(this.container, "relative", 0, 0, this.canvasWidth, this.canvasHeight)).attr({
			"cid": this.cId
		});
		/*
		this.floatCanvas = $($.Canvas.createDiv(this.container, "absolute", 0, 0, 0, 0)).attr({
			"id": "phTip" + this.cId,
			"cid": this.cId
		});
		*/
		this.floatCanvas = $("<div></div>").appendTo(this.container).attr({
			"id": "phTip" + this.cId,
			"cid": this.cId
		});
	}
});

Chart.AAChart.DisplayStyle = {
	LongOnly: 1,
	LongShortNet: 2
};

Chart.Interface.AAChartInterface = function(){
};
Chart.Interface.AAChartInterface.prototype = {
    /*
     * get investment group data dictionary.
     * @param none
     * @return {Dictionary<string, Pair<double>>} {first: weight, second: ytd}
     */
    getInvGroupData: function(){
        return null;
    },
	/*
	 * get investment group name by id
	 * @param invGroupId {string}
	 * @return {string}
	 */
	getInvGroupName: function(invGroupId){
		return "";		
	},
	/*
	 * get context that will display in tooltip
	 * @param invGroupId {string}
	 * @return {[string, string,...,string]}
	 */
	getFloatingTipContext: function(invGroupId, type){
		return null;
	}
};

Chart.Component.AAData = function(){
	var today = new Date();
	today = new Date(today.getFullYear(), today.getMonth(), today.getDate());
	this._rawData = new Dictionary();
	this._investmentGroupInfo = new Dictionary();
	
	var me = this;
	
	this._rawData.add("group1",{l: 24, s: -77, n:-53, color: "#66B502"});
	this._rawData.add("group2",{l: 90.88, s: -10, n:80.88, color: "#28366D"});
	this._rawData.add("group3",{l: 18.15, s: -12.15, n:6, color: "#A20126"});
	this._rawData.add("group4",{l: 12.5, s: 0, n:12.5, color: "#F36615"});
	this._rawData.add("group5",{l: 0, s: -30, n:-30, color: "#7B95B9"});
	
	this._investmentGroupInfo.add("group1", {name: "Cash"});
	this._investmentGroupInfo.add("group2", {name: "U.S. Stocks"});
	this._investmentGroupInfo.add("group3", {name: "Non U.S. Stocks"});
	this._investmentGroupInfo.add("group4", {name: "Bond"});
	this._investmentGroupInfo.add("group5", {name: "Other"});
};
Chart.Component.AAData.prototype = $.extend(new Chart.Common.Command.CommandHandler(), new Chart.Interface.AAChartInterface(),{
	/*
	 * set data and option
	 * @param {string} in JSON format.
	 */
	setData: function(jsonStr){
		var d = +new Date();
       
		this.reset();
		
		var data = $.evalJSON(jsonStr);
		if (!data) {
			return;
		}
		
		var loseData = false;
		if (data.Groups && data.Groups.length > 0) {
			var len = data.Groups.length;
			var groupId = "", group = null, temp = null;
			for (var i = 0; i < len; i++) {
				groupId = "group" + i.toString();
				group = data.Groups[i];
				temp = {
					l: group.Long ? group.Long : 0,
					s: group.Short ? group.Short : 0,
					n: group.Net ? group.Net : 0,
					color: group.Color ? group.Color : "#FFFFFF"
				};
				if (temp.l < 0 || temp.s > 0 || Math.abs(temp.n - temp.l - temp.s) > 0.00011) {
					loseData = true;
					continue;
				}
				this._rawData.add(groupId, temp);
				this._investmentGroupInfo.add(groupId, {
					name: group.Name ? group.Name : ""
				});
			}
		}
		
		//parse chart setting.
		var setting = {
			chart: {
				option: {}
			}
		};
		
		if (data.Type && parseInt(data.Type, 10)) {
			setting.chart.option.displaystyle = data.Type;
		}
		
		if (data.BarHeight && parseFloat(data.BarHeight)) {
			setting.chart.option.barheight = parseFloat(data.BarHeight);
		}
		
		if (data.BarMargin && parseFloat(data.BarMargin)) {
			setting.chart.option.barmargin = parseFloat(data.BarMargin);
		}
		
		if (data.Margin && parseFloat(data.Margin)) {
			setting.chart.option.margin = parseFloat(data.Margin);
		}
		
		if (data.BGColor) {
			Chart.Setting.Presentation.BG.serialize(setting, Chart.Setting.SettingItem.Chart, {
				color: data.BGColor
			});
		}
		
		this.executeCommand(
			new Chart.Common.Command.CommandArgs(
				null, 
				Chart.Common.Command.Commands.APPLY_CHART_SETTING, 
				{setting:setting}));
		
		if (loseData) {
			ChartLogger.instance.write("[data error] some group data are abandoned for wrong input.");
		}
		ChartLogger.instance.write("[time-consuming] time consuming of set data interface: " + (new Date() - d));
	},
	/*
	 * hook function
	 */
	refresh: function(callback){
		if(callback && typeof(callback)== "function"){
			callback();
		}
	},
	/*
	 * clear all cache data.
	 */
	reset: function(){
		this._rawData.clear();
		this._investmentGroupInfo.clear();
	},
	/*
     * override. filter commands.
     * @param arg {Chart.Common.Command.CommandArgs} content.
     * @return the handler event of target command.
     */
	getHandler: function(args){
		switch (args.command) {
			case Chart.Common.Command.Commands.ADD_INVESTMENT:
			case Chart.Common.Command.Commands.DELETE_ITEM:
			case Chart.Common.Command.Commands.REFRESH_PRESENTATION:
			case Chart.Common.Command.Commands.RESIZE:
			case Chart.Common.Command.Commands.INITIALIZE:
			case Chart.Common.Command.Commands.COMPONENT_STATUS_UPDATE:
				return this.defaultHandler;
			default:
				return this.defaultHandler;
		}
		return this.defaultHandler;
	},
	/*
     * default command handler, the purpose of this is the enable all commmand will be passed to children.
     * @param arg {Chart.Common.Command.CommandArgs} content.
     * @return null.
     */
	defaultHandler: function(args){
		//do nothing here.
	},
	/*
     * get investment group data dictionary.
     * @param none
     * @return {Dictionary<string, Pair<double>>} {first: weight, second: ytd}
     */
    getInvGroupData: function(){
        return this._rawData;
    },
	/*
	 * get investment group name by id
	 * @param invGroupId {string}
	 * @return {string}
	 */
	getInvGroupName: function(invGroupId){
		var info = this._investmentGroupInfo.tryGetValue(invGroupId, null);
		return info && info.name ? info.name : "";
	},
	/*
	 * get context that will display in tooltip
	 * @param invGroupId {string}
	 * @return {[string, string,...,string]}
	 */
	getFloatingTipContext: function(invGroupId, type){
		var ret = [], 
			data = this._rawData.tryGetValue(invGroupId,null);
		if (data) {
		    var info = this._investmentGroupInfo.tryGetValue(invGroupId,null);
		    if(info && info.name){
		        if(type == "l"){
		            ret.push(String.format("{0} {1}: {2}%", info.name, LocalizationManager.instance.getLabel("long", "Long"),LocalizationManager.instance.formatDecimal(data.l,2)));
		        }
		        else if(type == "s"){
		            ret.push(String.format("{0} {1}: {2}%", info.name, LocalizationManager.instance.getLabel("short", "Short"),LocalizationManager.instance.formatDecimal(Math.abs(data.s),2)));
		        }
		        else if(type == "n"){
		            ret.push(String.format("{0} {1}: {2}%", info.name, LocalizationManager.instance.getLabel("net", "Net"),LocalizationManager.instance.formatDecimal(data.n,2)));
					if(data.n > 100){
						ret.push(String.format("{0} {1}: {2}%", info.name, LocalizationManager.instance.getLabel("long", "Long"),LocalizationManager.instance.formatDecimal(data.l,2)));
					}else if(data.n < -100){
						ret.push(String.format("{0} {1}: {2}%", info.name, LocalizationManager.instance.getLabel("short", "Short"),LocalizationManager.instance.formatDecimal(Math.abs(data.s),2)));
					}
		        }
			}
		}
		return ret;
	}
});

Chart.Component.AAGraph = function(target,displayStyle){
	this._displayStyle = displayStyle;
    this._placeHolder = target;
    this._placeHolder.css({
        "position": "relative",
        "background-color": "transparent",
        "cursor": "default"
    });
    this._margin = {
        left: 0,
        top: 0,
        right: 0,
        bottom: 0
    };
	this.LEFT_MARGIN = 10;
	this.FOOTER_HEIGHT = 24;
	
	this._groupBar = {
		margin: 3,
		height: 16,
		scalar: 0
	};
		
	this._barInfo = [];
    this._datasource = null;
    this._tooltipFactory = new Chart.Common.Controls.BasicTipFactory(target.attr("cid"));
	this._tooltip = null;
    
	this._coordinateCanvas = null;
    this._graphCanvas = null;
    this._tooltipCanvas = null;
    this._messageCanvas = null;
	
	this.xAxisMapping = new Chart.Common.Coordinate.Double2DoubleLinearMapping();
    this.yAxisMapping = new Chart.Common.Coordinate.Double2DoubleLinearMapping();
    
    var mainGraph = this;
    
    this.Presentation = function(){
    };
    
    this.Presentation.GraphElement = function(){
    };
    this.Presentation.GraphElement.prototype = $.extend(new Chart.Common.Graphic.GraphElement(), {});
        
	this.Presentation.CoordinateArea = function(){
		this.canvas = mainGraph._coordinateCanvas;
		this.canvasRef = $(this.canvas);
		this.ctx = null;
		this._graphics = null;
		this.lineLayer = null;
		this.labelLayer = null;
		this.labelRef = null;
		
		this.LABEL_OFFSET = 4;
		this.GRIDLINE_EX = 6;
		this.SCALAR = 4;
		
		this._strokeThickness = 1;
        this._strokeColor = "#CCCCCC";
		//this._backgroudColor = "#FDFDFD";
		
		this._numberSetting = { decimalCount: 2, shortened: true };
		
		var me = this;
		
		var _createElement = function(){
			var graphSize = {
				width: me.getWidth(),
				height: me.getHeight()
			};
			//me.canvasRef.css({"background-color": $.color.parse(me._backgroudColor).toString()});
			me.lineLayer = $.Canvas.create(me.canvasRef, "absolute", 0, 0, graphSize.width, graphSize.height);
			me.labelLayer = $.Canvas.createDiv(me.canvasRef, "absolute", 0, 0, graphSize.width, graphSize.height);
			me.labelRef = $(me.labelLayer);
			me.ctx = me.lineLayer.getContext("2d");
			me._graphics = new $.Graphics(me.ctx);
		};
		
		_createElement();
	};
    this.Presentation.CoordinateArea.prototype = $.extend(new this.Presentation.GraphElement(), {
        getRange: function(xrange, yrange){
		},
        resizeComponents: function(width, height){
            this.lineLayer.width = width;
            this.lineLayer.height = height;
			this.labelLayer.width = width;
            this.labelLayer.height = height;
            $(this.lineLayer).css({
                width: width,
                height: height
            });
            $(this.labelLayer).css({
                width: width,
                height: height
            });
        },
        refresh: function(){
            var d = +new Date();
            this._drawCoordinate();
            ChartLogger.instance.write("[time-consuming] time consuming of drawing coordinate area: " + (new Date() - d));
        },
        reset: function(){
            this.ctx.clearRect(0, 0, this.getWidth(), this.getHeight());
            $(this.labelLayer).html("");
        },
        _drawCoordinate: function(){
			this.reset();
			
			this._drawXMarks();
			this._drawYMarks();
		},
		_drawYMarks: function(){
			var mapping = mainGraph.yAxisMapping;
			var valueRange = mapping.getValueRange();
			var totalRange = valueRange.second - valueRange.first;
			var yValueSpace = totalRange / mainGraph._groupBar.scalar;
			
			this._graphics.begin();
			this._graphics.setLineStyle(this._strokeThickness, this._strokeColor);
			
			var adjust = this._strokeThickness % 2 == 1 ? 0.5 : 0;
			var currentValue = valueRange.first;
			var y = Math.floor(mapping.getCoordinate(currentValue)) + adjust;
			var lineLength = this.getWidth();
			this._graphics.drawLine(0, y, lineLength, y);
			
			for (var i = 0; i < mainGraph._groupBar.scalar; i++) {
				currentValue = currentValue + yValueSpace;
				if (Math.abs(currentValue) < 0.000001) {
					currentValue = 0;
				}
				
				y = Math.floor(mapping.getCoordinate(currentValue)) + adjust;
				this._graphics.drawLine(0, y, lineLength, y);
			}
			this._graphics.end();
		},
		_drawXMarks: function(){
			var mapping = mainGraph.xAxisMapping;
			var coordinateRange = mainGraph.yAxisMapping.getCoordinateRange();
			var valueRange = mapping.getValueRange();
			var totalRange = valueRange.second - valueRange.first;
			var valueSpace = totalRange / this.SCALAR;
			
			this._graphics.begin();
			this._graphics.setLineStyle(this._strokeThickness, this._strokeColor);
			
			var adjust = this._strokeThickness % 2 == 1 ? 0.5 : 0;
			var currentValue = valueRange.first;
			var x = Math.floor(mapping.getCoordinate(currentValue)) + adjust;
			var y1 = coordinateRange.second,y2 = coordinateRange.second + this.GRIDLINE_EX;
			this._graphics.drawVDotLine(x, coordinateRange.first, y1, 1,2);
			this._graphics.drawLine(x, y1, x, y2);
			var text = StrFormatter.getFormattedNumString(currentValue, totalRange, this._numberSetting.decimalCount, this._numberSetting.shortened);
			var textbox = $($.TextStudio.create(text, this.labelRef, "absolute", x, y2 + this.LABEL_OFFSET, null, null, "coordinate"));
			
			for (var i = 0; i < this.SCALAR; i++) {
				currentValue = currentValue + valueSpace;
				if (Math.abs(currentValue) < 0.000001) {
					currentValue = 0;
				}
				
				x = Math.floor(mapping.getCoordinate(currentValue)) + adjust;
				this._graphics.drawVDotLine(x, coordinateRange.first, y1, 1, 2);
				this._graphics.drawLine(x, y1, x, y2);
				
				text = StrFormatter.getFormattedNumString(currentValue, totalRange, this._numberSetting.decimalCount, this._numberSetting.shortened);
				textbox = $($.TextStudio.create(text, this.labelRef, "absolute", x, y2 + this.LABEL_OFFSET, null, null, "coordinate"));
				textbox.css({
					left: i < this.SCALAR - 1 ? x - textbox.width() / 2 : x - textbox.width()
				});
			}
			this._graphics.end();
		},
		_drawVerticalDottedLine: function(x, y1, y2, scale){
			var temp1 = y2, temp2 = y2-scale, unit = scale*2;
			
			while (temp1 > y1) {
				this._graphics.drawLine(x, temp2, x, temp1);
				temp1 -= unit;
				temp2 -= unit;
				temp2 = temp2 < y1 ? y1 : temp2;
			}
		}
    });
	
    this.Presentation.GraphArea = function(){
        this.canvas = mainGraph._graphCanvas;
        this.ctx = this.canvas.getContext("2d");
        this._graphics = new $.Graphics(this.ctx);
    };
    this.Presentation.GraphArea.prototype = $.extend(new this.Presentation.GraphElement(), {
        applySetting: function(setting){
			if (setting && setting.chart && setting.chart.option) {
				if (setting.chart.option.barheight && parseFloat(setting.chart.option.barheight)) {
					mainGraph._groupBar.height = parseFloat(setting.chart.option.barheight);
				}
				if (setting.chart.option.barmargin && parseFloat(setting.chart.option.barmargin)) {
					mainGraph._groupBar.margin = parseFloat(setting.chart.option.barmargin);
				}
				if (setting.chart.option.margin && parseFloat(setting.chart.option.margin)) {
					mainGraph.LEFT_MARGIN = parseFloat(setting.chart.option.margin);
				}
			}
		},
		getRange: function(xrange, yrange){
			if (!mainGraph._datasource || !mainGraph._datasource.getInvGroupData) 
				return;
			var currentData = mainGraph._datasource.getInvGroupData();
			if (!currentData || currentData.count <= 0) 
				return;
			
			var scalar = currentData.count, 
				maxScalar = Math.floor(this.getHeight() / (mainGraph._groupBar.height + mainGraph._groupBar.margin * 2));
			scalar = scalar > maxScalar ? maxScalar : scalar;
			mainGraph._groupBar.scalar = scalar;
			
			xrange.first = 0;
			xrange.second = 100;
			yrange.first = 0.5;
			yrange.second = scalar + 0.5;
			
			if (mainGraph._displayStyle == Chart.AAChart.DisplayStyle.LongShortNet) {
				xrange.first = -100;
			}
		},
		resizeComponents: function(width, height){
        },
        refresh: function(){
            var d = +new Date();
            this._drawAreaGraph();
            ChartLogger.instance.write("[time-consuming] time consuming of drawing graph area: " + (new Date() - d));
        },
        reset: function(){
            this.ctx.clearRect(0, 0, this.getWidth(), this.getHeight());
			mainGraph._barInfo=[];
        },
        _drawAreaGraph: function(){
			this.reset();
			
			if (!mainGraph._datasource || !mainGraph._datasource.getInvGroupData) 
				return;
			var currentData = mainGraph._datasource.getInvGroupData();
			if (!currentData || currentData.count <= 0) 
				return;
			
			var valRange = mainGraph.xAxisMapping.getValueRange();
			var keys = currentData.keys();
			var groups = currentData.values();
			var adjust=0.5, 
				pos0 = Math.floor(mainGraph.xAxisMapping.getCoordinate(0))+adjust,
				x=0,y=0,width=0, pts=null,
				overflow = false;
			
			if (mainGraph._displayStyle == Chart.AAChart.DisplayStyle.LongShortNet) {
				for (var i = 0; i < currentData.count; i++) {
					y = Math.floor(mainGraph.yAxisMapping.getCoordinate(i + 1) - mainGraph._groupBar.height / 2) + adjust;
					if (groups[i].s < valRange.first) {
						x = Math.floor(mainGraph.xAxisMapping.getCoordinate(valRange.first)) + adjust;
						overflow = true;
					}
					else {
						x = Math.floor(mainGraph.xAxisMapping.getCoordinate(groups[i].s)) + adjust;
						overflow = false;
					}
					pts = [{
						x: x,
						y: y
					}, {
						x: pos0,
						y: y
					}, {
						x: pos0,
						y: y + mainGraph._groupBar.height
					}, {
						x: x,
						y: y + mainGraph._groupBar.height
					}];
					if (overflow) {
						pts.push({
							x: x - 7.5,
							y: y + mainGraph._groupBar.height / 2
						});
					}
					mainGraph._barInfo.push({
						id: keys[i],
						type: "s",
						points: pts
					});
					
					this._graphics.begin();
					this._graphics.setNoneFill();
					this._graphics.setLineStyle(1, groups[i].color);
					this._graphics.drawPolygon(pts);
					
					if (groups[i].l > valRange.second) {
						x = Math.floor(mainGraph.xAxisMapping.getCoordinate(valRange.second)) + adjust;
						overflow = true;
					}
					else {
						x = Math.floor(mainGraph.xAxisMapping.getCoordinate(groups[i].l)) + adjust;
						overflow = false;
					}
					pts = [{
						x: pos0,
						y: y
					}, {
						x: x,
						y: y
					}, {
						x: x,
						y: y + mainGraph._groupBar.height
					}, {
						x: pos0,
						y: y + mainGraph._groupBar.height
					}];
					if (overflow) {
						pts.splice(2,0,{
							x: x + 7.5,
							y: y + mainGraph._groupBar.height / 2
						});
					}
					mainGraph._barInfo.push({
						id: keys[i],
						type: "l",
						points: pts
					});
					this._graphics.drawPolygon(pts);
					this._graphics.end();
					
					var positive = groups[i].n >= 0;
					if (positive) {
						if (groups[i].n > valRange.second) {
							x = Math.floor(mainGraph.xAxisMapping.getCoordinate(valRange.second)) + adjust;
							overflow = true;
						}
						else {
							x = Math.floor(mainGraph.xAxisMapping.getCoordinate(groups[i].n)) + adjust;
							overflow = false;
						}
					}
					else {
						if (groups[i].n < valRange.first) {
							x = Math.floor(mainGraph.xAxisMapping.getCoordinate(valRange.first)) + adjust;
							overflow = true;
						}
						else {
							x = Math.floor(mainGraph.xAxisMapping.getCoordinate(groups[i].n)) + adjust;
							overflow = false;
						}
					}
					width = Math.abs(x - pos0);
					x = x > pos0 ? pos0 : x;
					pts = [{
						x: x,
						y: y
					}, {
						x: x + width,
						y: y
					}, {
						x: x + width,
						y: y + mainGraph._groupBar.height
					}, {
						x: x,
						y: y + mainGraph._groupBar.height
					}];
					if (overflow) {
						if (positive) {
							pts.splice(2, 0, {
								x: x + width + 7.5,
								y: y + mainGraph._groupBar.height / 2
							});
						}
						else{
							pts.push({
								x: x - 7.5,
								y: y + mainGraph._groupBar.height / 2
							});
						}
					}
					mainGraph._barInfo.push({
						id: keys[i],
						type: "n",
						points: pts
					});
					
					this._graphics.begin();
					this._graphics.setLineStyle(0);
					this._graphics.setNormalFill(groups[i].color);
					this._graphics.drawPolygon(pts);
					this._graphics.end();
				}
			}
			else {
				for (var i = 0; i < currentData.count; i++) {
					y = Math.floor(mainGraph.yAxisMapping.getCoordinate(i + 1) - mainGraph._groupBar.height / 2) + adjust;
					x = Math.floor(mainGraph.xAxisMapping.getCoordinate(groups[i].l)) + adjust;
					width = Math.abs(x - pos0);
					x = x > pos0 ? pos0 : x;
					pts = [{
						x: x,
						y: y
					}, {
						x: x + width,
						y: y
					}, {
						x: x + width,
						y: y + mainGraph._groupBar.height
					}, {
						x: x,
						y: y + mainGraph._groupBar.height
					}];
					mainGraph._barInfo.push({
					    id:keys[i],
					    type:"l",
					    points: pts
					});
					
					this._graphics.setLineStyle(0);
					this._graphics.setNormalFill(groups[i].color);
					this._graphics.begin();
					this._graphics.drawPolygon(pts);
					this._graphics.end();
				}
			}
		}
    });
    
    this.Presentation.MessagePanel = function(){
        this.canvas = mainGraph._messageCanvas;
    };
    this.Presentation.MessagePanel.prototype = $.extend(new this.Presentation.GraphElement(), {});
    
    this.Presentation.TooltipLayer = function(){
		this.canvas = mainGraph._tooltipCanvas;
		this.highlightLayer = null;
		this.ctx = null;
        this._graphics = null;
		
		this._currentDatum = null;
		
		var me = this;
		
		var _addEventHandler = function(){
			target.mousemove(_onMouseMove);
			target.mouseout(_onMouseLeave);
		};
		var _onMouseLeave = function(e){
			me._hideTip(e);
		};
		var _onMouseMove = function(e){
			var pt = $.getPosition(me.canvas, e);
			
			var datum = _findDatum(pt);
			if (datum) {
				me._currentDatum = datum; 
					me._showTip(mainGraph._datasource.getFloatingTipContext(datum.id, datum.type), e);
					return;
			}
			
			if (me._currentDatum) {
				me._hideTip(e);
				me._currentDatum = null;
			}
		};
		var _findDatum = function(pt){
			try {
				for(var i= mainGraph._barInfo.length-1;i>=0;i--){
				    //if(_pointInRect(pt, mainGraph._barInfo[i])){
					if (Chart.Common.Graphic.GraphicUtil.inPolygon(mainGraph._barInfo[i].points, mainGraph._barInfo[i].points.length, pt)) {
				        return mainGraph._barInfo[i];
				    }
				}
			} 
			catch (ex) {
			}
			
			return null;
		};
		var _pointInRect = function(pt, rect){
		    if(pt.x>= rect.x && pt.x <= rect.x+rect.width && pt.y >= rect.y && pt.y<=rect.y+rect.height){
		        return true;
		    }
		    return false;
		};
		var _createElement = function(){
			/*
			var graphSize = {
				width: me.getWidth(),
				height: me.getHeight()
			};
			me.highlightLayer = $.Canvas.create($(me.canvas), "absolute", 0, 0, graphSize.width, graphSize.height);
			me.ctx = me.highlightLayer.getContext("2d");
			me._graphics = new $.Graphics(me.ctx);
			*/
			mainGraph._tooltipFactory.setActiveRegion({
				x: 0,
				y: 0,
				width: me.getWidth(),
				height: me.getHeight()
			});
		};
		
		_createElement();
		_addEventHandler();
	};
    this.Presentation.TooltipLayer.prototype = $.extend(new this.Presentation.GraphElement(), {
		resizeComponents: function(width, height){
			if (this.highlightLayer) {
				this.highlightLayer.width = width;
				this.highlightLayer.height = height;
				$(this.highlightLayer).css({
					width: width,
					height: height
				});
			}
			mainGraph._tooltipFactory.setActiveRegion({
				x: 0,
				y: 0,
				width: width,
				height: height
			});
        },
		reset: function(){
			this._hideTip(null);
		},
		_showTip: function(context, e){
			if (!mainGraph._tooltip) {
				mainGraph._tooltip = mainGraph._tooltipFactory.create();
			}
			if(context && context.length>0){
			    mainGraph._tooltip.setContent(context);
			    mainGraph._tooltip.popupAt($.getPosition(target.get(0), e));
			}
		},
		_hideTip: function(e){
			if (mainGraph._tooltip) {
				mainGraph._tooltip.hide();
			}
		}
	});
    
    this.Presentation.PresentationManager = function(){
        this._graphArea = null;
		this._coordinateArea = null;
        this._messagePanel = null;
        this._tooltipLayer = null;
        this.canvas = mainGraph._placeHolder.get(0);
        
        var me = this;
        
        var createElement = function(){
            var totalSize = {
                width: mainGraph._placeHolder.width() - mainGraph._margin.left - mainGraph._margin.right,
                height: mainGraph._placeHolder.height() - mainGraph._margin.top - mainGraph._margin.bottom
            };
            var graphSize = {
                width: totalSize.width,
                height: totalSize.height-mainGraph.FOOTER_HEIGHT
            };
			mainGraph._coordinateCanvas = $.Canvas.createDiv(mainGraph._placeHolder, "absolute", mainGraph._margin.left, mainGraph._margin.top, graphSize.width, totalSize.height);
			mainGraph._graphCanvas = $.Canvas.create(mainGraph._placeHolder, "absolute", mainGraph._margin.left, mainGraph._margin.top, graphSize.width, graphSize.height);
            mainGraph._tooltipCanvas = $.Canvas.createDiv(mainGraph._placeHolder, "absolute", mainGraph._margin.left, mainGraph._margin.top, graphSize.width, graphSize.height);
            //mainGraph._messageCanvas = $.Canvas.create(mainGraph._placeHolder, "absolute", 0, 0, canvasWidth, canvasHeight);
			
			//$(mainGraph._graphCanvas).css({"background-color":"#FF0000"});
        };
        
        createElement();
    };
    this.Presentation.PresentationManager.prototype = $.extend(new Chart.Common.Command.CommandHandler(), new this.Presentation.GraphElement(), {
        initailizeCoordinateMapping: function(){
			var xrange = {
				first: 0,
				second: 0
			};
			var yrange = {
				first: 0,
				second: 0
			};
			var xcoordinate = {
				first: 0,
				second: this._graphArea.getWidth() - 1
			};
			var ycoordinate = {
				first: 0,
				second: this._graphArea.getHeight() - 1
			};
			
			if(mainGraph._displayStyle == Chart.AAChart.DisplayStyle.LongShortNet){
				xcoordinate.first += mainGraph.LEFT_MARGIN;
				xcoordinate.second -= mainGraph.LEFT_MARGIN;
			}
			
			this._graphArea.getRange(xrange, yrange);
			this._coordinateArea.getRange(xrange, yrange);
			
			mainGraph.xAxisMapping.setCoordinateRange(xcoordinate);
			mainGraph.xAxisMapping.setValueRange(xrange);
			mainGraph.yAxisMapping.setCoordinateRange(ycoordinate);
			mainGraph.yAxisMapping.setValueRange(yrange);
		},
		applySetting: function(setting){
			if (setting && setting.chart && setting.chart.option && setting.chart.option.displaystyle != null) {
				mainGraph._displayStyle = setting.chart.option.displaystyle;
			}
			var bgSetting = {};
			if (Chart.Setting.Presentation.BG.tryDeSerialize(setting, Chart.Setting.SettingItem.Chart, bgSetting)) {
				mainGraph._placeHolder.css({
					"background-color": bgSetting.color
				});
			}
			this._coordinateArea.applySetting(setting);
			this._graphArea.applySetting(setting);
			this._tooltipLayer.applySetting(setting);
		},
        refresh: function(){
            var me = this;
            setTimeout(function(){
                me.initailizeCoordinateMapping();
				me._coordinateArea.refresh();
                me._graphArea.refresh();
                //me._tooltipLayer.refresh();
            }, 10);
        },
		_onSetCulture: function(args){
			if (args) {
				this.refresh();
			}
		},
        clearAll: function(){
            this._coordinateArea.reset();
            this._graphArea.reset();
            this._tooltipLayer.reset();
            //this._messagePanel.onClearAll();
        },
        resizeComponents: function(width, height){
			var graphSize = {
				width: width - mainGraph._margin.left - mainGraph._margin.right,
				height: height - mainGraph._margin.top - mainGraph._margin.bottom-mainGraph.FOOTER_HEIGHT
			};
			this._coordinateArea.resize(graphSize.width, height);
			this._graphArea.resize(graphSize.width, graphSize.height);
			this._tooltipLayer.resize(graphSize.width, graphSize.height);
		},
        getHandler: function(args){
            switch (args.command) {
				case Chart.Common.Command.Commands.APPLY_CHART_SETTING:
					return this._onApplyChartSetting;
                case Chart.Common.Command.Commands.REFRESH_PRESENTATION:
                    return this._onRefreshPresentation;
                case Chart.Common.Command.Commands.RESIZE:
                    return this._onResize;
                case Chart.Common.Command.Commands.INITIALIZE:
                    return this._onInitialize;
		        case Chart.Common.Command.Commands.SET_CULTURE:
		            return this._onSetCulture;
                case Chart.Common.Command.Commands.COMPONENT_STATUS_UPDATE:
                    return this._onComponentStatusUpdate;
                default:
                    return null;
            }
        },
		_onApplyChartSetting: function(args){
			if (args && args.data && args.data.setting) {
				this.applySetting(args.data.setting);
				//this.refresh();
			}
		},
        _onInitialize: function(args){
			this._coordinateArea = new mainGraph.Presentation.CoordinateArea();
            this._graphArea = new mainGraph.Presentation.GraphArea();
            //this._messagePanel = new mainGraph.Presentation.MessagePanel();
            this._tooltipLayer = new mainGraph.Presentation.TooltipLayer();
        },
        _onRefreshPresentation: function(args){
            this.refresh();
        },
        _onResize: function(args){
            if (args && args.data && args.data.width && args.data.height) {
                this.resize(args.data.width, args.data.height);
            }
            this.refresh();
        },
        _onComponentStatusUpdate: function(args){
            if (args && args.data && args.data.status) {
                switch (args.data.status) {
                    case Chart.Common.Command.ComponentStatus.ClearAll:
                        this.clearAll();
                        break;
                    default:
                        break;
                }
            }
        }
    });
    
    var initializeEx = function(){
        mainGraph._presentation = new mainGraph.Presentation.PresentationManager();
    };
    
    initializeEx();
};
Chart.Component.AAGraph.prototype = $.extend(new Chart.Common.Command.CommandHandler(), {
    defaultHandler: function(args){
        //do nothing here.
    },
    getHandler: function(args){
        return this.defaultHandler;
    },
    collectionChildren: function(){
        this.interactiveChildren = [this._presentation];
    },
    setDataSource: function(datasource){
        this._datasource = datasource;
    },
    resize: function(width, height){
        this._presentation.resize(width, height);
        this._presentation.refresh();
    }
});

