Chart.HBSMChart = function(containerDOM, displayType){
	this.objId = CHARTID.HBSM;
	this.cId = +new Date();	
	this.container = containerDOM;
	this.displayType = Chart.HBSMChart.DisplayType.Extended;
	
	this.dataSource = null;
	this.graph = null;
	
	this.graphCanvas = null;
	this.floatCanvas = null;
	
	this.canvasWidth = 0;
	this.canvasHeight = 0;
	
	if (displayType != null && parseInt(displayType) >= 0) {
		this.displayType = displayType;
	}
	
	if (containerDOM) {
		this._initialize();
	}
	return this;
};
Chart.HBSMChart.prototype = $.extend(new Chart.Common.Graphic.GraphElement(), {
	/*
	 * override
	 */
	resizeComponents: function(width, height){
		this.canvasWidth = width;
		this.canvasHeight = height;
		
		this.graphCanvas.css({
			width: width,
			height: height
		});
		
		this.graph.resize(width, height);
	},
	/*
	 * override
	 */
	refresh: function(){
		var me = this;
		this.dataSource.refresh(function(){
			me.dataSource.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.REFRESH_PRESENTATION, null));
		});
	},

	/*
	 * interface for update culture
	 * @param cultureName {string} culture name string, such as "en_GB"
	 * @return null;
	 */
	setCulture: function(cultureName){
		var me = this;
		LocalizationManager.instance.setCurrentCulture(cultureName, function(){
			me.dataSource.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.SET_CULTURE, null));
		});
	},

	/*
	 * interface for push data mode
	 * @param jsonStr {string} data string, in JSON format.
	 * @return null;
	 */
	setData: function(jsonStr){
		this.dataSource.setData(jsonStr);
	},
	/*
	 * another interface for push data mode, call refresh directly.
	 */
	draw: function(){
		this.dataSource.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.REFRESH_PRESENTATION, null));
	},
	
	_initialize: function(){
		this.canvas = this.container.get(0);
		this.canvasWidth = this.container.width();
		this.canvasHeight = this.container.height();
		
		this._createElements();
		this._createComponents();
	},
	_createComponents: function(){
		this.dataSource = new Chart.Component.HBSMPushData();
		this.graph = new Chart.Component.HBSMGraph(this.graphCanvas, this.displayType);
		this.graph.setDataSource(this.dataSource);
		this.graph.collectionChildren();
		
		this.dataSource.collectionChildren();
		this.dataSource.addChild(this.graph);
		this.dataSource.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.INITIALIZE, null));
	},
	_createElements: function(){
		this.container.attr({
			"cid": this.cId
		});
		this.container.addClass("hbsm");
		this.graphCanvas = $($.Canvas.createDiv(this.container, "relative", 0, 0, this.canvasWidth, this.canvasHeight)).attr({
			"cid": this.cId
		});
		this.floatCanvas = $($.Canvas.createDiv(this.container, "absolute", 0, 0, 0, 0)).attr({
			"id": "phTip" + this.cId,
			"cid": this.cId
		});
	}
});

Chart.Component.HBSMPushData = function() {
    var today = new Date();
    today = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    this._rawData = new Dictionary();
	this._holdingWeightData = new Dictionary();
	this._holdingRawData = new Dictionary();
	this._dataSetting = [];
	this._gridLables = null;

	this.DEFAULT_OUT_RADIUS = 5;
	this.DEFAULT_IN_RADIUS = 3;
	this.DEFAULT_HOLDING_RADIUS = 3;

    var me = this;
	
	this._dataSetting.push({ key: "Item1", value: { color: "#FF0000", zcolor:"#9C9AD6", oradius: 5, iradius:3} });
    this._dataSetting.push({ key: "Item2", value: { color: "#A6BC09"} });
    this._dataSetting.push({ key: "Item3", value: { color: "#FEA620"} });
	

};
Chart.Component.HBSMPushData.prototype = $.extend(new Chart.Common.Command.CommandHandler(), new Chart.Interface.HBSMInterface(),{
	/*
	 * set data and option
	 * @param {string} in JSON format.
	 */
	setData: function(jsonStr){
		var d = +new Date();
       
		this.reset();
		
		var data = $.evalJSON(jsonStr);
		if (!data) {
			return;
		}
		
		//parse centroid and ownership zone
		var mainData = new Chart.HBSMChart.OwnerShipZoneRawData();
		mainData.style = data.Centroid.Position[0];
		mainData.size = data.Centroid.Position[1];
		mainData.rho = data.ShadeArea.Position[0];
		mainData.styleVar = data.ShadeArea.Position[1];
		mainData.sizeVar = data.ShadeArea.Position[2];
		mainData.zonePercentile = data.ShadeArea.Position[3];
		this._rawData.add("Item1", mainData);
		
		//parse datasetting
		var setting = {
			color: data.Centroid.Color,
			zcolor: data.ShadeArea.Color,
			oradius: data.Centroid.OuterRadius ? data.Centroid.OuterRadius : this.DEFAULT_OUT_RADIUS,
			iradius: data.Centroid.InnerRadius ? data.Centroid.InnerRadius : this.DEFAULT_IN_RADIUS
		};
		this._dataSetting.push({ key: "Item1", value: setting });
		
		//parse holding
		if (data.HoldingPoints && data.HoldingPoints.length > 0) {
			var holdingList = new Dictionary();
			for (var i = 0; i < data.HoldingPoints.length; i++) {
				var holding = data.HoldingPoints[i];
				if (holding) {
					var holdingId = "holding" + i;
					var holdingData = new Chart.HBSMChart.OwnerShipZoneRawData();
					holdingData.style = holding.Position[0];
					holdingData.size = holding.Position[1];
					holdingList.add(holdingId, {
						holdingId: holdingId,
						color: holding.Color,
						radius: holding.Radius ? holding.Radius : this.DEFAULT_HOLDING_RADIUS
					});
					this._holdingRawData.add(holdingId, holdingData);
				}
			}
			this._holdingWeightData.add("Item1",holdingList);
		}
		
		//parse labels
		if (data.Labels && data.Labels.VLabels && data.Labels.HLabels) {
			this._gridLables = {
				h: data.Labels.HLabels.Names,
				v: data.Labels.VLabels.Names
			};
		}		
		
		//parse chart setting.
		var setting = {
			chart: {
				option: {}
			}
		};
		
		if (data.Type != null && parseInt(data.Type, 10) >= 0) {
			setting.chart.option.displaystyle = data.Type;
		}
		
		if (data.BGColor) {
			Chart.Setting.Presentation.BG.serialize(setting, Chart.Setting.SettingItem.Chart, {
				color: data.BGColor
			});
		}
		
		this.executeCommand(
			new Chart.Common.Command.CommandArgs(
				null, 
				Chart.Common.Command.Commands.APPLY_CHART_SETTING, 
				{setting:setting}));
		
		ChartLogger.instance.write("[time-consuming] time consuming of set data interface: " + (new Date() - d));
	},
	/*
	 * hook function
	 */
	refresh: function(callback){
		if(this._rawData.count>0){
			var datalist = this._rawData.values();
			for (var i = 0; i < datalist.length; i++) {
				datalist[i].style = Math.random() * 300;
				datalist[i].size = Math.random() * 300;
				datalist[i].styleVar = Math.random() * 300;
				datalist[i].sizeVar = Math.random() * 300;
			}
		}
		if(callback && typeof(callback)== "function"){
			callback();
		}
	},
	/*
	 * clear all cache data.
	 */
	reset: function(){
		this._rawData.clear();
		this._holdingWeightData.clear();
		this._holdingRawData.clear();
		this._dataSetting = [];
		this._gridLables = null;
	},
	/*
     * override. filter commands.
     * @param arg {Chart.Common.Command.CommandArgs} content.
     * @return the handler event of target command.
     */
	getHandler: function(args){
		switch (args.command) {
			case Chart.Common.Command.Commands.ADD_INVESTMENT:
			case Chart.Common.Command.Commands.DELETE_ITEM:
			case Chart.Common.Command.Commands.REFRESH_PRESENTATION:
			case Chart.Common.Command.Commands.RESIZE:
			case Chart.Common.Command.Commands.INITIALIZE:
			case Chart.Common.Command.Commands.COMPONENT_STATUS_UPDATE:
			default:
				return this.defaultHandler;
		}
		return this.defaultHandler;
	},
	/*
     * default command handler, the purpose of this is the enable all commmand will be passed to children.
     * @param arg {Chart.Common.Command.CommandArgs} content.
     * @return null.
     */
	defaultHandler: function(args){
		//do nothing here.
	},
	/*
	 * override
	 * get ownership zone date dictionary, the key value is the pid of funds.
	 * @param none
	 * @return {Dictionary<string, OwnerShipZoneRawData>}
	 */
	getOwnerShipZoneRawData: function(){
		return this._rawData;
	},
	/*
	 * get funds' holding weight list.
	 * @param none
	 * @return {Dictionary<string, Dictionary<string, SingleHoldingData>>}
	 */
	getHoldingWeightData:function(){
		return this._holdingWeightData;
	},
	/*
	 * get holding's position data
	 * @param investmentId {string} target investment.
	 * @param holdingId {string} target holding id.
	 * @return {OwnerShipZoneRawData}
	 */
	getHoldingOwnerShipZoneRawData: function(investmentId, holdingId){
		return this._holdingRawData.tryGetValue(holdingId, null);
	},
	/*
	 * get horizonal and vertical labels
	 * @param none
	 * @return {{h:[],v:[]}}
	 * @require no
	 */
	getGridLabels: function(){
		return this._gridLables;
	},
	getInvestmentSetting: function(investmentId){
		var ret = null;
		for (var i = 0; i < this._dataSetting.length; i++) {
			if (this._dataSetting[i].key == investmentId) {
				ret = this._dataSetting[i].value;
				break;
			}
		}
		return ret;
	}
});

Chart.HBSMChart.DisplayType = {
    Standard: 0,
    Extended: 1
};
Chart.HBSMChart.OwnerShipZoneRawData = function(){
	this.date = new Date();
	this.rho = 0;
	this.style = 0;
	this.size = 0;
	this.styleVar = 0;
	this.sizeVar = 0;
	this.zonePercentile = 0;
};
Chart.HBSMChart.SingleHoldingData = function(){
	this.holdingId = "";
	this.holdingName = "";
	this.weight = 0;
};
