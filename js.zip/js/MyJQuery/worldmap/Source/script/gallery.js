var _codeField = null;
var _demoSize = {width: 800, height:600};

function openPlayground(obj){
	window.open('playground.html','','');
}
