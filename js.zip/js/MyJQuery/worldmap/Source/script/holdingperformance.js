Chart.HPChart = function(containerDOM){
	this.cId = +new Date();	
	this.container = containerDOM;
	
	this.dataSource = null;
	this.graph = null;
	
	this.graphCanvas = null;
	this.floatCanvas = null;
	
	this.canvasWidth = 0;
	this.canvasHeight = 0;
	
	if (containerDOM) {
		this._initialize();
	}
	return this;
};
Chart.HPChart.prototype = $.extend(new Chart.Common.Graphic.GraphElement(), {
	/*
	 * override
	 */
	resizeComponents: function(width, height){
		this.canvasWidth = width;
		this.canvasHeight = height;
		
		this.graphCanvas.css({
			width: width,
			height: height
		});
		
		this.graph.resize(width, height);
	},
	/*
	 * override
	 */
	refresh: function(){
		var me = this;
		this.dataSource.refresh(function(){
			me.dataSource.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.REFRESH_PRESENTATION, null));
		});
	},
	/*
	 * interface for push data mode
	 * @param jsonStr {string} data string, in JSON format.
	 * @return null;
	 */
	setData: function(jsonStr){
		this.dataSource.setData(jsonStr);
	},
	/*
	 * another interface for push data mode, call refresh directly.
	 */
	draw: function(){
		this.dataSource.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.REFRESH_PRESENTATION, null));
	},

	/*
	 * interface for update culture
	 * @param cultureName {string} culture name string, such as "en_GB"
	 * @return null;
	 */
	setCulture: function(cultureName){
		var me = this;
		LocalizationManager.instance.setCurrentCulture(cultureName, function(){
			me.dataSource.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.SET_CULTURE, null));
		});
	},

	_initialize: function(){
		this.canvas = this.container.get(0);
		this.canvasWidth = this.container.width();
		this.canvasHeight = this.container.height();
		
		this._createElements();
		this._createComponents();
	},
	_createComponents: function(){
		this.dataSource = new Chart.Component.HPData();
		this.graph = new Chart.Component.HPGraph(this.graphCanvas);
		this.graph.setDataSource(this.dataSource);
		this.graph.collectionChildren();
		
		this.dataSource.collectionChildren();
		this.dataSource.addChild(this.graph);
		this.dataSource.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.INITIALIZE, null));
	},
	_createElements: function(){
		this.container.attr({
			"cid": this.cId
		});
		this.container.addClass("holdingperformance");
		this.graphCanvas = $($.Canvas.createDiv(this.container, "relative", 0, 0, this.canvasWidth, this.canvasHeight)).attr({
			"cid": this.cId
		});
		/*
		this.floatCanvas = $($.Canvas.createDiv(this.container, "absolute", 0, 0, 0, 0)).attr({
			"id": "phTip" + this.cId,
			"cid": this.cId
		});
		*/
		this.floatCanvas = $("<div></div>").appendTo(this.container).attr({
			"id": "phTip" + this.cId,
			"cid": this.cId
		});
	}
});

Chart.Interface.HPChartInterface = function(){
};
Chart.Interface.HPChartInterface.prototype = {
    /*
     * get holding data dictionary. values in dictionay sorted by the first value.
     * @param none
     * @return {Dictionary<string, Pair<double>>} {first: weight, second: ytd}
     */
    getHoldingData: function(){
        return null;
    },
	/*
	 * get holding name by id
	 * @param holdingId {string}
	 * @return {string}
	 */
	getHoldingName: function(holdingId){
		return "";		
	},
	/*
	 * get context that will display in tooltip
	 * @param holdingId {string}
	 * @return {[string, string,...,string]}
	 */
	getFloatingTipContext: function(holdingId){
		return null;
	}
};

Chart.Component.HPData = function(){
	var today = new Date();
	today = new Date(today.getFullYear(), today.getMonth(), today.getDate());
	this._rawData = new Dictionary();
	this._holdingInfo = new Dictionary();
	this._prefix = {
		title: "",
		ytd: "YTD Total Return: ",
		weight: "Portfolio Weight: "
	};
	
	var me = this;
	
	/*
	this._rawData.add("holding1",{first: 5.23, second: 20});
	this._rawData.add("holding2",{first: 4.21, second: 10});
	this._rawData.add("holding3",{first: 2.00, second: -10});
	this._rawData.add("holding4",{first: 1.23, second: 12.5});
	this._rawData.add("holding5",{first: 0.70, second: 21.4});
	
	this._holdingInfo.add("holding1", {name: "Investment Holding1"});
	this._holdingInfo.add("holding2", {name: "Investment Holding2"});
	this._holdingInfo.add("holding3", {name: "Investment Holding3"});
	this._holdingInfo.add("holding4", {name: "Investment Holding4"});
	this._holdingInfo.add("holding5", {name: "Investment Holding5"});
	*/
};
Chart.Component.HPData.prototype = $.extend(new Chart.Common.Command.CommandHandler(), new Chart.Interface.HPChartInterface(),{
	/*
	 * set data and option
	 * @param {string} in JSON format.
	 */
	setData: function(jsonStr){
		var d = +new Date();
       
		this.reset();
		
		var data = $.evalJSON(jsonStr);
		if (!data) {
			return;
		}
		
		//parse holding data
		if (data.Holdings && data.Holdings.length > 0) {
			data.Holdings.sort(function(a, b){
				return b.Weight - a.Weight;
			});
			var len = data.Holdings.length;
			var holding = null, 
				holdingId ="";
			for (var i = 0; i < len; i++) {
				holding = data.Holdings[i];
				holdingId = "holding" + i.toString();
				this._rawData.add(holdingId, {
					first: holding.Weight ? holding.Weight : 0,
					second: holding.YTD ? holding.YTD : 0,
					radius: holding.Radius && parseFloat(holding.Radius) ? holding.Radius : 0
				});

				this._holdingInfo.add(holdingId, {
					name: holding.Name ? holding.Name : ""
				});
			}
		}
		
		//parse tooltip prefix
		if(data.HLabel && !$.isNull(data.HLabel.Prefix)){
			this._prefix.title = data.HLabel.Prefix;
		}
		if(data.YLabel && !$.isNull(data.YLabel.Prefix)){
			this._prefix.ytd = data.YLabel.Prefix;
		}
		if(data.WLabel && !$.isNull(data.WLabel.Prefix)){
			this._prefix.weight = data.WLabel.Prefix;
		} 
		//parse chart setting.
		var setting = {
			chart: {
				radius: {},
				option: {
					axis: {}
				}
			}
		};
		
		if(data.YLabel && !$.isNull(data.YLabel.Label)){
			setting.chart.option.axis.y = data.YLabel.Label;
		}
		if(data.WLabel && !$.isNull(data.WLabel.Label)){
			setting.chart.option.axis.x = data.WLabel.Label;
		}
		
		if (data.Legend && data.Legend.Radius && data.Legend.Radius.length > 0) {
			setting.chart.radius.legend = data.Legend.Radius;
		}
		
		if (data.Bubble) {
			if (data.Bubble.Radius && data.Bubble.Radius.length > 0) {
				setting.chart.radius.bubble = data.Bubble.Radius;
			}
			if(data.Bubble.Color){
				setting.chart.option.color = data.Bubble.Color;
			}
			if(data.Bubble.HColor){
				setting.chart.option.hcolor = data.Bubble.HColor;
			}
		}
		
		if (data.BGColor) {
			Chart.Setting.Presentation.BG.serialize(setting, Chart.Setting.SettingItem.Chart, {
				color: data.BGColor
			});
		}
		
		this.executeCommand(
			new Chart.Common.Command.CommandArgs(
				null, 
				Chart.Common.Command.Commands.APPLY_CHART_SETTING, 
				{setting:setting}));
		
		ChartLogger.instance.write("[time-consuming] time consuming of set data interface: " + (new Date() - d));
	},
	/*
	 * hook function
	 */
	refresh: function(callback){
		if(callback && typeof(callback)== "function"){
			callback();
		}
	},
	/*
	 * clear all cache data.
	 */
	reset: function(){
		this._rawData.clear();
		this._holdingInfo.clear();
		this._legendBars = [];
	},
	/*
     * override. filter commands.
     * @param arg {Chart.Common.Command.CommandArgs} content.
     * @return the handler event of target command.
     */
	getHandler: function(args){
		switch (args.command) {
			case Chart.Common.Command.Commands.ADD_INVESTMENT:
			case Chart.Common.Command.Commands.DELETE_ITEM:
			case Chart.Common.Command.Commands.REFRESH_PRESENTATION:
			case Chart.Common.Command.Commands.RESIZE:
			case Chart.Common.Command.Commands.INITIALIZE:
			case Chart.Common.Command.Commands.COMPONENT_STATUS_UPDATE:
				return this.defaultHandler;
			default:
				return this.defaultHandler;
		}
		return this.defaultHandler;
	},
	/*
     * default command handler, the purpose of this is the enable all commmand will be passed to children.
     * @param arg {Chart.Common.Command.CommandArgs} content.
     * @return null.
     */
	defaultHandler: function(args){
		//do nothing here.
	},
	/*
     * get holding data dictionary. values in dictionay sorted by the first value.
     * @param none
     * @return {Dictionary<string, Pair<double>>} {first: weight, second: ytd}
     */
    getHoldingData: function(){
        return this._rawData;
    },
	/*
	 * get holding name by id
	 * @param holdingId {string}
	 * @return {string}
	 */
	getHoldingName: function(holdingId){
		var info = this._holdingInfo.tryGetValue(holdingId, null);
		return info && info.name ? this._prefix.title + info.name : "";
	},
	/*
	 * get context that will display in tooltip
	 * @param holdingId {string}
	 * @return {[string, string,...,string]}
	 */
	getFloatingTipContext: function(holdingId){
		var ret = [], 
			data = this._rawData.tryGetValue(holdingId,null);
		if (data) {
			ret.push(String.format("{0}{1}%", this._prefix.ytd, LocalizationManager.instance.formatDecimal(data.second, 2)));
			ret.push(String.format("{0}{1}%", this._prefix.weight, LocalizationManager.instance.formatDecimal(data.first, 2)));
		}
		return ret;
	}
});

Chart.Component.HPGraph = function(target){
    this._placeHolder = target;
    this._placeHolder.css({
        "position": "relative",
        "background-color": "transparent",
        "cursor": "default"
    });
    this._margin = {
        left: 0,
        top: 0,
        right: 0,
        bottom: 0
    };
	this._bubbleColor = {
		normal: "#80CDD2DD",
		highlight: "#314563"
	};
	this._bubbleRadius = [31.5, 23, 15, 11.5, 9, 5.5];	//for graph
	this._bubbleRadius1 = [10.5, 9, 7.5, 6, 4.5, 3];	//for legend
	
	this.SEGMENTATION = 6;
	this.GRAPH_LEFT_MARGIN = 187;
	this.FOOTER_HEIGHT = 24;
	
	/*
	 * {
	 * 	id: string,
	 * 	x: double,
	 * 	y: double,
	 * 	radius: double
	 * }
	 */
	this._bubbleInfo = [];
	
    this._datasource = null;
    this._tooltipFactory = new Chart.Common.Controls.GraphRectTipFactory(target.attr("cid"));
	this._tooltip = null;
    
	this._coordinateCanvas = null;
    this._graphCanvas = null;
	this._legendCanvas = null;
    this._tooltipCanvas = null;
    this._messageCanvas = null;
	
	this.xAxisMapping = new Chart.Common.Coordinate.Double2DoubleLinearMapping();
    this.yAxisMapping = new Chart.Common.Coordinate.Double2DoubleLinearMapping();
    
    var mainGraph = this;
    
    this.Presentation = function(){
    };
    
    this.Presentation.GraphElement = function(){
    };
    this.Presentation.GraphElement.prototype = $.extend(new Chart.Common.Graphic.GraphElement(), {});
    
	/*
    this.Presentation.LegendArea = function(){
		this.canvas = mainGraph._legendCanvas;
		this.canvasRef = $(this.canvas);
		this.ctx = null;
		this._graphics = null;
		this.ballLayer = null;
		this.labelLayer = null;
		
		this.LABEL_OFFSET = 2;
		this.ITEM_MARGIN = 10;
		
		this._unitWeight = 0;
		
		var me = this;
		
		var _createElement = function(){
			var graphSize = {
				width: me.getWidth(),
				height: me.getHeight()
			};
			me.ballLayer = $.Canvas.create(me.canvasRef, "absolute", 0, 0, graphSize.width, graphSize.height);
			me.labelLayer = $.Canvas.createDiv(me.canvasRef, "absolute", 0, 0, graphSize.width, graphSize.height);
			me.ctx = me.ballLayer.getContext("2d");
			me._graphics = new $.Graphics(me.ctx);
		};
		
		_createElement();
	};
    this.Presentation.LegendArea.prototype = $.extend(new this.Presentation.GraphElement(), {
        getRange: function(xrange, yrange){
			this._unitWeight = xrange.second / mainGraph.SEGMENTATION;
			//this._unitWeight = Math.floor(this._unitWeight * 10) / 10;
			
			xrange.first = 0;
			//xrange.second = this._unitWeight * mainGraph.SEGMENTATION;
			
			var min = xrange.first;
			var max = xrange.second;
			var range = max - min;
			if (range == 0) {
				return;
			}
			var adjustedMax = max;
			var adjustedMin = min;
			var maxLableCount = mainGraph.SEGMENTATION;
			var factors = [0.01, 0.02, 0.025, 0.05, 0.075];
			var maxExponent = 20;
			
			for (var i = 0; i < maxExponent; i++) {
				for (var j = 0; j < factors.length; j++) {
					var factor = factors[j];
					var temp = factor * Math.pow(10, i);
					if (temp * maxLableCount > range) {
						adjustedMax = max + (temp - max % temp);
						
						var spaceCount = Math.floor((adjustedMax - min) / temp) +
						((adjustedMax - min) % temp == 0.0 ? 0 : 1);
						adjustedMin = adjustedMax - spaceCount * temp;
						
						if (spaceCount == maxLableCount) {
							xrange.first = adjustedMin;
							xrange.second = adjustedMax;
							return;
						}
					}
				}
			}
		},
        resizeComponents: function(width, height){
            this.ballLayer.width = width;
            this.ballLayer.height = height;
			this.labelLayer.width = width;
            this.labelLayer.height = height;
            $(this.ballLayer).css({
                width: width,
                height: height
            });
            $(this.labelLayer).css({
                width: width,
                height: height
            });
        },
        refresh: function(){
            var d = +new Date();
            this._drawLegend();
            ChartLogger.instance.write("[time-consuming] time consuming of drawing legend area: " + (new Date() - d));
        },
        reset: function(){
            this.ctx.clearRect(0, 0, this.getWidth(), this.getHeight());
            $(this.labelLayer).html("");
        },
        _drawLegend: function(){
			this.reset();
			
			var pos = {
				x: this.ITEM_MARGIN,
				y: Math.floor(this.getHeight() / 2)
			}, radius = 0;
			var maxWeight = this._unitWeight * mainGraph.SEGMENTATION;
			this._graphics.setNormalFill($.color.parse(mainGraph._bubbleColor.normal).toString());
			for (var i = mainGraph.SEGMENTATION; i > 0; i--) {
				radius = mainGraph.getBubbleRadius(this._unitWeight * i, maxWeight, 1);
				pos.x += radius;
				this._graphics.begin();
				this._graphics.drawCircle(pos, radius);
				this._graphics.end();
				pos.x += radius;
				pos.x += this.LABEL_OFFSET;
				
				var textStr = String.format("{0}% - {1}%", StrFormatter.getFormattedNumString(this._unitWeight * i, maxWeight, 1, true), StrFormatter.getFormattedNumString(this._unitWeight * (i - 1), maxWeight, 1, true));
				var textbox = $($.TextStudio.create(textStr, $(this.labelLayer), "absolute", pos.x, pos.y, null, null, "legend"));
				textbox.css({
					top: pos.y - textbox.height() / 2
				});
				pos.x += textbox.width();
				
				pos.x += this.ITEM_MARGIN;
			}
			
			$(this.ballLayer).css({
                left: this.getWidth()-pos.x
            });
            $(this.labelLayer).css({
                left: this.getWidth()-pos.x
            });
		}
    });
    */
    
	this.Presentation.CoordinateArea = function(){
		this.canvas = mainGraph._coordinateCanvas;
		this.canvasRef = $(this.canvas);
		this.ctx = null;
		this._graphics = null;
		this.lineLayer = null;
		this.labelLayer = null;
		this.labelRef = null;
		
		this.LABEL_OFFSET = 5;
		this._yMinLabelSpace = 30;
        this._ySpaceCount = 0;
		
		this._strokeThickness = 1;
        this._strokeColor = "#CCCCCC";
		this._strokeBaseLineColor = "#000000";
		this._label = {
			yaxis: "YTD Return %",
			xaxis: "% Portfolio Weight"
		};
		
		this._numberSetting = { decimalCount: 2, shortened: true };
		
		var me = this;
		
		var _createElement = function(){
			var graphSize = {
				width: me.getWidth(),
				height: me.getHeight()
			};
			me.lineLayer = $.Canvas.create(me.canvasRef, "absolute", 0, 0, graphSize.width, graphSize.height);
			me.labelLayer = $.Canvas.createDiv(me.canvasRef, "absolute", 0, 0, graphSize.width, graphSize.height);
			me.labelRef = $(me.labelLayer);
			me.ctx = me.lineLayer.getContext("2d");
			me._graphics = new $.Graphics(me.ctx);
		};
		
		_createElement();
	};
    this.Presentation.CoordinateArea.prototype = $.extend(new this.Presentation.GraphElement(), {
        applySetting: function(setting){
			if (setting && setting.chart) {
				if (setting.chart.option && setting.chart.option.axis) {
					if (!$.isNull(setting.chart.option.axis.x)) {
						this._label.xaxis = setting.chart.option.axis.x;
					}
					if (!$.isNull(setting.chart.option.axis.y)) {
						this._label.yaxis = setting.chart.option.axis.y;
					}
				}
			}
		},
		getRange: function(xrange, yrange){
			function _getxrange(){
				xrange.first = 0;
				
				var min = xrange.first;
				var max = xrange.second;
				var range = max - min;
				if (range == 0) {
					return;
				}
				var adjustedMax = max;
				var adjustedMin = min;
				var maxLableCount = mainGraph.SEGMENTATION;
				var factors = [0.01, 0.02, 0.025, 0.05, 0.075];
				var maxExponent = 20;
				
				for (var i = 0; i < maxExponent; i++) {
					for (var j = 0; j < factors.length; j++) {
						var factor = factors[j];
						var temp = factor * Math.pow(10, i);
						if (temp * maxLableCount > range) {
							adjustedMax = max + (temp - max % temp);
							
							var spaceCount = Math.floor((adjustedMax - min) / temp) +
							((adjustedMax - min) % temp == 0.0 ? 0 : 1);
							adjustedMin = adjustedMax - spaceCount * temp;
							
							if (spaceCount == maxLableCount) {
								xrange.first = adjustedMin;
								xrange.second = adjustedMax;
								return;
							}
						}
					}
				}
			}
			function _getyrange(){
				var min = yrange.first;
				var max = yrange.second;
				var range = max - min;
				if (range == 0) {
					return;
				}
				var adjustedMax = max;
				var adjustedMin = min;
				var maxLableCount = me._getYMaxMarkCount();
				var factors = [0.01, 0.02, 0.025, 0.05, 0.075];
				var maxExponent = 20;
				
				for (var i = 0; i < maxExponent; i++) {
					for (var j = 0; j < factors.length; j++) {
						var factor = factors[j];
						var temp = factor * Math.pow(10, i);
						if (temp * maxLableCount > range) {
							adjustedMax = max + (temp - max % temp);
							
							me._ySpaceCount = Math.floor((adjustedMax - min) / temp) +
							((adjustedMax - min) % temp == 0.0 ? 0 : 1);
							adjustedMin = adjustedMax - me._ySpaceCount * temp;
							
							if (me._ySpaceCount <= maxLableCount) {
								yrange.first = adjustedMin;
								yrange.second = adjustedMax;
								return;
							}
						}
					}
				}
			}
			
			var me = this;
			
			_getyrange();
			_getxrange();
		},
        resizeComponents: function(width, height){
            this.lineLayer.width = width;
            this.lineLayer.height = height;
			this.labelLayer.width = width;
            this.labelLayer.height = height;
            $(this.lineLayer).css({
                width: width,
                height: height
            });
            $(this.labelLayer).css({
                width: width,
                height: height
            });
        },
        refresh: function(){
            var d = +new Date();
            this._drawCoordinate();
            ChartLogger.instance.write("[time-consuming] time consuming of drawing coordinate area: " + (new Date() - d));
        },
        reset: function(){
            this.ctx.clearRect(0, 0, this.getWidth(), this.getHeight());
            $(this.labelLayer).html("");
        },
        _drawCoordinate: function(){
			this.reset();
			
			this._drawXMarks();
			this._drawYMarks();
		},
		_drawYMarks: function(){
			var mapping = mainGraph.yAxisMapping;
			var valueRange = mapping.getValueRange();
			var totalRange = valueRange.second - valueRange.first;
			var yValueSpace = totalRange / this._ySpaceCount;
			
			this._graphics.begin();
			this._graphics.setLineStyle(this._strokeThickness, this._strokeColor);
			
			var adjust = this._strokeThickness % 2 == 1 ? 0.5 : 0;
			var currentValue = valueRange.first;
			var y = Math.floor(mapping.getCoordinate(currentValue)) + adjust + mainGraph._margin.top;
			var lineLength = this.getWidth();
			this._graphics.drawLine(0, adjust, lineLength, adjust);
			this._graphics.drawLine(0, this.getHeight() - adjust, lineLength, this.getHeight()- adjust);
			this._graphics.drawLine(0, y, lineLength, y);
			$.TextStudio.create(
					this._label.xaxis, 
					this.labelRef, 
					"absolute", 
					this.LABEL_OFFSET, y + this.LABEL_OFFSET, 
					null, null, "coordinate");
			
			for (var i = 0; i < this._ySpaceCount; i++) {
				currentValue = currentValue + yValueSpace;
				if (Math.abs(currentValue) < 0.000001) {
					currentValue = 0;
				}
				
				y = Math.floor(mapping.getCoordinate(currentValue)) + adjust + mainGraph._margin.top;
				this._graphics.drawLine(0, y, lineLength, y);
				
				var text = StrFormatter.getFormattedNumString(currentValue, totalRange, this._numberSetting.decimalCount, this._numberSetting.shortened);
				if (i == this._ySpaceCount - 1 && this._label.yaxis) {
					text = this._label.yaxis;
				}
					
				$.TextStudio.create(
					text, 
					this.labelRef, 
					"absolute", 
					this.LABEL_OFFSET, y + this.LABEL_OFFSET, 
					null, null, "coordinate");
			}
			this._graphics.end();
			
			if (valueRange.first < 0) {
				//zero line
				y = Math.floor(mapping.getCoordinate(0)) + adjust + mainGraph._margin.top;
				this._graphics.begin();
				this._graphics.setLineStyle(this._strokeThickness, this._strokeBaseLineColor);
				this._graphics.drawLine(0, y, lineLength, y);
				this._graphics.end();
			}
		},
		_drawXMarks: function(){
			var mapping = mainGraph.xAxisMapping;
			var coordinateRange = mainGraph.yAxisMapping.getCoordinateRange();
			var valueRange = mapping.getValueRange();
			var totalRange = valueRange.second - valueRange.first;
			var valueSpace = totalRange / mainGraph.SEGMENTATION;
			
			this._graphics.begin();
			this._graphics.setLineStyle(this._strokeThickness, this._strokeColor);
			
			var adjust = this._strokeThickness % 2 == 1 ? 0.5 : 0;
			var currentValue = valueRange.first;
			var x = Math.floor(mapping.getCoordinate(currentValue)) + adjust;
			var y0= coordinateRange.first +mainGraph._margin.top,
				y = coordinateRange.first + mainGraph.FOOTER_HEIGHT + mainGraph._margin.top;
			//this._graphics.drawLine(x, coordinateRange.second+mainGraph._margin.top, x, y);
			//var text = StrFormatter.getFormattedNumString(currentValue, totalRange, this._numberSetting.decimalCount, this._numberSetting.shortened);
			//var textbox = $($.TextStudio.create(text, this.labelRef, "absolute", x, y + this.LABEL_OFFSET, null, null, "coordinate"));
			var text = null, textbox = null;
			
			for (var i = 0; i < mainGraph.SEGMENTATION; i++) {
				currentValue = currentValue + valueSpace;
				if (Math.abs(currentValue) < 0.000001) {
					currentValue = 0;
				}
				
				x = Math.floor(mapping.getCoordinate(currentValue)) + adjust;
				this._graphics.drawLine(x, coordinateRange.second+mainGraph._margin.top, x, y);
				
				text = StrFormatter.getFormattedNumString(currentValue, totalRange, this._numberSetting.decimalCount, this._numberSetting.shortened);
				textbox = $($.TextStudio.create(text, this.labelRef, "absolute", x+ this.LABEL_OFFSET, y0 + this.LABEL_OFFSET, null, null, "coordinate"));
			}
			this._graphics.end();
		},
		_getYMaxMarkCount: function(){
			return Math.floor((this.getHeight() - mainGraph._margin.top) / this._yMinLabelSpace);
		}
    });
	
    this.Presentation.GraphArea = function(){
        this.canvas = mainGraph._graphCanvas;
        this.ctx = this.canvas.getContext("2d");
        this._graphics = new $.Graphics(this.ctx);
    };
    this.Presentation.GraphArea.prototype = $.extend(new this.Presentation.GraphElement(), {
        getRange: function(xrange, yrange){
			if (!mainGraph._datasource || !mainGraph._datasource.getHoldingData) 
				return;
			var currentData = mainGraph._datasource.getHoldingData();
			if (!currentData || currentData.count <= 0) 
				return;
			
			var minWeight = Number.MAX_VALUE, 
				maxWeight = Number.MIN_VALUE, 
				minValue = Number.MAX_VALUE, 
				maxValue = Number.MIN_VALUE;
			var hasData = false;
			
			var currentValue = currentData.values();
			
			maxWeight = currentValue[0].first;
			minWeight = currentValue[currentData.count -1].first;
			
			$(currentValue).each(function(){
				hasData = true;
				if (this.second < minValue) {
					minValue = this.second;
				}
				if (this.second > maxValue) {
					maxValue = this.second;
				}
			});
			if (hasData) {
				if (maxValue == minValue || Math.abs(maxValue - minValue) < 0.000001) {
					if (maxValue == 0 || Math.abs(maxValue - 0) < 0.000001) {
						minValue = -10;
						maxValue = 10;
					}
					else {
						var adjust = Math.abs(maxValue * 0.1);
						maxValue = maxValue + adjust;
						minValue = minValue - adjust;
					}
				}
				
				if (maxWeight == minWeight || Math.abs(maxWeight - minWeight) < 0.000001) {
				
					if (maxWeight == 0 || Math.abs(maxWeight - 0) < 0.000001) {
						minWeight = -10;
						maxWeight = 10;
					}
					else {
						var adjust = Math.abs(maxWeight * 0.1);
						maxWeight = maxWeight + adjust;
						minWeight = minWeight - adjust;
					}
				}
				
				//adjust according to each holdings' radisu
				var changeRange = true, unitVal = 0, radius = 0, val = 0;
				while (changeRange) {
					changeRange = false;
					unitVal = (maxValue - minValue) / this.getHeight();
					radius = 0;
					val = 0;
					for (var i = 0, n = currentValue.length; i < n; i++) {
						radius = currentValue[i].radius ? currentValue[i].radius : mainGraph.getBubbleRadius(currentValue[i].first, maxWeight, 0);
						val = radius * unitVal;
						if (currentValue[i].second - val < minValue) {
							minValue = currentValue[i].second - val;
							changeRange = true;
							break;
						}
						if (currentValue[i].second + val > maxValue) {
							maxValue = currentValue[i].second + val;
							changeRange = true;
							break;
						}
					}
				}
				
				xrange.first = minWeight;
				xrange.second = maxWeight;
				yrange.first = minValue;
				yrange.second = maxValue;
			}
			else {
				xrange.first = 100;
				xrange.second = 0;
				yrange.first = -10;
				yrange.second = 10;
			}
		},
		resizeComponents: function(width, height){
        },
        refresh: function(){
            var d = +new Date();
            this._drawAreaGraph();
            ChartLogger.instance.write("[time-consuming] time consuming of drawing graph area: " + (new Date() - d));
        },
        reset: function(){
            this.ctx.clearRect(0, 0, this.getWidth(), this.getHeight());
			mainGraph._bubbleInfo = [];
        },
        _drawAreaGraph: function(){
			this.reset();
			
			if (!mainGraph._datasource || !mainGraph._datasource.getHoldingData) 
				return;
			var currentData = mainGraph._datasource.getHoldingData();
			if (!currentData || currentData.count <= 0) 
				return;
			
			var keys = currentData.keys();
			var holdings = currentData.values();
			var maxWeight = mainGraph.xAxisMapping.getValueRange().second;
			this._graphics.setLineStyle(0);
			this._graphics.setNormalFill($.color.parse(mainGraph._bubbleColor.normal).toString());
			for (var i = 0; i < currentData.count; i++) {
				var pos = {
					x: mainGraph.xAxisMapping.getCoordinate(holdings[i].first),
					y: mainGraph.yAxisMapping.getCoordinate(holdings[i].second)
				}, radius = holdings[i].radius?holdings[i].radius: mainGraph.getBubbleRadius(holdings[i].first, maxWeight, 0);
				mainGraph._bubbleInfo.push({
					id: keys[i],
					x: pos.x,
					y: pos.y,
					radius: radius
				});
				this._graphics.begin();
				this._graphics.drawCircle(pos, radius);
				this._graphics.end();
			}
		}
    });
    
    this.Presentation.MessagePanel = function(){
        this.canvas = mainGraph._messageCanvas;
    };
    this.Presentation.MessagePanel.prototype = $.extend(new this.Presentation.GraphElement(), {});
    
    this.Presentation.TooltipLayer = function(){
		this.canvas = mainGraph._tooltipCanvas;
		this.highlightLayer = null;
		this.ctx = null;
        this._graphics = null;
		
		this._currentDatum = null;
		
		var me = this;
		
		var _addEventHandler = function(){
			target.mousemove(_onMouseMove);
			target.mouseout(_onMouseLeave);
		};
		var _onMouseLeave = function(e){
			me._hideTip(e);
		};
		var _onMouseMove = function(e){
			var pt = $.getPosition(me.canvas, e);
			
			var datum = _findDatum(pt);
			if (datum) {
				me._currentDatum = datum; 
				me._highlightBubble(datum);
				var context = mainGraph._datasource.getFloatingTipContext(datum.id);
				if (context && context.length > 0) {
					me._showTip(mainGraph._datasource.getHoldingName(datum.id), context, e);
					return;
				}
			}
			
			if (me._currentDatum) {
				me._highlightBubble(null);
				me._hideTip(e);
				me._currentDatum = null;
			}
		};
		var _findDatum = function(pt){
			try {
				var nodeList = mainGraph._bubbleInfo;
				var pointCount = nodeList.length;
				if (pointCount < 1) {
					return null;
				}
				var begin = 0,
					end = pointCount - 1,
					shorten = true;
				if (nodeList[begin].x - nodeList[begin].radius <= pt.x &&
				nodeList[end].x + nodeList[end].radius >= pt.x) {
					/*
					while (shorten && (end - begin >= 2)){
						shorten = false;
						var mid = begin + Math.floor((end - begin) / 2);
						if (nodeList[mid].x - nodeList[mid].radius < pt.x) {
							begin = mid;
							shorten = true;
						}
						if (nodeList[mid].x + nodeList[mid].radius > pt.x) {
							end = mid;
							shorten = true;
						}
					}
					*/
					
					// found in horizental
					if (end - begin >= 0) {
						var ret = null, 
							datum = null, 
							lastDistance = Number.MAX_VALUE, 
							distance = 0;
						for (var i = begin; i <= end; i++) {
							datum = nodeList[i];
							distance = Math.pow(datum.x - pt.x, 2) + Math.pow(datum.y - pt.y, 2);
							if (distance < datum.radius * datum.radius) {
								if (distance < lastDistance) {
									ret = datum;
									lastDistance = distance;
								}
							}
						}
						
						return ret;
					}
				}
			} 
			catch (ex) {
			}
			
			return null;
		};
		var _createElement = function(){
			var graphSize = {
				width: me.getWidth(),
				height: me.getHeight()
			};
			me.highlightLayer = $.Canvas.create($(me.canvas), "absolute", 0, 0, graphSize.width, graphSize.height);
			me.ctx = me.highlightLayer.getContext("2d");
			me._graphics = new $.Graphics(me.ctx);
			
			mainGraph._tooltipFactory.setActiveRegion({
				x: 0,
				y: 0,
				width: graphSize.width,
				height: graphSize.height
			});
		};
		
		_createElement();
		_addEventHandler();
	};
    this.Presentation.TooltipLayer.prototype = $.extend(new this.Presentation.GraphElement(), {
		resizeComponents: function(width, height){
            this.highlightLayer.width = width;
            this.highlightLayer.height = height;
            $(this.highlightLayer).css({
                width: width,
                height: height
            });
			mainGraph._tooltipFactory.setActiveRegion({
				x: 0,
				y: 0,
				width: width,
				height: height
			});
        },
		reset: function(){
			this._hideTip(null);
		},
		_showTip: function(title, context, e){
			if (!mainGraph._tooltip) {
				mainGraph._tooltip = mainGraph._tooltipFactory.create();
			}
			mainGraph._tooltip.setTitle(title);
			mainGraph._tooltip.setContent(context);
			mainGraph._tooltip.popupAt($.getPosition(target.get(0), e));
		},
		_hideTip: function(e){
			if (mainGraph._tooltip) {
				mainGraph._tooltip.hide();
			}
		},
		_highlightBubble: function(bubbleInfo){
			this.ctx.clearRect(0, 0, this.getWidth(), this.getHeight());
			
			if (bubbleInfo) {
				this._graphics.begin();
				this._graphics.setLineStyle(0);
				this._graphics.setNormalFill($.color.parse(mainGraph._bubbleColor.highlight).toString());
				this._graphics.drawCircle({
					x: bubbleInfo.x,
					y: bubbleInfo.y
				}, bubbleInfo.radius);
				this._graphics.end();
			}
		}
	});
    
    this.Presentation.PresentationManager = function(){
        this._legendArea = null;
        this._graphArea = null;
		this._coordinateArea = null;
        this._messagePanel = null;
        this._tooltipLayer = null;
        this.canvas = mainGraph._placeHolder.get(0);
        
        var me = this;
        
        var createElement = function(){
            var totalSize = {
                width: mainGraph._placeHolder.width(),
                height: mainGraph._placeHolder.height()
            };
            var graphSize = {
                width: totalSize.width - mainGraph._margin.left - mainGraph._margin.right,
                height: totalSize.height - mainGraph._margin.top - mainGraph._margin.bottom
            };
			//mainGraph._legendCanvas = $.Canvas.createDiv(mainGraph._placeHolder, "absolute", mainGraph._margin.left, 0, graphSize.width, mainGraph._margin.top);
            mainGraph._coordinateCanvas = $.Canvas.createDiv(mainGraph._placeHolder, "absolute", mainGraph._margin.left, 0, graphSize.width, totalSize.height);
            mainGraph._graphCanvas = $.Canvas.create(mainGraph._placeHolder, "absolute", mainGraph._margin.left, mainGraph._margin.top, graphSize.width, graphSize.height-mainGraph.FOOTER_HEIGHT);
			mainGraph._tooltipCanvas = $.Canvas.createDiv(mainGraph._placeHolder, "absolute", mainGraph._margin.left, mainGraph._margin.top, graphSize.width, graphSize.height-mainGraph.FOOTER_HEIGHT);
            //mainGraph._messageCanvas = $.Canvas.create(mainGraph._placeHolder, "absolute", 0, 0, canvasWidth, canvasHeight);
			
			//$(mainGraph._coordinateCanvas).css({"background-color":"#CCCCCC"});
			//$(mainGraph._graphCanvas).css({"background-color":"#FF0000"});
			//$(mainGraph._legendCanvas).css({"background-color":"#EEEEEE"});
        };
        
        createElement();
    };
    this.Presentation.PresentationManager.prototype = $.extend(new Chart.Common.Command.CommandHandler(), new this.Presentation.GraphElement(), {
        initailizeCoordinateMapping: function(){
			var d = +new Date();
			var xrange = {
				first: 0,
				second: 0
			};
			var yrange = {
				first: 0,
				second: 0
			};
			var xcoordinate = {
				first: this._graphArea.getWidth() - 1,
				second: mainGraph.GRAPH_LEFT_MARGIN
			};
			var ycoordinate = {
				first: this._graphArea.getHeight() - 1,
				second: 0
			};
			
			this._graphArea.getRange(xrange, yrange);
			
			//extend yrange for the max bubble radius
			//var unit = Math.abs(yrange.second - yrange.first) / (ycoordinate.first - ycoordinate.second) * mainGraph._bubbleRadius[0];
			//yrange.first -= unit;
			//yrange.second += unit;
			
			this._coordinateArea.getRange(xrange, yrange);
			//this._legendArea.getRange(xrange, yrange);
			
			mainGraph.xAxisMapping.setCoordinateRange(xcoordinate);
			mainGraph.xAxisMapping.setValueRange(xrange);
			mainGraph.yAxisMapping.setCoordinateRange(ycoordinate);
			mainGraph.yAxisMapping.setValueRange(yrange);
			
			ChartLogger.instance.write("[time-consuming] time consuming of creating mapping: " + (new Date() - d));
		},
		applySetting: function(setting){
			if (setting && setting.chart) {
				if (setting.chart.radius) {
					if (setting.chart.radius.bubble && setting.chart.radius.bubble.length) {
						mainGraph._bubbleRadius = setting.chart.radius.bubble;
					}
					if (setting.chart.radius.legend && setting.chart.radius.legend.length) {
						mainGraph._bubbleRadius1 = setting.chart.radius.legend;
					}
				}
				if (setting.chart.option) {
					if (setting.chart.option.color) {
						mainGraph._bubbleColor.normal = setting.chart.option.color;
					}
					if (setting.chart.option.hcolor) {
						mainGraph._bubbleColor.highlight = setting.chart.option.hcolor;
					}
				}
			}
			var bgSetting = {};
			if (Chart.Setting.Presentation.BG.tryDeSerialize(setting, Chart.Setting.SettingItem.Chart, bgSetting)) {
				mainGraph._placeHolder.css({
					"background-color": bgSetting.color
				});
			}
			this._coordinateArea.applySetting(setting);
			//this._legendArea.applySetting(setting);
			this._graphArea.applySetting(setting);
			this._tooltipLayer.applySetting(setting);
		},
        refresh: function(){
            var me = this;
            setTimeout(function(){
                me.initailizeCoordinateMapping();
				me._coordinateArea.refresh();
                //me._legendArea.refresh();
                me._graphArea.refresh();
                //me._tooltipLayer.refresh();
            }, 10);
        },
        clearAll: function(){
            this._coordinateArea.reset();
			//this._legendArea.reset();
            this._graphArea.reset();
            this._tooltipLayer.reset();
            //this._messagePanel.onClearAll();
        },
        resizeComponents: function(width, height){
			var graphSize = {
				width: width - mainGraph._margin.left - mainGraph._margin.right,
				height: height - mainGraph._margin.top - mainGraph._margin.bottom
			};
			this._coordinateArea.resize(graphSize.width, height);
			//this._legendArea.resize(graphSize.width, mainGraph._margin.top);
			this._graphArea.resize(graphSize.width, graphSize.height - mainGraph.FOOTER_HEIGHT);
			this._tooltipLayer.resize(graphSize.width, graphSize.height - mainGraph.FOOTER_HEIGHT);
		},
        getHandler: function(args){
            switch (args.command) {
				case Chart.Common.Command.Commands.APPLY_CHART_SETTING:
					return this._onApplyChartSetting;
                case Chart.Common.Command.Commands.REFRESH_PRESENTATION:
                    return this._onRefreshPresentation;
                case Chart.Common.Command.Commands.RESIZE:
                    return this._onResize;
                case Chart.Common.Command.Commands.INITIALIZE:
                    return this._onInitialize;
                case Chart.Common.Command.Commands.COMPONENT_STATUS_UPDATE:
                    return this._onComponentStatusUpdate;
		        case Chart.Common.Command.Commands.SET_CULTURE:
		            return this._onSetCulture;
                default:
                    return null;
            }
        },
		_onApplyChartSetting: function(args){
			if (args && args.data && args.data.setting) {
				this.applySetting(args.data.setting);
				//this.refresh();
			}
		},
		_onSetCulture: function(args){
			if (args) {
				this.refresh();
			}
		},
        _onInitialize: function(args){
			this._coordinateArea = new mainGraph.Presentation.CoordinateArea();
            //this._legendArea = new mainGraph.Presentation.LegendArea();
            this._graphArea = new mainGraph.Presentation.GraphArea();
            //this._messagePanel = new mainGraph.Presentation.MessagePanel();
            this._tooltipLayer = new mainGraph.Presentation.TooltipLayer();
        },
        _onRefreshPresentation: function(args){
            this.refresh();
        },
        _onResize: function(args){
            if (args && args.data && args.data.width && args.data.height) {
                this.resize(args.data.width, args.data.height);
            }
            this.refresh();
        },
        _onComponentStatusUpdate: function(args){
            if (args && args.data && args.data.status) {
                switch (args.data.status) {
                    case Chart.Common.Command.ComponentStatus.ClearAll:
                        this.clearAll();
                        break;
                    default:
                        break;
                }
            }
        }
    });
    
    var initializeEx = function(){
        mainGraph._presentation = new mainGraph.Presentation.PresentationManager();
    };
    
    initializeEx();
};
Chart.Component.HPGraph.prototype = $.extend(new Chart.Common.Command.CommandHandler(), {
    defaultHandler: function(args){
        //do nothing here.
    },
    getHandler: function(args){
        return this.defaultHandler;
    },
    collectionChildren: function(){
        this.interactiveChildren = [this._presentation];
    },
    setDataSource: function(datasource){
        this._datasource = datasource;
    },
    resize: function(width, height){
        this._presentation.resize(width, height);
        this._presentation.refresh();
    },
	/*
	 * get radius by weight
	 * @param weight {double}
	 * @param maxWeighgt {double}
	 * @param type {int} 0 = graph; 1= legend;
	 * @return radius
	 */
	getBubbleRadius: function(weight, maxWeight, type){
		var array = this._bubbleRadius;
		if (type == 1) {
			array = this._bubbleRadius1;
		}
		var length = array.length, unitWeight = maxWeight / this.SEGMENTATION, quote = 0;
		for (var i = this.SEGMENTATION; i > 0; i--) {
			quote = unitWeight * i;
			if (weight >= quote) {
				return array[(this.SEGMENTATION - i) % length];
			}
		}
		return array[length - 1];
	}
});

