Chart.EfficientFrontier = function(containerDOM){
	this.cId = +new Date();	
	this.container = containerDOM;
	
	this.data = null;
	this.graph = null;
	
	this.graphCanvas = null;
	this.floatCanvas = null;
	
	this.canvasWidth = 0;
	this.canvasHeight = 0;
	
	this.options = {}; 
    this.options.showSelectedPortfolio = function(){};
	this.options.showModelPortfolio = function(){};
	
	if (containerDOM) {
		this._initialize();
	}
	return this;
};
Chart.EfficientFrontier.prototype = $.extend(new Chart.Common.Graphic.GraphElement(), {
	/*
	 * override
	 */
	resizeComponents: function(width, height){
		this.canvasWidth = width;
		this.canvasHeight = height;
		
		this.graphCanvas.css({
			width: width,
			height: height
		});
		
		this.graph.resize(width, height);
	},
	/*
	 * override
	 */
	/*
	refresh: function(){
		var me = this;
		this.data.refresh(function(){
			me.data.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.REFRESH_PRESENTATION, null));
		});
	},
	*/
	/*
	 * 
	 */
	showAssetClasses: function(){
		this.graph.setAssetVisibility(true);
	},
	/*
	 * 
	 */
	hideAssetClasses: function(){
		this.graph.setAssetVisibility(false);
	},
	/*
	 * 
	 */
	getCurrentPortfolioReturn: function(){
		return this.data.getCurrentDataLength() - this.graph.getSelectedIndex() - 1;
	},
	/*
	 * 
	 */
	setFoundSelectedModel: function(expRet, stdDev){
		this.data.setFrontierAsSeletedModel(expRet, stdDev);
	},
	/*
	 * 
	 */
	setSelectedPoint: function(expRet, stdDev, assetContent, pointType){
		
	},
	/*
	 * 
	 */
	setSelectedAsTarget: function(){
		this.data.setSelectedAsTarget(this.graph.getSelectedIndex());
	},
	/*
	 * 
	 */
	setTargetPoint: function(expRet, stdDev){
		this.data.setTargetPoint(expRet, stdDev);
	},
	/*
	 * 
	 */
	setAssetClasses: function(strXml){
		this.data.setAssetClasses(strXml);
	},
	/*
	 * interface for update culture
	 * @param cultureName {string} culture name string, such as "en_GB"
	 * @return null;
	 */
	setCulture: function(cultureName){
		var me = this;
		LocalizationManager.instance.setCurrentCulture(cultureName, function(){
			me.data.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.SET_CULTURE, null));
		});
	},
	/*
	 * interface for push data mode
	 * @param strXml {string} data string, in xml format.
	 * @return null;
	 */
	setData: function(strXml){
		this.data.setData(strXml);
	},
	/*
	 * another interface for push data mode, call refresh directly.
	 */
	draw: function(){
		this.data.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.REFRESH_PRESENTATION, null));
	},
	
	_initialize: function(){
		this.canvas = this.container.get(0);
		this.canvasWidth = this.container.width();
		this.canvasHeight = this.container.height();
		
		this._createElements();
		this._createComponents();
	},
	_createComponents: function(){
		this.data = new Chart.Component.EFData();
		this.graph = new Chart.Component.EFGraph(this.graphCanvas);
		this.graph.options = this.options;
		this.graph.setDataSource(this.data);
		this.graph.collectionChildren();
		
		this.data.collectionChildren();
		this.data.addChild(this.graph);
		this.data.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.INITIALIZE, null));
	},
	_createElements: function(){
		this.container.attr({
			"cid": this.cId
		});
		this.container.addClass("efficientfrontier");
		this.graphCanvas = $($.Canvas.createDiv(this.container, "relative", 0, 0, this.canvasWidth, this.canvasHeight)).attr({
			"cid": this.cId
		});
		/*
		this.floatCanvas = $($.Canvas.createDiv(this.container, "absolute", 0, 0, 0, 0)).attr({
			"id": "phTip" + this.cId,
			"cid": this.cId
		});
		*/
		this.floatCanvas = $("<div></div>").appendTo(this.container).attr({
			"id": "phTip" + this.cId,
			"cid": this.cId
		});
	}
});

Chart.Interface.EFChartInterface = function(){
};
Chart.Interface.EFChartInterface.prototype = {
	/*
	 * get axises' value range
	 * @param none
	 * @return {[xfirst,xsecond,yfirst,ysecond]}
	 */
    getValueRange: function(){
		
	},
	/*
	 * 
	 */
	getRiskRange:function(){
		
	},
	/*
     * get bar data dictionary.
     * @param none
     * @return {[{key:itemkey, value:GroupDataRecord<double>}]}
     */
    getCurrentData: function(){
        return null;
    },
	/*
	 * get context that will display in tooltip
	 * @param itemkey {string}
	 * @param scale {int}
	 * @return {[string, string,...,string]}
	 */
	getFloatingTipContext: function(itemkey, scale){
		return null;
	}
};

Chart.Component.EFData = function(){
	this._frontier = [];
    this._models = [];
	this._assetClasses = [];
	this._riskRanges = [];
	this._maxRet = 0;
	this._maxDev = 0;
	this._minDev = 0;
	this._minRet = 0;
	this._intervalRet = 0;
	this._intervalDev = 0;
	this._proposedKind = "";
	this._pointNumber = 0;
	this._riskScore = 0;
	
	var me = this;
};
Chart.Component.EFData.prototype = $.extend(new Chart.Common.Command.CommandHandler(), new Chart.Interface.EFChartInterface(),{
	/*
	 * 
	 */
	setAssetClasses: function(strXml){
		this._assetClasses = [];
		
		var setting = $(strXml);
		if(!setting){
			return;
		}
		
 		var nodelist = setting.find("AssetClasses col");
		if (!nodelist || nodelist.length <= 0) {
			return;
		}
		
		var node = null;
		var asset = null;
		for(var i=0;i<nodelist.length;i++){
			node = $(nodelist.get(i));
			asset = {};
			asset.id = node.attr("id");
			asset.ret = Chart.Common.Util.NumberUtil.parseRawDouble(node.attr("return"),0.0);
			asset.dev = Chart.Common.Util.NumberUtil.parseRawDouble(node.attr("stddev"),0.0);
			asset.color = $.color.parse(node.attr("color"));
			asset.name = node.text();
			this._assetClasses.push(asset);
		}
		node = null;
		asset = null;
	},
	/*
	 * interface for push data mode
	 * @param strXml {string} data string, in xml format.
	 * @return null;
	 */
	setData: function(strXml){
		var d = +new Date();
       
		this.reset();
		
		var data = $(strXml);
		if(!data){
			return;
		}
		
		this._parseBasicInformation(data);
		this._parseRiskRanges(data);
		this._parsePortfolio(data);
		this._parseModel(data);
		
		ChartLogger.instance.write("[time-consuming] time consuming of set data interface: " + (new Date() - d));
	},
	/*
	 * 
	 */
	setFrontierAsSeletedModel: function(expRet, stdDev){
		var index = this.getCurrentIndex(stdDev, true);
		
		if (index >= 0) {
			var datum = this._frontier[index];
			var found = false;
			
			this._updateModelPortfolio("selected",datum);
			
			this.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.REFRESH_PRESENTATION, null));
		}
	},
	/*
	 * 
	 */
	setSelectedAsTarget: function(selectedIndex){
		var datum = null;
		if (selectedIndex >= 0 && selectedIndex < this._frontier.length) {
			datum = this._frontier[selectedIndex];
		}
		else {
			var selectedmodel = this._findModelByType("selected");
			if (selectedmodel) {
				datum = selectedmodel.portfolio;
			}
		}
		
		if (datum) {
			this._updateModelPortfolio("selected", datum);
			this._updateModelPortfolio("target", datum);
			
			this.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.REFRESH_PRESENTATION, null));
		}
		
	},
	/*
	 * 
	 */
	setTargetPoint: function(expRet, stdDev){
		var model = this._findModelByType("target");
		if (model && model.portfolio) {
			model.portfolio.ret = expRet;
			model.portfolio.dev = stdDev;
			
			this.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.REFRESH_PRESENTATION, null));
		}
	},
	/*
	 * hook function
	 */
	refresh: function(callback){
		if(callback && typeof(callback)== "function"){
			callback();
		}
	},
	/*
	 * clear all cache data.
	 */
	reset: function(){
		this._frontier = [];
		this._models = [];
		//this._assetClasses = [];
		this._riskRanges = [];
		this._maxRet = 0;
		this._maxDev = 0;
		this._minDev = 0;
		this._minRet = 0;
		this._intervalRet = 0;
		this._intervalDev = 0;
		this._proposedKind = "";
		this._pointNumber = 0;
		this._riskScore = 0;
	},
	/*
     * override. filter commands.
     * @param arg {Chart.Common.Command.CommandArgs} content.
     * @return the handler event of target command.
     */
	getHandler: function(args){
		switch (args.command) {
			case Chart.Common.Command.Commands.ADD_INVESTMENT:
			case Chart.Common.Command.Commands.DELETE_ITEM:
			case Chart.Common.Command.Commands.REFRESH_PRESENTATION:
			case Chart.Common.Command.Commands.RESIZE:
			case Chart.Common.Command.Commands.INITIALIZE:
			case Chart.Common.Command.Commands.COMPONENT_STATUS_UPDATE:
				return this.defaultHandler;
			default:
				return this.defaultHandler;
		}
		return this.defaultHandler;
	},
	/*
     * default command handler, the purpose of this is the enable all commmand will be passed to children.
     * @param arg {Chart.Common.Command.CommandArgs} content.
     * @return null.
     */
	defaultHandler: function(args){
		//do nothing here.
	},
	/*
	 * get axises' value range
	 * @param none
	 * @return {[xfirst,xsecond,yfirst,ysecond]}
	 */
    getValueRange: function(){
		return [this._minDev, this._maxDev, this._minRet, this._maxRet];
	},
	/*
	 * get axises' scaler
	 * @param none
	 * @return {[xscale, yscale]}
	 */
	getScale: function(){
		return [this._intervalDev, this._intervalRet];
	},
	/*
	 * 
	 */
	getRiskScore:function(){
		return this._riskScore;
	},
	/*
	 * 
	 */
	getRiskRange:function(){
		return this._riskRanges;
	},
	/*
	 * 
	 */
	getAssetClasses: function(){
		return this._assetClasses;
	},
	/*
	 * 
	 */
	getModels:function(){
		return this._models;
	},
	/*
     * get bar data dictionary.
     * @param none
     * @return {[{key:itemkey, value:GroupDataRecord<double>}]}
     */
    getCurrentData: function(){
        return this._frontier;
    },
	/*
	 * 
	 */
	getCurrentDataLength: function(){
		if(this._frontier){
			return this._frontier.length;
		}
		return 0;
	},
	/*
	 * 
	 */
	getCurrentIndex: function(targetDev, isExactly){
		if (!this._frontier || this._frontier.length <= 0) 
			return -1;
		
		var index = -1, len = this._frontier.length;
		
		if (isExactly && (this._frontier[0].dev > targetDev || this._frontier[len - 1].dev < targetDev)) {
			return -1;
		}
		
		if (this._frontier[0].dev.equalWith(targetDev) || this._frontier[0].dev > targetDev) {
			index = 0;
		}
		else 
			if (this._frontier[len - 1].dev.equalWith(targetDev) || this._frontier[len - 1].dev < targetDev) {
				index = len - 1;
			}
			else {
				var begin = 0;
				var end = len - 1;
				while (end - begin >= 2) {
					var mid = begin + Math.floor((end - begin) / 2);
					if (this._frontier[mid].dev < targetDev) {
						begin = mid;
					}
					else {
						end = mid;
					}
				}
				if (this._frontier[begin].dev.equalWith(targetDev)) {
					index = begin;
				}
				else {
					index = end;
					
					if(isExactly && !this._frontier[end].dev.equalWith(targetDev)){
						index = -1;
					}
				}
			}
		
		return index;
	},
	/*
	 * get context that will display in tooltip
	 * @param itemkey {string}
	 * @param scale {int}
	 * @return {[string, string,...,string]}
	 */
	getFloatingTipContext: function(itemkey, scale){
		//return null;
	},
	
	/*
	 * 
	 */
	_findModelByType: function(type){
		if (this._models && this._models.length > 0) {
			var lowerType = type.toLowerCase(), len = this._models.length;
			for (var i=0; i < len; i++) {
				if (this._models[i].type.toLowerCase() == lowerType) {
					return this._models[i];
				}
			}
		}
		return null;
	},
	/*
	 * 
	 */
	_updateModelPortfolio: function(type, portfolioDatum){
		var model = this._findModelByType(type)
		if (model) {
			model.portfolio = this._copyPortfolioPoint(portfolioDatum);
		}
		else {
			model = {};
			model.id = "";
			model.name = "";
			model.type = type;
			model.portfolio = this._copyPortfolioPoint(portfolioDatum);
			this._models.push(model);
		}
	},
	_copyPortfolioPoint: function(sourcePoint){
		var point = {};
		
		point.ret = sourcePoint.ret;
		point.dev = sourcePoint.dev;
		point.portfolioIds = sourcePoint.portfolioIds;
		point.portfolioValues = sourcePoint.portfolioValues;
		
		return point;
	},
	_parseBasicInformation: function(data){
		var axis = data.find("axis");
		if (axis && axis.length > 0) {
			this._maxDev = Chart.Common.Util.NumberUtil.parseRawDouble(axis.attr("maxdev"));
			this._maxRet = Chart.Common.Util.NumberUtil.parseRawDouble(axis.attr("maxret"));
			if (axis.attr("retscale")) {
				this._intervalRet = parseInt(axis.attr("retscale"));
			}
			else {
				this._intervalRet = 2;
			}
			if (axis.attr("devscale")) {
				this._intervalDev = parseInt(axis.attr("devscale"));
			}
			else {
				this._intervalDev = 5;
			}
			var retAdjust = this._intervalRet * 10;
			var devAdjust = this._intervalDev * 10;
			if (axis.attr("maxretneg")) {
				this._minRet = Chart.Common.Util.NumberUtil.parseRawDouble(axis.attr("maxretneg"), 0.0);
				if (this._minRet < 0) {
					this._minRet = (-retAdjust - (this._minRet * 10 % retAdjust) + this._minRet * 10) / 10;
					//this._minRet = (-20 - (this._minRet * 10 % 20) + this._minRet * 10) / 10;
				}
				else {
					this._minRet = (this._minRet * 10 - (this._minRet * 10 % retAdjust)) / 10;
					//this._minRet = (this._minRet * 10 - (this._minRet * 10 % 20)) / 10;	
				}
			}
			else {
				this._minRet = 0;
			}
			if (axis.attr("maxdevneg")) {
				this._minDev = Chart.Common.Util.NumberUtil.parseRawDouble(axis.attr("maxdevneg"), 0.0);
				if (this._minDev < 0) {
					//this._minDev = (-50 - (this._minDev * 10 % 50) + this._minDev * 10) / 10;
					this._minDev = (-devAdjust - (this._minDev * 10 % devAdjust) + this._minDev * 10) / 10;
				}
				else {
					//this._minDev = (this._minDev * 10 - (this._minDev * 10 % 50)) / 10;	
					this._minDev = (this._minDev * 10 - (this._minDev * 10 % devAdjust)) / 10;
				}
			}
			else {
				this._minDev = 0;
			}
			
			//this._maxDev = (50 - (this._maxDev * 10 % 50) + this._maxDev * 10) / 10;
			//this._maxRet = (20 - (this._maxRet * 10 % 20) + this._maxRet * 10) / 10;
			this._maxDev = (devAdjust - (this._maxDev * 10 % devAdjust) + this._maxDev * 10) / 10;
			this._maxRet = (retAdjust - (this._maxRet * 10 % retAdjust) + this._maxRet * 10) / 10;
			this._pointNumber = Math.max(1, parseInt(axis.attr("row")));
		}
		this._proposedKind = data.attr("isproposed") ? data.attr("isproposed") : "";
	},
	_parseRiskRanges: function(data){
		var node = data.find("RiskRanges");
		if (node && node.length > 0) {
			this._riskScore = parseInt(node.attr("riskscore"));
			var ranges = node.find("RiskRange");
			if (ranges && ranges.length > 0) {
				this._riskRanges = [];
				var me = this;
				ranges.each(function(){
					me._riskRanges.push(Chart.Common.Util.NumberUtil.parseRawDouble($(this).attr("v"), 0.0));
				});
			}
		}
	},
	_parsePortfolio: function(data){
		var portfolioList = data.find("EFrontResult row");
		if (portfolioList && portfolioList.length > 0) {
			var me = this;
			portfolioList.each(function(){
				me._frontier.push(me._parsePoint($(this)));
			});
			this._frontier.sort(function(a, b){
				return a.dev - b.dev;
			});
		}
	},
	_parseModel: function(data){
		var models = data.find("usermix");
		if (models && models.length > 0) {
			var me = this;
			models.each(function(){
				var model = {};
				var node = $(this);
				model.id = node.attr("id");
				model.name = node.attr("name");
				model.type = node.attr("type");
				model.portfolio = me._parsePoint(node);
				me._models.push(model);
			});
		}
	},
	_parsePoint: function(node){
		var point = {};
		
		point.ret = Chart.Common.Util.NumberUtil.parseRawDouble(node.attr("return"), 0.0);
		point.dev = Chart.Common.Util.NumberUtil.parseRawDouble(node.attr("stddev"), 0.0);
		point.portfolioIds = [];
		point.portfolioValues = [];
		
		var assets = node.children();
		if (assets && assets.length > 0) {
			var count = assets.length;
			assets.each(function(){
				var node = $(this);
				point.portfolioIds.push(node.attr("id"));
				point.portfolioValues.push(Chart.Common.Util.NumberUtil.parseRawDouble(node.text(), 0.0));
			});
		}
		
		return point;
	}
});

Chart.Component.EFGraph = function(target){
    this._placeHolder = target;
    this._placeHolder.css({
        "position": "relative",
        "background-color": "transparent",
        "cursor": "default"
    });
    this._margin = {
        left: 5,
        top: 0,
        right: 0,
        bottom: 0
    };
	this.HEADER_HEIGHT = 25;
	this.FOOTER_HEIGHT = 35;
	this.SLIDER_HEIGHT = 60;
	
	this.options = {};
	
	this._barInfo = [];
    this._datasource = null;
    this._tooltipFactory = new Chart.Common.Controls.BasicTipFactory(target.attr("cid"));
	this._tooltip = null;
    
	this._contextCanvas = null;
	this._coordinateCanvas = null;
    this._graphCanvas = null;
	this._graphCanvas1 = null;
    this._tooltipCanvas = null;
    this._messageCanvas = null;
	this._sliderCanvas = null;
	this._selection = null;
	
	this.xAxisMapping = new Chart.Common.Coordinate.Double2DoubleLinearMapping();
    this.yAxisMapping = new Chart.Common.Coordinate.Double2DoubleLinearMapping();
    
    var mainGraph = this;
    
    this.Presentation = function(){
    };
    
    this.Presentation.GraphElement = function(){
    };
    this.Presentation.GraphElement.prototype = $.extend(new Chart.Common.Graphic.GraphElement(), {
		updateSelection: function(dev, ret, index){
		}
	});
        
	this.Presentation.CoordinateArea = function(){
		this.canvas = mainGraph._coordinateCanvas;
		this.canvasRef = $(this.canvas);
		this.ctx = null;
		this._graphics = null;
		this.lineLayer = null;
		this.labelLayer = null;
		this.labelRef = null;
		
		this.LABEL_OFFSET = 1;
		
		this._strokeThickness = 1;
        this._strokeColor = "#CCCCCC";
        
        this._showXLines = true;
        this._showYLines = true;
		
		this._fillcolorNormal = "#E0E8F0"
		this._fillcolorAlt = "#E8F3FA"
		
		this._numberSetting = { decimalCount: 0, shortened: false };
		
		var me = this;
		
		var _createElement = function(){
			var graphSize = {
				width: me.getWidth(),
				height: me.getHeight()
			};
			me.lineLayer = $.Canvas.create(me.canvasRef, "absolute", 0, 0, graphSize.width, graphSize.height);
			me.labelLayer = $.Canvas.createDiv(me.canvasRef, "absolute", 0, 0, graphSize.width, graphSize.height);
			me.labelRef = $(me.labelLayer);
			me.ctx = me.lineLayer.getContext("2d");
			me._graphics = new $.Graphics(me.ctx);
		};
		
		_createElement();
	};
    this.Presentation.CoordinateArea.prototype = $.extend(new this.Presentation.GraphElement(), {
        applySetting: function(setting){
			if (setting) {
				var numSetting = {};
				if(Chart.Setting.Presentation.NumSetting.tryDeSerialize(setting, Chart.Setting.SettingItem.Chart, numSetting)){
					this._numberSetting.decimalCount = numSetting.decimalCount;
					this._numberSetting.shortened = numSetting.shortened;	
				}
			}
		},
		getRange: function(xrange, yrange){
		},
        resizeComponents: function(width, height){
            $.Canvas.resize($(this.lineLayer), width, height);
            $.Canvas.resize($(this.labelLayer), width, height);
        },
        refresh: function(){
            var d = +new Date();
            this._drawCoordinate();
            ChartLogger.instance.write("[time-consuming] time consuming of drawing coordinate area: " + (new Date() - d));
        },
        reset: function(){
            this.ctx.clearRect(0, 0, this.getWidth(), this.getHeight());
            $(this.labelLayer).html("");
        },
        _getYMaxMarkCount: function(){
			return Math.floor(this.getHeight() / this._yMinLabelSpace);
		},
        _drawCoordinate: function(){
			this.reset();
			
			this._drawTitle();
			this._drawBG();
			this._drawXMarks();
			this._drawYMarks();
		},
		_drawTitle: function(){
			var text = LocalizationManager.instance.getLabel("return","Expected Return");
			var tb = $($.TextStudio.create(text, this.labelRef, "absolute", this.LABEL_OFFSET, 0, null, null, "coordinate"));
			tb.css({
				top: mainGraph.yAxisMapping.getCoordinateRange().second - tb.height()- this.LABEL_OFFSET
			});
			
			text = LocalizationManager.instance.getLabel("deviation","Standard Deviation");
			tb = $($.TextStudio.create(text, this.labelRef, "absolute", this.LABEL_OFFSET, this.getHeight()-20+this.LABEL_OFFSET, null, null, "coordinate"));
		},
		_drawBG: function(){
			var mapping = mainGraph.xAxisMapping;
			var xcoordinateRange = mapping.getCoordinateRange();
			
			if (!mainGraph._datasource || !mainGraph._datasource.getRiskRange) 
				return;
			
			var ycoordinateRange = mainGraph.yAxisMapping.getCoordinateRange(),
				top = ycoordinateRange.second, bottom = ycoordinateRange.first,
				left = xcoordinateRange.first, right = xcoordinateRange.second;
			
			var range = mainGraph._datasource.getRiskRange();
			if ($.isArray(range) && range.length >= 0) {
				for (var i = 0; i < range.length; i++) {
					right = mapping.getCoordinate(range[i]);
					right = right > xcoordinateRange.second ? xcoordinateRange.second : right;
					this._graphics.begin();
					this._graphics.setLineStyle(0);
					this._graphics.setNormalFill(i % 2 == 0 ? this._fillcolorNormal : this._fillcolorAlt);
					this._graphics.drawRectangle(left, top, right - left, bottom - top);
					this._graphics.end();
					left = right;
				}
			}
			else {
				this._graphics.begin();
				this._graphics.setLineStyle(0);
				this._graphics.setNormalFill(this._fillcolorNormal);
				this._graphics.drawRectangle(left, top, right - left, bottom - top);
				this._graphics.end();
			}
		},
		_drawYMarks: function(){
			var mapping = mainGraph.yAxisMapping;
			var valueRange = mapping.getValueRange();
			var totalRange = valueRange.second - valueRange.first;
			var yValueSpace = 2;
			
			this._graphics.begin();
			this._graphics.setLineStyle(this._strokeThickness, this._strokeColor);
			
			var adjust = this._strokeThickness % 2 == 1 ? 0.5 : 0,
				currentValue = valueRange.first,
				x = this.LABEL_OFFSET + adjust,
				y = Math.floor(mapping.getCoordinate(currentValue)) + adjust,
				lineLength = this._showYLines?this.getWidth():mainGraph.xAxisMapping.getCoordinateRange().first,
				baseLineLength = (!this._showXLines && !this._showYLines)?this.getWidth():lineLength,
				length = Math.floor(totalRange/yValueSpace);
			this._graphics.drawLine(0, y, baseLineLength, y);
			
			var text = "";
			for (var i = 0; i < length; i++) {
				currentValue = currentValue + yValueSpace;
				if (Math.abs(currentValue) < 0.000001) {
					currentValue = 0;
				}
				
				y = Math.floor(mapping.getCoordinate(currentValue)) + adjust;
				this._graphics.drawLine(0, y, lineLength, y);
				text = StrFormatter.getFormattedNumString(currentValue, totalRange, this._numberSetting.decimalCount, this._numberSetting.shortened);
				$.TextStudio.create(text, this.labelRef, "absolute", x, y + this.LABEL_OFFSET, null, null, "coordinate")
			}
			this._graphics.end();
		},
		_drawXMarks: function(){
			var mapping = mainGraph.xAxisMapping;
			var valueRange = mapping.getValueRange();
			var totalRange = valueRange.second - valueRange.first;
			var xValueSpace = 5;
			
			var adjust = this._strokeThickness % 2 == 1 ? 0.5 : 0, 
				currentValue = valueRange.first,
				coordinateRange = mainGraph.yAxisMapping.getCoordinateRange(), 
				x = Math.floor(mapping.getCoordinate(currentValue)) + adjust, 
				y = coordinateRange.first + this.LABEL_OFFSET + adjust, 
				lineBottom = this.getHeight()-20, 
				lineTop = this._showXLines ? coordinateRange.second : lineBottom, 
				baseLineTop = (!this._showXLines && !this._showYLines) ? coordinateRange.second : lineTop,
				length = Math.floor(totalRange/xValueSpace)-1;
			
			var text = "";
			var lines = [];
			lines.push([x, baseLineTop, x, lineBottom]);
			text = StrFormatter.getFormattedNumString(currentValue, totalRange, this._numberSetting.decimalCount, this._numberSetting.shortened);
			$.TextStudio.create(text, this.labelRef, "absolute", x, y, null, null, "coordinate")
			
			for (var i = 0; i < length; i++) {
				currentValue = currentValue + xValueSpace;
				x = Math.floor(mapping.getCoordinate(currentValue)) + adjust;
				lines.push([x, lineTop, x, lineBottom]);
				text = StrFormatter.getFormattedNumString(currentValue, totalRange, this._numberSetting.decimalCount, this._numberSetting.shortened);
				$.TextStudio.create(text, this.labelRef, "absolute", x+ this.LABEL_OFFSET, y, null, null, "coordinate")
			}
			
			this._graphics.begin();
			this._graphics.setLineStyle(this._strokeThickness, this._strokeColor);
			this._graphics.drawLines(lines);
			this._graphics.end();
		}
    });
	
    this.Presentation.GraphArea = function(){
        this.canvas = mainGraph._graphCanvas;
		this.canvasAsset = mainGraph._graphCanvas1;
        this.ctx = this.canvas.getContext("2d");
		this.ctxAsset = this.canvasAsset.getContext("2d");
        this._graphics = new $.Graphics(this.ctx);
		this._graphicsAsset = new $.Graphics(this.ctxAsset);
		this.selection = $(mainGraph._selection);
		
		this._strokeThickness = 4;
        this._strokeColor = "#AAAAAA";
		this._strokeColorRisk = "#2C7C81";
		
		this._assetRadius = 3;
		this._selectionRadius = 4.5;
		
		var me = this;
		
		var _createElement = function(){
			$.Canvas.resize(me.selection, 9, 9);
			var graphics = new $.Graphics($.Canvas.create(me.selection, "relative", 0, 0, 9, 9).getContext("2d"));
			graphics.begin();
			graphics.setLineStyle(0);
			graphics.setNormalFill("#FF0000");
			graphics.drawCircle({x: 4.5, y: 4.5}, 4.5);
			graphics.end();
			graphics = null;
			
			me.selection.hide();
		};
		
		_createElement();
    };
    this.Presentation.GraphArea.prototype = $.extend(new this.Presentation.GraphElement(), {
        applySetting: function(setting){
			
		},
		getRange: function(xrange, yrange){
			if (!mainGraph._datasource || !mainGraph._datasource.getValueRange) 
				return;
			
			var arr = mainGraph._datasource.getValueRange();
			if($.isArray(arr) && arr.length>=4){
				xrange.first = arr[0];
				xrange.second = arr[1];
				yrange.first = arr[2];
				yrange.second = arr[3];
			}
		},
		resizeComponents: function(width, height){
			$.Canvas.resize($(this.canvasAsset));
        },
        refresh: function(){
            var d = +new Date();
			this.reset();
            this._drawFrontier();
			this._drawAssetClasses();
			this._drawModel();
            ChartLogger.instance.write("[time-consuming] time consuming of drawing graph area: " + (new Date() - d));
        },
        reset: function(){
            this.ctx.clearRect(0, 0, this.getWidth(), this.getHeight());
			this.ctxAsset.clearRect(0, 0, this.getWidth(), this.getHeight());
			this.selection.hide();
			mainGraph._barInfo=[];
        },
		updateSelection: function(dev, ret, index){
			if (dev < 0) {
				this.selection.hide();
				return;
			}
			var x = mainGraph.xAxisMapping.getCoordinate(dev) - 4.5,
				y = mainGraph.yAxisMapping.getCoordinate(ret) - 4.5;
			
			this.selection.hide();
			this.selection.css({left:x,top:y});
			this.selection.show();
		},
        _drawFrontier: function(){
			if (!mainGraph._datasource || !mainGraph._datasource.getCurrentData) 
				return;
			var currentData = mainGraph._datasource.getCurrentData();
			if (!currentData || currentData.length <= 0) 
				return;

			//check for risk score frontier			
			var riskIndex = -1, riskStart = 0, riskEnd = 0;
			if (mainGraph._datasource.getRiskScore) {
				riskIndex = mainGraph._datasource.getRiskScore() - 1;
			}
			if (riskIndex >= 0) {
				if (mainGraph._datasource.getRiskRange){
					var range = mainGraph._datasource.getRiskRange();
					if (range && range.length > riskIndex + 1) {
						riskStart = range[riskIndex];
						riskEnd = range[riskIndex + 1];
					}
				}
			}
			var pts = [], riskPts = [], pt = null;
			for (var i = 0; i < currentData.length; i++) {
				pt = {
					x: mainGraph.xAxisMapping.getCoordinate(currentData[i].dev),
					y: mainGraph.yAxisMapping.getCoordinate(currentData[i].ret)
				};
				pts.push(pt);
				if (currentData[i].dev >= riskStart && currentData[i].dev <= riskEnd) {
					riskPts.push(pt);
				}
			}
			pt = null;
			
			this._graphics.begin();
			this._graphics.setLineStyle(this._strokeThickness, this._strokeColor);
			this._graphics.drawPolyline(pts);
			this._graphics.end();
			
			if (riskPts.length > 0) {
				this._graphics.begin();
				this._graphics.setLineStyle(this._strokeThickness, this._strokeColorRisk);
				this._graphics.drawPolyline(riskPts);
				this._graphics.end();
			}
			
		},
		_drawAssetClasses: function(){
			if (!mainGraph._datasource || !mainGraph._datasource.getAssetClasses) 
				return;
			var assetData = mainGraph._datasource.getAssetClasses();
			if (!assetData || assetData.length <= 0) 
				return;
			
			var pt = null;
			for (var i = 0; i < assetData.length; i++) {
				pt = {};
				pt.x = mainGraph.xAxisMapping.getCoordinate(assetData[i].dev);
				pt.y = mainGraph.yAxisMapping.getCoordinate(assetData[i].ret);
				
				this._graphicsAsset.begin();
				this._graphicsAsset.setLineStyle(0);
				this._graphicsAsset.setNormalFill(assetData[i].color.toString());
				this._graphicsAsset.drawCircle(pt, this._assetRadius);
				this._graphicsAsset.end();
			}
			pt = null;
		},
		_drawModel:function(){
			if (!mainGraph._datasource || !mainGraph._datasource.getModels) 
				return;
			var models = mainGraph._datasource.getModels();
			if (!models || models.length <= 0) 
				return;
			
			var data = null, pt = null;
			for (var i = 0; i < models.length; i++) {
				data = models[i];
				pt = {};
				pt.x = mainGraph.xAxisMapping.getCoordinate(data.portfolio.dev);
				pt.y = mainGraph.yAxisMapping.getCoordinate(data.portfolio.ret);
				switch (data.type.toLowerCase()) {
					case "current":
						this._graphics.begin();
						this._graphics.setLineStyle(0);
						this._graphics.setNormalFill("#FF0000");
						this._graphics.drawCircle(pt, 1.5);
						this._graphics.end();
						this._graphics.begin();
						this._graphics.setNoneFill();
						this._graphics.setLineStyle(1, "#FF0000");
						this._graphics.drawCircle(pt, 4.5);
						this._graphics.end();
						break;
					case "selected":
						mainGraph._presentation.updateSelection(data.portfolio.dev, data.portfolio.ret);
						break;
					case "target":
						this._graphics.begin();
						this._graphics.setLineStyle(0);
						this._graphics.setNormalFill("#669966");
						this._graphics.drawCircle(pt, 2.5);
						this._graphics.end();
						this._graphics.begin();
						this._graphics.setNoneFill();
						this._graphics.setLineStyle(1, "#669966");
						this._graphics.drawCircle(pt, 5.5);
						this._graphics.end();
						break;
					case "othertarget":
						this._graphics.begin();
						this._graphics.setLineStyle(0);
						this._graphics.setNormalFill("#AAAAAA");
						this._graphics.drawCircle(pt, 2.5);
						this._graphics.end();
						this._graphics.begin();
						this._graphics.setNoneFill();
						this._graphics.setLineStyle(1, "#AAAAAA");
						this._graphics.drawDotCircle(pt, 5.5, 1);
						this._graphics.end();
						break;
					case "proposed":
						this._graphics.begin();
						this._graphics.setLineStyle(0);
						this._graphics.setNormalFill("#6699CC");
						this._graphics.drawCircle(pt, 4.5);
						this._graphics.end();
						break;
					case "model":
						this._graphics.begin();
						this._graphics.setLineStyle(0);
						this._graphics.setNormalFill("#6699CC");
						this._graphics.drawRectangle(pt.x - 3.5, pt.y - 3.5, 7, 7);
						this._graphics.end();
						break;
					case "middle":
						this._graphics.begin();
						this._graphics.setLineStyle(1, "#008000");
						this._graphics.setNoneFill();
						this._graphics.drawLine(pt.x - 5, pt.y, pt.x + 5, pt.y);
						this._graphics.drawLine(pt.x, pt.y - 5, pt.x, pt.y + 5);
						this._graphics.end();
						break;
				}
			}
			data = null;
			pt = null;
		}
    });
	
	this.Presentation.Slider = function(){
		this.canvas = mainGraph._sliderCanvas;
		this.canvasRef = $(this.canvas);
		this.ctx = null;
		this._graphics = null;
		this.lineLayerRef = null;
		this.sliderPrevRef = null;
		this.sliderNextRef = null;
		this.sliderCursorRef = null;
		
		this.mapping = new Chart.Common.Coordinate.Double2DoubleLinearMapping();
		
		this._strokeThickness = 1;
		this._strokeColor = "#808080";
		this._fillColor = "#FFFFFF";
		
		this._buttonRadius = 9;
		this._cursorRadius = 7;
		
		this._selectedIndex = -1;
		
		this.TIMER_INTERVAL = 50;
		var _isDragging = false;
		var _needUpdateSelection = false;
		var _timer = null;
		var _savedhandlers = {};
		
		var me = this;
		
		this._addEventHandler = function(){
			this.canvasRef.mousemove(_onDrawing);
			this.sliderCursorRef.mousedown(_onBeginDrag);
			this.sliderPrevRef.mousedown(_onPrevClick);
			this.sliderNextRef.mousedown(_onNextClick);
			ChartLogger.instance.write("[E-F][slider] add event handler to slider");
		};
		this._unBindEventHandler = function(){
			this.canvasRef.unbind("mousemove", _onDrawing);
			this.sliderCursorRef.unbind("mousedown", _onBeginDrag);
			this.sliderPrevRef.unbind("mousedown", _onPrevClick);
			this.sliderNextRef.unbind("mousedown", _onNextClick);
			ChartLogger.instance.write("[E-F][slider] remove event handler from slider");
		};
		var _onPrevClick = function(e){
			if (me._selectedIndex < 0) {
				ChartLogger.instance.write("[E-F][slider] preview button clicked, index < 0");
				return;
			}
			
			var currentData = mainGraph._datasource.getCurrentData();
			if (me._selectedIndex == 0) {
			//do nothing
			}
			else 
				if (currentData.length >= me._selectedIndex) {
					me._selectedIndex--;
				}
				else {
					me._selectedIndex = currentData.length - 1;
				}
			
			var datum = currentData[me._selectedIndex];
			mainGraph._presentation.updateSelection(datum.dev, datum.ret, me._selectedIndex);
			
			ChartLogger.instance.write("[E-F][slider] preview button clicked, current index is: " + me._selectedIndex);
		};
		var _onNextClick = function(e){
			if (me._selectedIndex < 0) {
				ChartLogger.instance.write("[E-F][slider] next button clicked, index < 0");
				return;
			}
			
			var currentData = mainGraph._datasource.getCurrentData();
			if (currentData.length > me._selectedIndex + 1) {
				me._selectedIndex++;
				var datum = currentData[me._selectedIndex];
				mainGraph._presentation.updateSelection(datum.dev, datum.ret, me._selectedIndex);
			}
			
			ChartLogger.instance.write("[E-F][slider] next button clicked, current index is: " + me._selectedIndex);
		};
		var _onBeginDrag = function(e){
			ChartLogger.instance.write("[E-F][slider] ++++++ start draging.");
			_isDragging = true;
			
			// cancel out any text selections
			document.body.focus();
			
			// prevent text selection and drag in old-school browsers
			if (document.onselectstart !== undefined && _savedhandlers.onselectstart == null) {
				_savedhandlers.onselectstart = document.onselectstart;
				document.onselectstart = function(){
					return false;
				};
			}
			if (document.ondrag !== undefined && _savedhandlers.ondrag == null) {
				_savedhandlers.ondrag = document.ondrag;
				document.ondrag = function(){
					return false;
				};
			}
			
			_updateSelectionBegin();
			_timer = setInterval(_executeUpdateSelection, me.TIMER_INTERVAL);
		};
		var _onEndDrag = function(e){
			if (!_isDragging) {
				return;
			}
			
			ChartLogger.instance.write("[E-F][slider] ------ stop draging.");
			_isDragging = false;
			// revert drag stuff for old-school browsers
			if (document.onselectstart !== undefined) 
				document.onselectstart = _savedhandlers.onselectstart;
			if (document.ondrag !== undefined) 
				document.ondrag = _savedhandlers.ondrag;
			
			clearInterval(_timer);
			_executeUpdateSelection();
			_updateSelectionEnd();
		};
		var _onDrawing = function(e){
			if (!_isDragging) {
				return;
			}
			var newPosX = Math.floor($.getPosition(me.canvas, e).x) - me._cursorRadius,
				coordinateRange = me.mapping.getCoordinateRange();
			
			if (newPosX > coordinateRange.second) {
				newPosX = coordinateRange.second;
			}
			if (newPosX < coordinateRange.first) {
				newPosX = coordinateRange.first;
			}
			
			me.sliderCursorRef.css({
				left: newPosX
			});
			
			//The timer will ask the presentation manager to refresh periodically. by Call ExecuteUpdateSelection
			_needUpdateSelection = true;
		};
		var _updateSelectionBegin = function(){
			$(document).one("mouseup", _onEndDrag);
		};
		var _updateSelectionEnd = function(){
		};
		var _executeUpdateSelection = function(){
			if (_needUpdateSelection) {
				_needUpdateSelection = false;
				
				var targetDev = me.mapping.getValue(me.sliderCursorRef.position().left);
				
				if (!mainGraph._datasource || !mainGraph._datasource.getCurrentIndex) 
					return;
				var index = mainGraph._datasource.getCurrentIndex(targetDev);
				if (index < 0) 
					return;
					
				me._selectedIndex = index;
				var datum = mainGraph._datasource.getCurrentData()[index];
				mainGraph._presentation.updateSelection(datum.dev, datum.ret, index);
				
				ChartLogger.instance.write("[E-F][slider] ...... on draging, change selection to "+datum.dev);
			}
		};
		var _createElement = function(){
			var graphSize = {
				width: me.getWidth(),
				height: me.getHeight()
			};
			me.lineLayerRef = $($.Canvas.create(me.canvasRef, "relative", 0, 0, graphSize.width, graphSize.height));
			me.sliderPrevRef = $($.Canvas.createDiv(me.canvasRef, "absolute", graphSize.width - 45, 0, 18, 18));
			me.sliderNextRef = $($.Canvas.createDiv(me.canvasRef, "absolute", graphSize.width - 20, 0, 18, 18));
			me.sliderCursorRef = $($.Canvas.createDiv(me.canvasRef, "absolute", 0, 2, 14, 14));
			me.ctx = me.lineLayerRef.get(0).getContext("2d");
			me._graphics = new $.Graphics(me.ctx);
			
			//pre
			var graphics = new $.Graphics($.Canvas.create(me.sliderPrevRef, "relative", 0, 0, 18, 18).getContext("2d"));
			graphics.begin();
			graphics.setLineStyle(1, me._strokeColor);
			graphics.setNormalFill(me._fillColor);
			graphics.drawCircle({x: 9,y: 9}, 8.5);
			graphics.end();
			graphics.begin();
			graphics.setLineStyle(2, me._strokeColor);
			graphics.drawLine(4, 9, 14, 9);
			graphics.end();
			graphics = null;
			
			//next
			graphics = new $.Graphics($.Canvas.create(me.sliderNextRef, "relative", 0, 0, 18, 18).getContext("2d"));
			graphics.begin();
			graphics.setLineStyle(1, me._strokeColor);
			graphics.setNormalFill(me._fillColor);
			graphics.drawCircle({x: 9,y: 9}, 8.5);
			graphics.end();
			graphics.begin();
			graphics.setLineStyle(2, me._strokeColor);
			graphics.drawLine(4, 9, 14, 9);
			graphics.drawLine(9, 4, 9, 14);
			graphics.end();
			graphics = null;
			
			//cursor
			graphics = new $.Graphics($.Canvas.create(me.sliderCursorRef, "relative", 0, 0, 14, 14).getContext("2d"));
			graphics.begin();
			graphics.setLineStyle(1, me._strokeColor);
			graphics.setNormalFill(me._fillColor);
			graphics.drawCircle({x: 7,y: 7}, 6.5);
			graphics.end();
			graphics.begin();
			graphics.setLineStyle(1, me._strokeColor);
			graphics.drawLine(6.5, 0, 6.5, 7);
			graphics.end();
			graphics = null;
			
		};
		
		_createElement();
		//_addEventHandler();
	};
	this.Presentation.Slider.prototype = $.extend(new this.Presentation.GraphElement(), {
        getSelectedIndex: function(){
			return this._selectedIndex;
		},
		applySetting: function(setting){
			
		},
		resizeComponents: function(width, height){
			$.Canvas.resize($(this.lineLayer), width, height);
        },
        refresh: function(){
            var d = +new Date();
			this.reset();
			this._drawSlider();
            ChartLogger.instance.write("[time-consuming] time consuming of drawing slider: " + (new Date() - d));
        },
        reset: function(){
            this.ctx.clearRect(0, 0, this.getWidth(), this.getHeight());
			this._selectedIndex = 0;
			this._unBindEventHandler();
        },
		updateSelection: function(dev, ret, index){
			if(dev < 0){
				return;
			}
			
			var x = this.mapping.getCoordinate(dev);
			this.sliderCursorRef.css({left:x});
			
			if (index && index >= 0) {
				this._selectedIndex = index;
			}
			else {
				if (!mainGraph._datasource || !mainGraph._datasource.getCurrentIndex) 
					return;
				index = mainGraph._datasource.getCurrentIndex(dev);
				if (index < 0) 
					return;
				
				this._selectedIndex = index;
			}
		},
		_drawSlider: function(){
			if (!mainGraph._datasource || !mainGraph._datasource.getCurrentData) 
				return;
			var currentData = mainGraph._datasource.getCurrentData();
			if (!currentData || currentData.length <= 0) 
				return;

			var valueRange = {
				first: currentData[0].dev,
				second: currentData[currentData.length - 1].dev
			};

			var x1 = Math.floor(mainGraph.xAxisMapping.getCoordinate(valueRange.first))+0.5,
				x2 = Math.floor(mainGraph.xAxisMapping.getCoordinate(valueRange.second))+0.5;
			
			this.mapping.setCoordinateRange({first:x1,second:x2-this._cursorRadius*2});
			this.mapping.setValueRange(valueRange);
			
			this._graphics.begin();
			this._graphics.setLineStyle(this._strokeThickness, this._strokeColor);
			this._graphics.drawLine(x1,9.5,x2,9.5);
			this._graphics.drawLine(x1,4,x1,14);
			this._graphics.drawLine(x2,4,x2,14);
			this._graphics.end();
			
			this._addEventHandler();
		}
    });
    
    this.Presentation.MessagePanel = function(){
        this.canvas = mainGraph._messageCanvas;
    };
    this.Presentation.MessagePanel.prototype = $.extend(new this.Presentation.GraphElement(), {});
    
    this.Presentation.TooltipLayer = function(){
		this.canvas = mainGraph._tooltipCanvas;
		this.canvasRef = $(this.canvas);
		this.highlightLayer = null;
		this.ctx = null;
        this._graphics = null;
		
		this._currentDatum = null;
		
		var me = this;
		
		var _addEventHandler = function(){
			//if (true) {
				//target.mousemove(_onMouseMove);
				//target.mouseout(_onMouseLeave);
			//}
			mainGraph._contextCanvas.mousedown(_onMouseDown);
		};
		var _onMouseDown = function(e){
			var pt = $.getPosition(me.canvas, e);
			var targetDev = mainGraph.xAxisMapping.getValue(pt.x);
			
			if (!mainGraph._datasource || !mainGraph._datasource.getCurrentIndex) 
				return;
			var index = mainGraph._datasource.getCurrentIndex(targetDev);
			if (index < 0) 
				return;
			
			var datum = mainGraph._datasource.getCurrentData()[index];
			mainGraph._presentation.updateSelection(datum.dev, datum.ret, index);
			
			ChartLogger.instance.write("[E-F][interactive] mouse down, change selection to " + datum.dev);
		};
		var _onMouseLeave = function(e){
			me._hideTip(e);
		};
		var _onMouseMove = function(e){
			var pt = $.getPosition(me.canvas, e);
			
			var datum = _findDatum(pt);
			if (datum) {
				me._currentDatum = datum; 
					me._showTip(mainGraph._datasource.getFloatingTipContext(datum.id, datum.type,datum.index), e);
					return;
			}
			
			if (me._currentDatum) {
				me._hideTip(e);
				me._currentDatum = null;
			}
		};
		var _findDatum = function(pt){
			try {
				for(var i= mainGraph._barInfo.length-1;i>=0;i--){
					if (Chart.Common.Graphic.GraphicUtil.inPolygon(mainGraph._barInfo[i].points, mainGraph._barInfo[i].points.length, pt)) {
						return mainGraph._barInfo[i];
					}
				}
			} 
			catch (ex) {
			}
			
			return null;
		};
		var _createElement = function(){
			var graphSize = {
				width: me.getWidth(),
				height: me.getHeight()
			};
			//me.highlightLayer = $.Canvas.create($(me.canvas), "absolute", 0, 0, graphSize.width, graphSize.height);
			//me.ctx = me.highlightLayer.getContext("2d");
			//me._graphics = new $.Graphics(me.ctx);
			
			mainGraph._tooltipFactory.setActiveRegion({
				x: 0,
				y: 0,
				width: graphSize.width,
				height: graphSize.height
			});
		};
		
		_createElement();
		_addEventHandler();
	};
    this.Presentation.TooltipLayer.prototype = $.extend(new this.Presentation.GraphElement(), {
		resizeComponents: function(width, height){
            //this.highlightLayer.width = width;
            //this.highlightLayer.height = height;
            //$(this.highlightLayer).css({
            //    width: width,
            //    height: height
            //});
			mainGraph._tooltipFactory.setActiveRegion({
				x: 0,
				y: 0,
				width: width,
				height: height
			});
        },
		reset: function(){
			this._hideTip(null);
		},
		_showTip: function(context, e){
			if (!mainGraph._tooltip) {
				mainGraph._tooltip = mainGraph._tooltipFactory.create();
			}
			if(context && context.length>0){
			    mainGraph._tooltip.setContent(context);
			    mainGraph._tooltip.popupAt($.getPosition(target.get(0), e));
			}
		},
		_hideTip: function(e){
			if (mainGraph._tooltip) {
				mainGraph._tooltip.hide();
			}
		}
	});
    
    this.Presentation.PresentationManager = function(){
        this._graphArea = null;
		this._coordinateArea = null;
        this._messagePanel = null;
        this._tooltipLayer = null;
		this._slider = null;
        this.canvas = mainGraph._placeHolder.get(0);
        
        var me = this;
        
        var createElement = function(){
			var totalSize = {
				width: mainGraph._placeHolder.width() - mainGraph._margin.left - mainGraph._margin.right,
				height: mainGraph._placeHolder.height() - mainGraph._margin.top - mainGraph._margin.bottom
			};
			var graphHeight = totalSize.height - mainGraph.SLIDER_HEIGHT;
			var context = $($.Canvas.createDiv(mainGraph._placeHolder, "absolute", mainGraph._margin.left, mainGraph._margin.top, totalSize.width, graphHeight));
			mainGraph._contextCanvas = context;
			mainGraph._sliderCanvas = $.Canvas.createDiv(mainGraph._placeHolder, "absolute", mainGraph._margin.left, mainGraph._margin.top + graphHeight, totalSize.width, mainGraph.SLIDER_HEIGHT);
			mainGraph._coordinateCanvas = $.Canvas.createDiv(context, "absolute", 0, 0, totalSize.width, graphHeight);
			mainGraph._graphCanvas = $.Canvas.create(context, "absolute", 0, 0, totalSize.width, graphHeight);
			mainGraph._graphCanvas1 = $.Canvas.create(context, "absolute", 0, 0, totalSize.width, graphHeight);
			mainGraph._tooltipCanvas = $.Canvas.createDiv(context, "absolute", 0, 0, totalSize.width, graphHeight);
			//mainGraph._messageCanvas = $.Canvas.create(mainGraph._placeHolder, "absolute", 0, 0, canvasWidth, canvasHeight);
			mainGraph._selection = $.Canvas.createDiv(context, "absolute", 0, 0, 0, 0);
		};
        
        createElement();
    };
    this.Presentation.PresentationManager.prototype = $.extend(new Chart.Common.Command.CommandHandler(), new this.Presentation.GraphElement(), {
        initailizeCoordinateMapping: function(){
			var xrange = {
				first: 0,
				second: 0
			};
			var yrange = {
				first: 0,
				second: 0
			};
			var xcoordinate = {
				first: 0,
				second: this._graphArea.getWidth() - 1
			};
			var ycoordinate = {
				first: this._graphArea.getHeight() - mainGraph.FOOTER_HEIGHT - 1,
				second: mainGraph.HEADER_HEIGHT
			};
			
			this._graphArea.getRange(xrange, yrange);
			this._coordinateArea.getRange(xrange, yrange);
			
			mainGraph.xAxisMapping.setCoordinateRange(xcoordinate);
			mainGraph.xAxisMapping.setValueRange(xrange);
			mainGraph.yAxisMapping.setCoordinateRange(ycoordinate);
			mainGraph.yAxisMapping.setValueRange(yrange);
		},
		applySetting: function(setting){
			var bgSetting = {};
			if (Chart.Setting.Presentation.BG.tryDeSerialize(setting, Chart.Setting.SettingItem.Chart, bgSetting)) {
				mainGraph._placeHolder.css({
					"background-color": bgSetting.color
				});
			}
			if (setting && setting.chart && setting.chart.option){
				//left right margin
				if (setting.chart.option.leftmargin != null && parseFloat(setting.chart.option.leftmargin) != NaN) {
					this._leftMargin = parseFloat(setting.chart.option.leftmargin);
				}
				if (setting.chart.option.rightmargin != null && parseFloat(setting.chart.option.rightmargin) != NaN) {
					this._rightMargin = parseFloat(setting.chart.option.rightmargin);
				}
			}
			this._coordinateArea.applySetting(setting);
			this._graphArea.applySetting(setting);
			this._tooltipLayer.applySetting(setting);
			this._slider.applySetting(setting);
		},
        refresh: function(){
            var me = this;
            setTimeout(function(){
                me.initailizeCoordinateMapping();
				me._coordinateArea.refresh();
				me._slider.refresh();
                me._graphArea.refresh();
                //me._tooltipLayer.refresh();
            }, 10);
        },
		updateSelection: function(dev, ret, index){
			var me = this;
			setTimeout(function(){
				me._coordinateArea.updateSelection(dev, ret, index);
				me._graphArea.updateSelection(dev, ret, index);
				me._tooltipLayer.updateSelection(dev, ret, index);
				me._slider.updateSelection(dev, ret, index);
				
				if (mainGraph.options && mainGraph.options.showSelectedPortfolio) {
					mainGraph.options.showSelectedPortfolio(me, {
						dev: dev,
						ret: ret
					});
				}
			}, 10);
		},
        clearAll: function(){
            this._coordinateArea.reset();
            this._graphArea.reset();
            this._tooltipLayer.reset();
			this._slider.reset();
            //this._messagePanel.onClearAll();
        },
        resizeComponents: function(width, height){
			var graphSize = {
				width: width - mainGraph._margin.left - mainGraph._margin.right,
				height: height - mainGraph._margin.top - mainGraph._margin.bottom
			};
			this._coordinateArea.resize(graphSize.width, graphSize.height);
			this._graphArea.resize(graphSize.width, graphSize.height);
			this._tooltipLayer.resize(graphSize.width, graphSize.height);
			//this._slider.resize()
		},
        getHandler: function(args){
            switch (args.command) {
				case Chart.Common.Command.Commands.APPLY_CHART_SETTING:
					return this._onApplyChartSetting;
                case Chart.Common.Command.Commands.REFRESH_PRESENTATION:
                    return this._onRefreshPresentation;
                case Chart.Common.Command.Commands.RESIZE:
                    return this._onResize;
                case Chart.Common.Command.Commands.INITIALIZE:
                    return this._onInitialize;
                case Chart.Common.Command.Commands.COMPONENT_STATUS_UPDATE:
                    return this._onComponentStatusUpdate;
				case Chart.Common.Command.Commands.SET_CULTURE:
					return this._onSetCulture;
                default:
                    return null;
            }
        },
		getSelectedIndex: function(){
			return this._slider.getSelectedIndex();
		},
		_onApplyChartSetting: function(args){
			if (args && args.data && args.data.setting) {
				this.applySetting(args.data.setting);
				//this.refresh();
			}
		},
        _onInitialize: function(args){
			this._coordinateArea = new mainGraph.Presentation.CoordinateArea();
            this._graphArea = new mainGraph.Presentation.GraphArea();
			this._slider = new mainGraph.Presentation.Slider();
            //this._messagePanel = new mainGraph.Presentation.MessagePanel();
            this._tooltipLayer = new mainGraph.Presentation.TooltipLayer();
        },
        _onRefreshPresentation: function(args){
            this.refresh();
        },
        _onResize: function(args){
            if (args && args.data && args.data.width && args.data.height) {
                this.resize(args.data.width, args.data.height);
            }
            this.refresh();
        },
        _onComponentStatusUpdate: function(args){
            if (args && args.data && args.data.status) {
                switch (args.data.status) {
                    case Chart.Common.Command.ComponentStatus.ClearAll:
                        this.clearAll();
                        break;
                    default:
                        break;
                }
            }
        },
		_onSetCulture: function(args){
			if (args) {
				this.refresh();
			}
		}
    });
    
    var initializeEx = function(){
        mainGraph._presentation = new mainGraph.Presentation.PresentationManager();
    };
    
    initializeEx();
};
Chart.Component.EFGraph.prototype = $.extend(new Chart.Common.Command.CommandHandler(), {
    defaultHandler: function(args){
        //do nothing here.
    },
    getHandler: function(args){
        return this.defaultHandler;
    },
    collectionChildren: function(){
        this.interactiveChildren = [this._presentation];
		this._presentation.parentContainer = this;
    },
    setDataSource: function(datasource){
        this._datasource = datasource;
    },
	setAssetVisibility: function(show){
		if (show) {
			$(this._graphCanvas1).show();
		}
		else {
			$(this._graphCanvas1).hide();
		}
	},
	getSelectedIndex: function(){
		return this._presentation.getSelectedIndex();
	},
    resize: function(width, height){
        //this._presentation.resize(width, height);
        //this._presentation.refresh();
    }
});

