Chart.Growth = function(containerDOM){
	this.objId = CHARTID.Growth;
	this.cId = +new Date();	
	this.container = containerDOM;
	
	this.dataSource = null;
	this.graph = null;
	this.slider = null;
	this.legend = null;
	
	this.graphCanvas = null;
	this.sliderCanvas = null;
	this.legendCanvas = null;
	this.floatCanvas = null;
	
	this.canvasWidth = 0;
	this.canvasHeight = 0;
	
	if (containerDOM) 
		this._initialize();
	return this;
};
Chart.Growth.prototype = $.extend(new Chart.Common.Graphic.GraphElement(), {
	/*
	 * override
	 */
	resizeComponents: function(width, height){
		this.canvasWidth = width;
		this.canvasHeight = height;
		
		this.graphCanvas.css({
			width: width,
			height: height - 194
		});
		this.sliderCanvas.css({
			width: width,
			height: 40
		});
		this.legendCanvas.css({
			width: width,
			height: 150
		});
		
		this.graph.resize(width, height - 194);
		this.slider.resize(width, 40);
		this.legend.resize(width, 150);
	},
	/*
	 * override
	 */
	refresh: function(){
		var me = this;
		this.dataSource.refresh(function(){
			me.dataSource.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.REFRESH_PRESENTATION, null));
		});
	},
	setCulture: function(cultureName){
		var me = this;
		LocalizationManager.instance.setCurrentCulture(cultureName, function(){
			me.dataSource.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.SET_CULTURE, null));
		});
	},
	_initialize: function(){
		this.canvas = this.container.get(0);
		this.canvasWidth = this.container.width();
		this.canvasHeight = this.container.height();
		
		this._createElements();
		this._createComponents();
	},
	_createComponents: function(){
		this.dataSource = new Chart.Component.GrowthData();
		this.graph = new Chart.Component.TimeSeriesGraph(this.graphCanvas);
		this.graph.setDataSource(this.dataSource);
		this.graph.collectionChildren();
		
		this.slider = new Chart.Component.DateSlider(this.sliderCanvas);
		this.slider.setDataSource(this.dataSource);
		this.slider.collectionChildren();
		
		this.legend = new Chart.Component.Legend(this.legendCanvas);
		this.legend.setDataSource(this.dataSource);
		this.legend.collectionChildren();
		
		this.dataSource.addChild(this.graph);
		this.dataSource.addChild(this.slider);
		this.dataSource.addChild(this.legend);
		this.dataSource.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.INITIALIZE, null));
	},
	_createElements: function(){
		this.container.attr({
			"cid": this.cId
		});
		this.container.addClass("growth");
		this.graphCanvas = $($.Canvas.createDiv(this.container, "relative", 0, 0, this.canvasWidth, this.canvasHeight - 194)).attr({
			"cid": this.cId
		});
		this.sliderCanvas = $($.Canvas.createDiv(this.container, "relative", 0, 2, this.canvasWidth, 40)).attr({
			"cid": this.cId
		});
		this.legendCanvas = $($.Canvas.createDiv(this.container, "relative", 0, 4, this.canvasWidth, 150)).attr({
			"cid": this.cId
		});
		/*
		this.floatCanvas = $($.Canvas.createDiv(this.container, "absolute", 0, 0, 0, 0)).attr({
			"id": "phTip" + this.cId,
			"cid": this.cId
		});
		*/
		this.floatCanvas = $("<div></div>").appendTo(this.container).attr({
			"id": "phTip" + this.cId,
			"cid": this.cId
		});
	}
});

Chart.Component.GrowthData = function() {
    var today = new Date();
    today = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    this._rawData = new Dictionary();
    this._currentData = [];
    this._dataSetting = [];
    this._baseInformation = [];
    this._timeRange = {
        second: today,
        first: today.dateAdd("a", -5)
    };
    this._currentSelection = {
        second: today.clone(),
        first: this._timeRange.first.clone().dateAdd("a", 3)
    };

    var me = this;

    this.getCurrentData = function(){
		var d = new Date();
		var startIndex = Chart.Common.Util.DateUtil.getDateIndex(me._currentSelection.first);
		var endIndex = Chart.Common.Util.DateUtil.getDateIndex(me._currentSelection.second);
		this._currentData = [];
		for (var i = 0; i < this._rawData.count; i++) {
			this._currentData.push({
				key: this._rawData.keys()[i],
				value: calculateGrowth(Chart.Common.Data.TimeSeries.TSDataSlicer.getSingleCurrentData(this._rawData.values()[i], 200, startIndex, endIndex, true), 10000)
			});
		}
		ChartLogger.instance.write("[time-consuming] time consuming of get current data: "+(new Date() - d));
	};

    this.TSDataGenerator = function() {

    };
    this.TSDataGenerator.prototype.createTSData = function(investment) {
        var firstIndex = 0;
        var toIndex = 0;

        toIndex = Chart.Common.Util.DateUtil.getDateIndex(me._timeRange.second);
        firstIndex = Chart.Common.Util.DateUtil.getDateIndex(me._timeRange.first);

        var tsData = [];

        var currentValue = 10000;
        while (firstIndex < toIndex) {
            tsData.push(new Chart.Common.Data.TimeSeriesDatum(firstIndex, currentValue));

            currentValue = currentValue * (1 + (Math.random() - 0.5) * 0.1);
            currentValue = currentValue < 0 ? 0 : currentValue;

            firstIndex += 1;
        }

        var dataRecord = new Chart.Common.Data.TimeSeries.TimeSeriesDataRecord({ investmentId: investment });
        dataRecord.tsData = new Chart.Common.Data.ListWrapper(tsData);
        dataRecord.parseBorderValue();

        return dataRecord;
    };

    function calculateGrowth(tsDataRecord, initialValue){
		if (!tsDataRecord || !tsDataRecord.tsData || tsDataRecord.tsData.data.length < 0) {
			return null;
		}
		var newList = new Chart.Common.Data.ListWrapper([]);
		var firstValue = tsDataRecord.tsData.data[0].value;
		var tempValue = initialValue / firstValue;
		var length = tsDataRecord.tsData.data.length;
		$(tsDataRecord.tsData.data).each(function() {
		    newList.data.push(new Chart.Common.Data.TimeSeriesDatum(this.dateIndex, this.value * tempValue));
		});
		//var datum = null;
		//for (var i = 0; i < length; i++) {
		//	datum = tsDataRecord.tsData.data[i];
		//	newList.data.push(new Chart.Common.Data.TimeSeriesDatum(datum.dateIndex, datum.value * tempValue));
		//}
		tsDataRecord.tsData = newList;
		tsDataRecord.parseBorderValue();
		return tsDataRecord;
	}

    this._dataSetting.push({ key: "Item1", value: { shape: Chart.Common.Graphic.ShapeType.LineMedium, color: "#0A1E60"} });
    this._dataSetting.push({ key: "Item2", value: { shape: Chart.Common.Graphic.ShapeType.LineSmall, color: "#A6BC09"} });
    this._dataSetting.push({ key: "Item3", value: { shape: Chart.Common.Graphic.ShapeType.LineSmall, color: "#FEA620"} });
    this._dataSetting.push({ key: "Item4", value: { shape: Chart.Common.Graphic.ShapeType.LineSmall, color: "#FF1300"} });
    this._dataSetting.push({ key: "Item5", value: { shape: Chart.Common.Graphic.ShapeType.LineSmall, color: "#738FB6"} });
    this._dataSetting.push({ key: "Item6", value: { shape: Chart.Common.Graphic.ShapeType.LineSmall, color: "#006065"} });

    this._baseInformation.push({ key: "Item1", value: { name: "Invesment Item1 "} });
    this._baseInformation.push({ key: "Item2", value: { name: "Invesment Item2 has a long name "} });
    this._baseInformation.push({ key: "Item3", value: { name: "Invesment Item3 has a very long long long long name"} });
    this._baseInformation.push({ key: "Item4", value: { name: "Invesment Item4 also has a very long long long name "} });
    this._baseInformation.push({ key: "Item5", value: { name: "Invesment Item5 "} });
    this._baseInformation.push({ key: "Item6", value: { name: "Invesment Item6 "} });
};
Chart.Component.GrowthData.prototype = $.extend(new Chart.Common.Command.CommandHandler(),{
	/*
     * get graph data.
     * @param null .
     * @return [{key:itemKey, value:TimeSeriesDataRecord},...,{}].
     */
	getLineData: function(){
		return this._currentData;
	},
	getInvestmentName: function(investmentId){
		for (var i = 0; i < this._baseInformation.length; i++) {
			if (this._baseInformation[i].key == investmentId) {
				return this._baseInformation[i].value.name;
			}
		}
		return investmentId;
	},
	getInvestmentSetting: function(investmentId){
		var ret = null;
		for (var i = 0; i < this._dataSetting.length; i++) {
			if (this._dataSetting[i].key == investmentId) {
				ret = this._dataSetting[i].value;
				break;
			}
		}
		return ret;
	},
	isSubjectInvestment: function(investmentId){
		if (investmentId == "Item1") {
			return true;
		}
		return false;
	},
	getFloatingTipContent: function(datumIndex){
		if (datumIndex == null) {
			return null;
		}
		
		var firstDatum = null;
		var currentDatum = null;
		
		var record;
		for (var i = 0; i < this._currentData.length; i++) {
			record = this._currentData[i].value;
			if (record.dataKey == null || record.dataKey != datumIndex.key) {
				continue;
			}
			if (record.tsData == null ||
			record.tsData.data == null ||
			record.tsData.data.length <= 0) {
				break;
			}
			firstDatum = record.tsData.data[0];
			
			var nodeList = record.tsData.data;
			var pointCount = nodeList.length;
			if (pointCount < 1) {
				break;
			}
			var begin = 0;
			var end = pointCount - 1;
			if (nodeList[begin].dateIndex <= datumIndex.dateIndex &&
			nodeList[end].dateIndex >= datumIndex.dateIndex) {
				while (end - begin >= 2) {
					var mid = begin + Math.floor((end - begin) / 2);
					if (nodeList[mid].dateIndex < datumIndex.dateIndex) {
						begin = mid;
					}
					else {
						end = mid;
					}
				}
				// found in horizental
				if (nodeList[begin].dateIndex == datumIndex.dateIndex) {
					currentDatum = nodeList[begin];
				}
				else {
					currentDatum = nodeList[end];
				}
			}
			break;
		}
		
		if (firstDatum == null || currentDatum == null) {
			return null;
		}
		
		var format = "";
		if (this._tooltipDateFormat) {
			format = this._tooltipDateFormat.format;
		}
		else {
			format = LocalizationManager.instance.getDateFormat(Chart.Common.Util.DataFrequency.Daily, Globalization.DateFormatType.Normal);
		}
		
		var content = [];
		content.push(LocalizationManager.instance.getLabel("date1", "Date: ") + LocalizationManager.instance.formatDate(currentDatum.dateValue(), format));
		content.push(LocalizationManager.instance.getLabel("value", "Value: ") + LocalizationManager.instance.formatDecimal(currentDatum.value, 2));
		return content;
	},
	getYAxisCoordinateMappingType: function(){
		return Chart.Common.Coordinate.CartesianMappingType.Linear;
	},
	
	/*
	 * interface for date slider
	 */
	getTimeRange: function(){
		return this._timeRange;
	},
	/*
	 * interface for date slider
	 */
	getCurrentSelection: function(){
		return this._currentSelection;
	},
	_onSetCulture: function(args){
		if (args) {
			this.refresh();
		}
	},
	refresh: function(callback){
		var me = this;
		var generator = new this.TSDataGenerator();
		setTimeout(function(){
			me.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.ADD_INVESTMENT, {
				investmentId: "Item1",
				index: 0
			}));
			me.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.ADD_INVESTMENT, {
				investmentId: "Item2",
				index: 1
			}));
			me.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.ADD_INVESTMENT, {
				investmentId: "Item3",
				index: 2
			}));
			me.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.ADD_INVESTMENT, {
				investmentId: "Item4",
				index: 3
			}));
			//        me.executeCommand(new Chart.Common.Command.CommandArgs(
			//                    null,
			//                    Chart.Common.Command.Commands.ADD_INVESTMENT,
			//                    { investmentId: "Item5", index: 4 }));
			
			var d = +new Date();
			me._rawData.clear();
			me._rawData.add("Item1", generator.createTSData("Item1"));
			me._rawData.add("Item2", generator.createTSData("Item2"));
			me._rawData.add("Item3", generator.createTSData("Item3"));
			me._rawData.add("Item4", generator.createTSData("Item4"));
			ChartLogger.instance.write("[time-consuming] time consuming of generate data: " + (+new Date() - d));
			//        me._rawData.add("Item5", generator.createTSData("Item5"));
			//        me._rawData.add("Item6", generator.createTSData("Item6"));
			me.getCurrentData();
			if (callback) 
				callback();
		}, 100);
	},
	
	/*
     * override. filter commands.
     * @param arg {Chart.Common.Command.CommandArgs} content.
     * @return the handler event of target command.
     */
	getHandler: function(args){
		switch (args.command) {
			case Chart.Common.Command.Commands.UPDATE_SELECTION:
				return this.onUpdateSelection;
			case Chart.Common.Command.Commands.DELETE_INVESTMENT:
				return this.onDeleteInvestment;
	        case Chart.Common.Command.Commands.SET_CULTURE:
	            return this._onSetCulture;
			case Chart.Common.Command.Commands.ADD_INVESTMENT:
			case Chart.Common.Command.Commands.DELETE_ITEM:
			case Chart.Common.Command.Commands.REFRESH_PRESENTATION:
			case Chart.Common.Command.Commands.RESIZE:
			case Chart.Common.Command.Commands.INITIALIZE:
			case Chart.Common.Command.Commands.COMPONENT_STATUS_UPDATE:
			case Chart.Common.Command.Commands.UPDATE_TIME_RANGE:
			default:
				return this.defaultHandler;
		}
		return this.defaultHandler;
	},
	/*
     * default command handler, the purpose of this is the enable all commmand will be passed to children.
     * @param arg {Chart.Common.Command.CommandArgs} content.
     * @return null.
     */
	defaultHandler: function(args){
		//do nothing here.
	},
	/*
     * event handler for command UPDATE_SELECTION.
     * @param arg {Chart.Common.Command.Args.UpdateSelectionArgs} content.
     * @return null.
     */
	onUpdateSelection: function(args){
		if (args && args.data && args.data.startIndex && args.data.endIndex) {
			this._currentSelection.first = Chart.Common.Util.DateUtil.getDateFromIndex(args.data.startIndex);
			this._currentSelection.second = Chart.Common.Util.DateUtil.getDateFromIndex(args.data.endIndex);
			this.getCurrentData();
		}
	},
	onDeleteInvestment: function(args){
		if (args && args.data && args.data.investmentId) {
			for (var i = 0; i < this._currentData.length; i++) {
				if (this._currentData[i].key == args.data.investmentId) {
					this._currentData.splice(i, 1);
					return true;
				}
			}
		}
		args.handled = true;
		return false
	}
});