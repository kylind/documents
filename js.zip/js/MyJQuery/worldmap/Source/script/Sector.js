Chart.SectorChart = function(containerDOM){
	this.cId = +new Date();	
	this.container = containerDOM;

	this.graph = null;
	
	this.graphCanvas = null;
	this.floatCanvas = null;
	
	this.canvasWidth = 0;
	this.canvasHeight = 0;
	
	if (containerDOM) {
		this._initialize();
	}
	return this;
};
Chart.SectorChart.prototype = $.extend(new Chart.Common.Graphic.GraphElement(), {
	/*
	 * override
	 */
	resizeComponents: function(width, height){
		this.canvasWidth = width;
		this.canvasHeight = height;
		
		this.graphCanvas.css({
			width: width,
			height: height
		});
		
		this.graph.resize(width, height);
	},
	/*
	 * override
	 */
	refresh: function(){
		var me = this;
		this.graph.refresh(function(){
			me.dataSource.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.REFRESH_PRESENTATION, null));
		});
	},
	/*
	 * interface for push data mode
	 * @param jsonStr {string} data string, in JSON format.
	 * @return null;
	 */
	setData: function(jsonStr){
		this.graph.setData(jsonStr);
	},
	/*
	 * another interface for push data mode, call refresh directly.
	 */
	draw: function(){
		this.graph.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.REFRESH_PRESENTATION, null));
	},
	setCulture: function(cultureName){
		var me = this;
		LocalizationManager.instance.setCurrentCulture(cultureName, function(){
			me.graph.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.SET_CULTURE, null));
		});
	},
	_initialize: function(){
		this.canvas = this.container.get(0);
		this.canvasWidth = this.container.width();
		this.canvasHeight = this.container.height();
		
		this._createElements();
		this._createComponents();
	},
	_createComponents: function(){
		this.graph = new Chart.Component.SectorGraph(this.graphCanvas);
		// this.graph.setDataSource(this.dataSource);
		this.graph.collectionChildren();
		this.graph.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.INITIALIZE, null));
	},
	_createElements: function(){
		this.container.attr({
			"cid": this.cId
		});
		//this.container.addClass("holdingperformance");
		this.graphCanvas = $($.Canvas.createDiv(this.container, "relative", 0, 0, this.canvasWidth, this.canvasHeight)).attr({
			"cid": this.cId
		});

		this.floatCanvas = $("<div></div>").appendTo(this.container).attr({
			"id": "phTip" + this.cId,
			"cid": this.cId
		});
	}
});

Chart.Component.SectorData = function(){
	this._x = this._y = this._width = this._height = 0;
};
Chart.Component.SectorData.prototype = $.extend(new Chart.Common.Command.CommandHandler(),{
	ChartType:{
		Historical: 0,
		Current: 1
	},
	DefaultData:{
		Size: {
			X: 160,
			Y: 160 
		},
		Type: 0,
		Vertices:{
			LabelMargin: 7,
			Differ: 75,	//difference between outer triangle size and inner's
			OverlapLine:{
				Color: "#FDFDFD",
				Size: 1
			},
			Vertex1:{
				//VColor: "#718DB4",
				// Label: "Serv",
				LColor: "#000000",
				Font: "Verdana",
				Size: 10,
				Border:{
					Size: 1,
					Style: "solid",
					Color: "#999999"
				}
			},
			Vertex2:{
				//VColor: "#66B503",
				// Label: "Info",
				LColor: "#000000",
				Font: "Verdana",
				Size: 10,
				Border:{
					Size: 1,
					Style: "solid",
					Color: "#999999"
				}
			},
			Vertex3:{
				//VColor: "#F36615",
				// Label: "Mfg",
				LColor: "#000000",
				Font: "Verdana",
				Size: 10,
				Border:{
					Size: 1,
					Color: "#999999"
				}
			}
		},
		Centroid: {
			Order: 1,
			Color: "#28386D",
			// InnerRadius: 4,
			//OuterRadius: 7,
			//OuterRadiusThick: 1,
			OuterColor: "#28386D",
			// S1Score: 19.188,
			// S2Score: 41.949,
			// S3Score: 38.859,
			// Label: "",
			Font: "Verdana",
			Size: 10
		},
		Benchmark: {
			Order: 0,
			Color: "#F0F0F0",
			BorderColor: "#666666",
			IsHollow: true,
			Length: 7,
			// S1Score: 19.503,
			// S2Score: 41.33,
			// S3Score: 39.161,
			// Label: "Benchmark",
			Font: "Verdana",
			Size: 10,
			Border:{
				Size: 1,
				Color: "#999999"
			}
		} 
	},

	/*
	 * set data and option
	 * @param {string} in JSON format.
	 */
	setData: function(jsonStr){
		var d = +new Date();
		var data =(typeof(jsonStr)==="string" ? $.evalJSON(jsonStr) : jsonStr);
		this.reset();
		//check required field
		if (!data || !data.Size || !data.Centroids || data.Centroids.length<0 || !data.Benchmark) {
			return false;
		}
		
		data.Vertices = $.extend(true,{}, this.DefaultData.Vertices, (data.Vertices ? data.Vertices : data.Vertices={}));
		data.Benchmark = $.extend(true,{}, this.DefaultData.Benchmark, (data.Benchmark ? data.Benchmark : data.Benchmark={}));
		
		var centroids = [];
		var centroidsLength = data.Centroids.length;
		for(var i=0; i<centroidsLength; i++){
			var centroid = data.Centroids[i];
			centroids[centroid.Order-1] = $.extend(true,{}, this.DefaultData.Centroid, centroid);
		};
		data.Centroids = centroids;
		this.data = data;
		this.executeCommand(
			new Chart.Common.Command.CommandArgs(
				null, 
				Chart.Common.Command.Commands.APPLY_CHART_SETTING, 
				{setting:data}));
		
		ChartLogger.instance.write("[time-consuming] time consuming of set data interface: " + (new Date() - d));
	},
	getRange: function(){
		return {
			x: this._x,
			y: this._y,
			width: this.data.Size.X,
			height: this.data.Size.Y
		};
	},
	setRange: function(range){
		this._x = range.x;
		this._y = range.y;
		this.data.Size.X = range.width;
		this.data.Size.Y = range.height;
	},
	/*
	 * hook function
	 */
	refresh: function(callback){
		if(callback && typeof(callback)== "function"){
			callback();
		}
	},
	/*
	 * clear all cache data.
	 */
	reset: function(){
		this.data = null;
	},
	/*
     * override. filter commands.
     * @param arg {Chart.Common.Command.CommandArgs} content.
     * @return the handler event of target command.
     */
	getHandler: function(args){
		switch (args.command) {
			case Chart.Common.Command.Commands.ADD_INVESTMENT:
			case Chart.Common.Command.Commands.DELETE_ITEM:
			case Chart.Common.Command.Commands.REFRESH_PRESENTATION:
			case Chart.Common.Command.Commands.RESIZE:
			case Chart.Common.Command.Commands.INITIALIZE:
			case Chart.Common.Command.Commands.COMPONENT_STATUS_UPDATE:
				return this.defaultHandler;
			default:
				return this.defaultHandler;
		}
		return this.defaultHandler;
	},
	/*
     * default command handler, the purpose of this is the enable all commmand will be passed to children.
     * @param arg {Chart.Common.Command.CommandArgs} content.
     * @return null.
     */
	defaultHandler: function(args){
		//do nothing here.
	},
	getAreaSize: function(){
		var triangleSize = this.data.Size.Y - this.data.Vertices.Vertex2.Size - this.data.Vertices.LabelMargin;
		triangleSize = (triangleSize > this.data.Size.X ? this.data.Size.X : triangleSize);
		return triangleSize;
	},
	getVertices: function(){
		var radian30 = 30 * 0.017453293; // degrees*0.017453293 = radians
		var size = this.data.Size;
		var vertices = this.data.Vertices;
		var triangleSize = this.getAreaSize();
		var innerTriSize = triangleSize - vertices.Differ;
		var v1Points = [
			{x: triangleSize/2, y: 0},
			{x: triangleSize - (triangleSize/2)*Math.sin(radian30), y: (triangleSize/2)*Math.cos(radian30)},
			{x: triangleSize/2 + (innerTriSize/2)*Math.sin(radian30), y: vertices.Differ/(2*Math.cos(radian30)) + (innerTriSize/2)*Math.cos(radian30)},
			{x: triangleSize/2, y: vertices.Differ/(2*Math.cos(radian30))},
			{x: triangleSize/2 - (innerTriSize/2)*Math.sin(radian30), y: vertices.Differ/(2*Math.cos(radian30)) + (innerTriSize/2)*Math.cos(radian30)},
			{x: triangleSize/2 - (triangleSize/2)*Math.sin(radian30), y: (triangleSize/2)*Math.cos(radian30)}
		];
		var L1Points = {
			"x": v1Points[0].x + vertices.LabelMargin, 
			"y": v1Points[0].y,
			"width": triangleSize - (v1Points[0].x + vertices.LabelMargin),
			"height": vertices.Vertex1.Size
		};
		var v2Points = [
			{x: triangleSize - (triangleSize/2)*Math.sin(radian30), y: (triangleSize/2)*Math.cos(radian30)},
			{x: triangleSize, y: triangleSize*Math.cos(radian30)},
			{x: triangleSize/2, y: triangleSize*Math.cos(radian30)},
			{x: triangleSize/2, y: vertices.Differ/(2*Math.cos(radian30)) + innerTriSize*Math.cos(radian30)},
			{x: triangleSize/2 + innerTriSize*Math.sin(radian30), y: vertices.Differ/(2*Math.cos(radian30)) + innerTriSize*Math.cos(radian30)},
			{x: triangleSize/2 + (innerTriSize/2)*Math.sin(radian30), y: vertices.Differ/(2*Math.cos(radian30)) + (innerTriSize/2)*Math.cos(radian30)}
		];
		var L2Points = {
			"x": v2Points[2].x, 
			"y": v2Points[2].y + vertices.LabelMargin,
			"width": triangleSize/2,
			"height": vertices.Vertex2.Size
		};
		var v3Points = [
			{x: triangleSize/2 - (triangleSize/2)*Math.sin(radian30), y: (triangleSize/2)*Math.cos(radian30)},
			{x: triangleSize/2 - (innerTriSize/2)*Math.sin(radian30), y: vertices.Differ/(2*Math.cos(radian30)) + (innerTriSize/2)*Math.cos(radian30)},
			{x: triangleSize/2 - innerTriSize*Math.sin(radian30), y: vertices.Differ/(2*Math.cos(radian30)) + innerTriSize*Math.cos(radian30)},
			{x: triangleSize/2, y: vertices.Differ/(2*Math.cos(radian30)) + innerTriSize*Math.cos(radian30)},
			{x: triangleSize/2, y: triangleSize*Math.cos(radian30)},
			{x: 0, y: triangleSize*Math.cos(radian30)}
		];
		var L3Points = {
			"x": v3Points[5].x, 
			"y": v3Points[5].y + vertices.LabelMargin,
			"width": triangleSize/2,
			"height": vertices.Vertex3.Size
		};
		
		var overlapLines =[
			[v1Points[1].x,v1Points[1].y, v1Points[2].x, v1Points[2].y],
			[v1Points[4].x,v1Points[4].y, v1Points[5].x, v1Points[5].y],
			[v2Points[2].x,v2Points[2].y, v2Points[3].x, v2Points[3].y]
		];
		return $.extend(true, {}, vertices, {Vertex1:{Points: v1Points, LPoints: L1Points},Vertex2:{Points: v2Points, LPoints: L2Points},Vertex3:{Points: v3Points, LPoints: L3Points},OverlapLines:{Points: overlapLines}});
	},
	getBenchmark: function(){
		var radian30 = 30*0.017453293;
		var outerSize = this.getAreaSize();
		var size = this.data.Benchmark.Length;
		var differ = outerSize - size;
		var bPoints = [
			{x: outerSize/2, y: differ/(2*Math.cos(radian30))},
			{x: outerSize/2 + size*Math.sin(radian30), y: differ/(2*Math.cos(radian30)) + size*Math.cos(radian30)},
			{x: outerSize/2 - size*Math.sin(radian30), y: differ/(2*Math.cos(radian30)) + size*Math.cos(radian30)}
		];
		
		return $.extend(true, {}, this.data.Benchmark, {Points: bPoints});
	},
	CalculateCentroidPoint: function(size, portfolio,benchmark){
		var f;
		if((portfolio.M * benchmark.S > benchmark.M * benchmark.S) && (portfolio.I * benchmark.S > benchmark.I * benchmark.S)){
			f = portfolio.S / benchmark.S;
		}
		else if((portfolio.M * benchmark.I > benchmark.M * portfolio.I) && (portfolio.S * benchmark.I > benchmark.S * portfolio.I)){
			f = portfolio.I / benchmark.I;
		}
		else{
			f = portfolio.M / benchmark.M;
		}
		var pHatS = portfolio.S + (1/3 - benchmark.S) * f;
		var pHatI = portfolio.I + (1/3 - benchmark.I) * f;
		var pHatM = portfolio.M + (1/3 - benchmark.M) * f;
		var x = size * (pHatS/2 + pHatI);
		var y = size * 0.866 * (1 - pHatS);
		return {x: x, y: y};
	},
	getCentroids: function(){
		var centroids = this.data.Centroids;
		var benchmark = this.data.Benchmark;
		var size = this.getAreaSize();
		for(var i = 0 ; i < centroids.length ; i++){
			var centroid = centroids[i];
			centroid.Point = this.CalculateCentroidPoint(size, 
				{S: centroid.S1Score/100, I: centroid.S2Score/100, M: centroid.S3Score/100},
				{S: benchmark.S1Score/100, I: benchmark.S2Score/100, M: benchmark.S3Score/100}
			);
		}
		return this.data.Centroids;
	}
});

Chart.Component.SectorGraph = function(target){
    this._placeHolder = target;
    this._placeHolder.css({
        "position": "relative",
        "background-color": "transparent",
        "cursor": "default"
    });
	this._tooltip = new Chart.Component.SectorGraph.ToolTip(target);
    this.labelMargin = 7;
	this._datasource = new Chart.Component.SectorData();
	this.createGraph();

};
Chart.Component.SectorGraph.prototype = $.extend(new Chart.Common.Command.CommandHandler(), {
    createGraph: function(){
		var position = this._placeHolder.position();
		canvas = $.Canvas.create(this._placeHolder, "absolute", position.left, position.top, this._placeHolder.width(), this._placeHolder.height());
		ctx = canvas.getContext("2d");
		this._graph = new $.Graphics(ctx);
	},
	defaultHandler: function(args){
		switch (args.command) {
			case Chart.Common.Command.Commands.APPLY_CHART_SETTING:
				return this._onApplyChartSetting(args);
			case Chart.Common.Command.Commands.REFRESH_PRESENTATION:
				return this.refresh();
			case Chart.Common.Command.Commands.RESIZE:
				return this.resize();
			case Chart.Common.Command.Commands.SET_CULTURE:
				return this.onSetCulture;

			// case Chart.Common.Command.Commands.INITIALIZE:
				// return this._onInitialize;
			// case Chart.Common.Command.Commands.COMPONENT_STATUS_UPDATE:
				// return this._onComponentStatusUpdate;
			default:
				return null;
		}
    },
	_onApplyChartSetting: function(args){
		if (args && args.data && args.data.setting) {
			this.applySetting(args.data.setting);
			//this.refresh();
		}
	},
    getHandler: function(args){
		return this.defaultHandler;
    },
    collectionChildren: function(){
        this.interactiveChildren = [this._datasource];
    },
    setData: function(datasource){
        this._datasource.setData(datasource);
		this._tooltip.setData({"Centroids": this._datasource.getCentroids(), "Benchmark": this._datasource.getBenchmark()});
		// var range = this.dataSource.getRange();
    },
    reset: function(){
		this._placeHolder.empty();
		this.createGraph();
	},
	resize: function(width, height){
        // this._presentation.resize(width, height);
        // this._presentation.refresh();
		this.reset();
		var range = this._datasource.getRange();
		range.width = width;
		range.height = height;
		this._datasource.setRange(range);
		this.refresh();
    },
	onSetCulture: function(args){
		if (args) {
			this.refresh();
		}
	},
	refresh: function(){
		var graph = this._graph;
		var vertices = this._datasource.getVertices();
		var vertex = vertices.Vertex1;
		graph.begin();
		graph.setLineStyle(vertex.Border.Size, vertex.Border.Color);
		graph.setNormalFill(vertex.VColor);
		graph.drawPolygon(vertex.Points);
		graph.end();
		
		var label = $.TextStudio.create(vertex.Label, this._placeHolder,"absolute", vertex.LPoints.x, vertex.LPoints.y, vertex.LPoints.width, vertex.LPoints.height);
		$(label).css({
			"color": vertex.LColor,
			"font-family": vertex.Font,
			"font-size": vertex.Size + "px",
			"line-height":vertex.Size + "px",
			"font-weight": "normal"
		});
		
		vertex = vertices.Vertex2;
		graph.begin();
		graph.setLineStyle(vertex.Border.Size, vertex.Border.Color);
		graph.setNormalFill(vertex.VColor);
		graph.drawPolygon(vertex.Points);
		graph.end();
		label = $.TextStudio.create(vertex.Label, this._placeHolder,"absolute", vertex.LPoints.x, vertex.LPoints.y, vertex.LPoints.width, vertex.LPoints.height);
		$(label).css({
			"color": vertex.LColor,
			"font-family": vertex.Font,
			"font-size": vertex.Size + "px",
			"text-align": "right",
			"line-height":vertex.Size + "px",
			"font-weight": "normal"
			
		});
		
		vertex = vertices.Vertex3;
		graph.begin();
		graph.setLineStyle(vertex.Border.Size, vertex.Border.Color);
		graph.setNormalFill(vertex.VColor);
		graph.drawPolygon(vertex.Points);
		graph.end();
		label = $.TextStudio.create(vertex.Label, this._placeHolder,"absolute", vertex.LPoints.x, vertex.LPoints.y, vertex.LPoints.width, vertex.LPoints.height);
		$(label).css({
			"color": vertex.LColor,
			"font-family": vertex.Font,
			"font-size": vertex.Size + "px",
			"line-height":vertex.Size + "px",
			"font-weight": "normal"
		});
		
		graph.begin();
		graph.setLineStyle(vertices.OverlapLine.Size, vertices.OverlapLine.Color);
		graph.setNoneFill();
		graph.drawLines(vertices.OverlapLines.Points);
		graph.end();
		
		var centroids = this._datasource.getCentroids();
		for(var i = centroids.length - 1; i >=0; i--){
			var centroid = centroids[i];
			if(centroid.OuterRadius && centroid.OuterRadius > centroid.InnerRadius){
				graph.begin();
				graph.setLineStyle(centroid.OuterRadiusThick, centroid.OuterColor);
				graph.setNoneFill();
				graph.drawCircle(centroid.Point, centroid.OuterRadius);
				graph.end();
			}
			graph.begin();
			graph.setLineStyle(0, centroid.OuterColor);
			graph.setNormalFill(centroid.Color);
			graph.drawCircle(centroid.Point, centroid.InnerRadius);
			graph.end();
		}
		
		var benchmark = this._datasource.getBenchmark();
		graph.begin();
		graph.setLineStyle(benchmark.Border.Size, benchmark.Border.Color);
		if(benchmark.IsHollow) graph.setNoneFill();
		else graph.setNormalFill(benchmark.Color);
		graph.drawPolygon(benchmark.Points);
		graph.end();
		
	},
	applySetting: function(setting){
		
	}
});

Chart.Component.SectorGraph.ToolTip = function(target){
	var me = this;
	this._target = $(target);
	var _OnMouseMove = function(e){
		var pt = $.getPosition(me._target, e);
		var tip = me._data.FindToolTip(pt);
		if(typeof(tip)=="string" && tip.length > 0){
			if (!me._tooltip) {
				me._tooltip = me._tooltipFactory.create();
			}
			me._tooltip.setContent([tip]);
			me._tooltip.popupAt($.getPosition(me._target.get(0), e));
		}
		else{
			if(me._tooltip) me._tooltip.hide();
		}
	};
	var _OnMouseOut = function(){
		if(me._tooltip) me._tooltip.hide();
	};
	this._target.mousemove(_OnMouseMove);
	this._target.mouseout(_OnMouseOut);
    this._tooltipFactory = new Chart.Common.Controls.BasicTipFactory(this._target.attr("cid"));
	this._tooltip = null;
	this._data = new Chart.Component.SectorGraph.ToolTipData();
	this.setData = function(data){
		this._data.setData(data);
	};
}
Chart.Component.SectorGraph.ToolTipData = function(){
	this._data = null;
	this.FindToolTip = function(point){
		if(!this._data || !this._data.Centroids || !this._data.Benchmark) return "";
		
		var tip = null;
		var str = null;
		var centroids = this._data.Centroids;
		var benchmark = this._data.Benchmark;
		if(Chart.Common.Graphic.GraphicUtil.inPolygon(benchmark.Points, 3, point)){
			str = benchmark.Label;
		}
		else
		{
			for(var i = 0; i < centroids.length; i++){
				var centroid = centroids[i];
				var center = centroid.Point;
				var radius = (centroid.OuterRadius ? centroid.OuterRadius : centroid.InnerRadius);
				if( radius > Math.sqrt(Math.pow(point.x - center.x, 2) + Math.pow(point.y - center.y, 2))){
					str = centroid.Label;
					break;
				}
			}
		}
		return str;
	};
	this.setData = function(data){
		this._data = data;
	};
}

