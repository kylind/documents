Chart.HistoryRangeChart = function(containerDOM){
	this.cId = +new Date();	
	this.container = containerDOM;

	this.graph = null;
	
	this.graphCanvas = null;
	this.floatCanvas = null;
	
	this.canvasWidth = 0;
	this.canvasHeight = 0;
	
	if (containerDOM) {
		this._initialize();
	}
	return this;
};
Chart.HistoryRangeChart.prototype = $.extend(new Chart.Common.Graphic.GraphElement(), {
	/*
	 * override
	 */
	resizeComponents: function(width, height){
		this.canvasWidth = width;
		this.canvasHeight = height;
		
		this.graphCanvas.css({
			width: width,
			height: height
		});
		
		this.graph.resize(width, height);
	},
	/*
	 * override
	 */
	refresh: function(){
		var me = this;
		this.graph.refresh();
	},
	/*
	 * interface for push data mode
	 * @param jsonStr {string} data string, in JSON format.
	 * @return null;
	 */
	setData: function(jsonStr){
		return this.graph.setData(jsonStr);
	},
	/*
	 * another interface for push data mode, call refresh directly.
	 */
	draw: function(){
		this.graph.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.REFRESH_PRESENTATION, null));
	},
	/*
	* values index to show floating bar, -1 to hide the floating bar
	*/
	showFloatingBar: function(index){
		this.graph.showFloatingBar(index);
	},
	setCulture: function(cultureName){
		var me = this;
		LocalizationManager.instance.setCurrentCulture(cultureName, function(){
			me.graph.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.SET_CULTURE, null));
		});
	},
	_initialize: function(){
		this.canvas = this.container.get(0);
		this.canvasWidth = this.container.width();
		this.canvasHeight = this.container.height();
		
		this._createElements();
		this._createComponents();
	},
	_createComponents: function(){
		this.graph = new Chart.Component.HistoryRangeGraph(this.graphCanvas);
		// this.graph.setDataSource(this.dataSource);
		this.graph.collectionChildren();
		this.graph.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.INITIALIZE, null));
	},
	_createElements: function(){
		this.container.attr({
			"cid": this.cId
		});
		//this.container.addClass("holdingperformance");
		this.graphCanvas = $($.Canvas.createDiv(this.container, "relative", 0, 0, this.canvasWidth, this.canvasHeight)).attr({
			"cid": this.cId
		});

		this.floatCanvas = $("<div></div>").appendTo(this.container).attr({
			"id": "phTip" + this.cId,
			"cid": this.cId
		});
	}
});

Chart.Component.HistoryRangeData = function(){
	this._x = this._y = this._width = this._height = 0;
};
Chart.Component.HistoryRangeData.prototype = $.extend(new Chart.Common.Command.CommandHandler(),{
	ChartType:{
		Equity: 0,
		FixedIncome: 1
	},
	DefaultData:{
		// "Size": {
			// "X": 160,
			// "Y": 160 
		// },
		"YAxis": {
			// "W": 140,
			"H": 205,
			"GroupH": 24,	// set 0 when not to show
			"LegendH": 24,	// set 0 when not to show
			"IntervalH": 50,
			"PaddingH": 5,
			"YMark": {
				"PaddingH": 6,
				"Font": "Verdana",
				"Size": 11,
				"Color": "#000000"
				// "Labels": ["7.0", "14.0", "21.0", "28.0"]
			},
			"Line": {
				"Size": 1,
				"Color": "#CCCCCC"
			},
			// "Range":{
				// "Max": 24,
				// "Min": 0
			// },
			"CurrentFillColor": "#333333",
			"AverageFillColor": "#F0F0F0",
			"AverageStrokeColor": "#666666"
		},
		"Groups": [
			{
				// "W":288,
				// "Icon": "/icons/image1.gif",
				"Font": "Verdana",
				"Size": 11,
				"Color": "#636563",
				// "Label": "Info",
				"Columns":[
					{
						// "W": 75,
						"BarW": 25,
						"BarColor": "#29386B"
						// "Values":
					}
				]
			}
		],
		"Legends": [
			{
				"Icon": "/imgs/im.gif",
				"Label": "Historical",
				"Font": "Verdana",
				"Size": 11,
				"Color": "#000000"
			}
		]
	},

	/*
	 * set data and option
	 * @param {string} in JSON format.
	 */
	setData: function(jsonStr){
		var d = +new Date();
		var data =(typeof(jsonStr)==="string" ? $.evalJSON(jsonStr) : jsonStr);
		this.reset();
		//check required field
		if (!data || !data.Size || !data.YAxis
			|| !data.YAxis.YMark || !data.YAxis.YMark.Labels || data.YAxis.YMark.Labels.length<1
			|| !data.YAxis.Range || isNaN(data.YAxis.Range.Max) || isNaN(data.YAxis.Range.Min)
			||!data.Groups || data.Groups.length<1) {
			return false;
		}
		this._translator = new Chart.Component.HistoryRangeTranslator(
			parseFloat(data.YAxis.Range.Min),
			parseFloat(data.YAxis.Range.Max),
			data.YAxis.IntervalH * data.YAxis.YMark.Labels.length
		);
		data.YAxis = $.extend(true,{}, this.DefaultData.YAxis, data.YAxis);
		var defaultGroup = this.DefaultData.Groups[0];
		var defaultColumn = defaultGroup.Columns[0];
		for(var ig=0; ig<data.Groups.length; ig++){
			var group = data.Groups[ig];
			for(var ic=0; ic< group.Columns.length; ic++){
				group.Columns[ic] = $.extend({},defaultColumn, group.Columns[ic]);
			}
			data.Groups[ig] = $.extend({},defaultGroup, data.Groups[ig]);
		};

		this.data = data;
		this.executeCommand(
			new Chart.Common.Command.CommandArgs(
				null, 
				Chart.Common.Command.Commands.APPLY_CHART_SETTING, 
				{setting:data}));
		
		ChartLogger.instance.write("[time-consuming] time consuming of set data interface: " + (new Date() - d));
		return true;
	},
	getRange: function(){
		return {
			x: this._x,
			y: this._y,
			width: this.data.Size.X,
			height: this.data.Size.Y
		};
	},
	setRange: function(range){
		this._x = range.x;
		this._y = range.y;
		this.data.Size.X = range.width;
		this.data.Size.Y = range.height;
	},
	/*
	 * hook function
	 */
	refresh: function(callback){
		if(callback && typeof(callback)== "function"){
			callback();
		}
	},
	/*
	 * clear all cache data.
	 */
	reset: function(){
		this.data = null;
	},
	/*
     * override. filter commands.
     * @param arg {Chart.Common.Command.CommandArgs} content.
     * @return the handler event of target command.
     */
	getHandler: function(args){
		switch (args.command) {
			case Chart.Common.Command.Commands.ADD_INVESTMENT:
			case Chart.Common.Command.Commands.DELETE_ITEM:
			case Chart.Common.Command.Commands.REFRESH_PRESENTATION:
			case Chart.Common.Command.Commands.RESIZE:
			case Chart.Common.Command.Commands.INITIALIZE:
			case Chart.Common.Command.Commands.COMPONENT_STATUS_UPDATE:
			case Chart.Common.Command.Commands.SET_CULTURE:
				return this.defaultHandler;
			default:
				return this.defaultHandler;
		}
		return this.defaultHandler;
	},
	/*
     * default command handler, the purpose of this is the enable all commmand will be passed to children.
     * @param arg {Chart.Common.Command.CommandArgs} content.
     * @return null.
     */
	defaultHandler: function(args){
		//do nothing here.
	},
	getMinMax: function(arr){
		var max, min;
		if(!arr || !(arr instanceof Array) || arr.length<1) return null;
		
		max = min = arr[0];
		for(var i=0; i<arr.length; i++){
			if(max<arr[i]) max=arr[i];
			if(min>arr[i]) min=arr[i];
		}
		
		return [min,max];
	},
	getCordinator: function(){
		var lines = [];
		var ymarkPoints = [];
		var xWay;
		var data = this.data;
		var yAxis = data.YAxis;
		for(var i=0; i<yAxis.YMark.Labels.length; i++){
			lines.push([0, i*yAxis.IntervalH, data.Size.X, i*yAxis.IntervalH]);
			ymarkPoints.push([0, i*yAxis.IntervalH + yAxis.YMark.PaddingH, yAxis.W, yAxis.YMark.Size]);
		};
		lines.push([0, yAxis.YMark.Labels.length * yAxis.IntervalH, data.Size.X, yAxis.YMark.Labels.length * yAxis.IntervalH]);
		
		xWay = yAxis.W;
		for(var ig=0; ig<data.Groups.length; ig++){
			var group = data.Groups[ig];
			for(var ic=0; ic<group.Columns.length; ic++){
				lines.push([xWay, 0, xWay, yAxis.H]);
				xWay += group.Columns[ic].W;
			}
		}
		return $.extend(true, {}, yAxis,{"Line":{"Points": lines}, "YMark":{"Points": ymarkPoints}});
	},
	getGroups: function(){
		var xSpace = this.data.YAxis.W;
		var translator = this._translator;
		var semiTriHeight = 9/2;
		var triWidth = 8;
		var data = this.data;
		for(var ig=0; ig<data.Groups.length; ig++){
			var group = data.Groups[ig];
			for(var ic=0; ic<group.Columns.length; ic++){
				var column = group.Columns[ic];
				var minMax = this.getMinMax(column.BarValues);
				column.RangePoints = [
					{x: xSpace+((column.W/2) - (column.BarW/2)), y: translator.translate(minMax[1])},
					{x: xSpace+((column.W/2) + (column.BarW/2)), y: translator.translate(minMax[1])},
					{x: xSpace+((column.W/2) + (column.BarW/2)), y: translator.translate(minMax[0])},
					{x: xSpace+((column.W/2) - (column.BarW/2)), y: translator.translate(minMax[0])}
				];
				column.CurrentPoints = [
					{x: xSpace+((column.W/2) - (column.BarW/2))-triWidth,y: translator.translate(column.BarValues[1])-semiTriHeight},
					{x: xSpace+((column.W/2) - (column.BarW/2)), y: translator.translate(column.BarValues[1])},
					{x: xSpace+((column.W/2) - (column.BarW/2))-triWidth,y: translator.translate(column.BarValues[1])+semiTriHeight}
				];
				
				column.AveragePoints = [
					{x: xSpace+((column.W/2) - (column.BarW/2))+triWidth,y: translator.translate(column.BarValues[0])-semiTriHeight},
					{x: xSpace+((column.W/2) - (column.BarW/2)), y: translator.translate(column.BarValues[0])},
					{x: xSpace+((column.W/2) - (column.BarW/2))+triWidth,y: translator.translate(column.BarValues[0])+semiTriHeight}
				];
				
				xSpace += group.Columns[ic].W;
			}
		}
		return data.Groups;
	},
	getFloatingBar: function(index){
		var barHeight = 5;
		var xSpace = this.data.YAxis.W;
		var translator = this._translator;
		var data = this.data;
		var idx = parseInt(index);
		for(var ig=0; ig<data.Groups.length; ig++){
			var group = data.Groups[ig];
			for(var ic=0; ic<group.Columns.length; ic++){
				var column = group.Columns[ic];
				if(idx >= 0 && idx < column.BarValues.length){
					var val = translator.translate(column.BarValues[idx]);
					column.FloatPoints = [
						{x: xSpace, y: val - barHeight/2},
						{x: xSpace + column.W, y: val - barHeight/2},
						{x: xSpace + column.W, y: val + barHeight/2},
						{x: xSpace, y: val + barHeight/2}
					];
				}
				else{
					column.FloatPoints = null;
				}
				xSpace += column.W;
			}
		}
		return data.Groups;
	}
});

Chart.Component.HistoryRangeGraph = function(target){
    this._placeHolder = target;
    this._placeHolder.css({
        "position": "relative",
        "background-color": "transparent",
        "cursor": "default"
    });
	//this._tooltip = new Chart.Component.HistoryRangeGraph.ToolTip(target);
    this.labelMargin = 7;
	this._datasource = new Chart.Component.HistoryRangeData();
	this.createGraph();

};
Chart.Component.HistoryRangeGraph.prototype = $.extend(new Chart.Common.Command.CommandHandler(), {
    createGraph: function(){
		var position = this._placeHolder.position();
		canvas = $.Canvas.create(this._placeHolder, "absolute", position.left, position.top, this._placeHolder.width(), this._placeHolder.height());
		ctx = canvas.getContext("2d");
		this._graph = new $.Graphics(ctx);
		canvas = $.Canvas.create(this._placeHolder, "absolute", position.left, position.top, this._placeHolder.width(), this._placeHolder.height());
		ctx = canvas.getContext("2d");
		this._floating = new $.Graphics(ctx);
	},
	defaultHandler: function(args){
		switch (args.command) {
			case Chart.Common.Command.Commands.APPLY_CHART_SETTING:
				return this._onApplyChartSetting(args);
			case Chart.Common.Command.Commands.REFRESH_PRESENTATION:
				return this.refresh();
			case Chart.Common.Command.Commands.RESIZE:
				return this.resize();
			case Chart.Common.Command.Commands.SET_CULTURE:
				return this.onSetCulture();

			// case Chart.Common.Command.Commands.INITIALIZE:
				// return this._onInitialize;
			// case Chart.Common.Command.Commands.COMPONENT_STATUS_UPDATE:
				// return this._onComponentStatusUpdate;
			default:
				return null;
		}
    },
	_onApplyChartSetting: function(args){
		if (args && args.data && args.data.setting) {
			this.applySetting(args.data.setting);
			//this.refresh();
		}
	},
    getHandler: function(args){
		return this.defaultHandler;
    },
    collectionChildren: function(){
        this.interactiveChildren = [this._datasource];
    },
    setData: function(datasource){
        this._datasource.setData(datasource);
		//this._tooltip.setData({"Years": this._datasource.getYears()});
		// var range = this.dataSource.getRange();
    },
    reset: function(){
		this._placeHolder.empty();
		this.createGraph();
	},
	resize: function(width, height){
		this.reset();
		var range = this._datasource.getRange();
		range.width = width;
		range.height = height;
		this._datasource.setRange(range);
		this.refresh();
    },
	refresh: function(){
		var graph = this._graph;
		var cord = this._datasource.getCordinator();
		graph.begin();
		graph.setLineStyle(cord.Line.Size, cord.Line.Color);
		graph.drawLines(cord.Line.Points);
		graph.end();
		
		var ymarkPoints = cord.YMark.Points;
		var labels = cord.YMark.Labels; 
		for(var i = 0; i < labels.length; i++){
			var tmpText = StrFormatter.formatNumber(parseFloat(labels[i]), 2);
			var label = $.TextStudio.create(tmpText, this._placeHolder,"absolute", ymarkPoints[i][0], ymarkPoints[i][1], ymarkPoints[i][2], ymarkPoints[i][3]);
			$(label).css({
				"color": cord.YMark.Color,
				"font-family": cord.YMark.Font,
				"font-size": cord.YMark.Size + "px",
				"line-height":cord.YMark.Size + "px",
				"font-weight": "normal",
				"text-align": "left",
				"vertical-align": "middle"
			});
		}
		
		var groups = this._datasource.getGroups();
		for(var ig=0; ig<groups.length; ig++){
			var columns = groups[ig].Columns;
			for(var ic=0; ic<columns.length; ic++){
				var column = columns[ic];
				graph.begin();
				graph.setLineStyle(0);
				graph.setNormalFill(column.BarColor);
				graph.drawPolygon(column.RangePoints);
				graph.end();
				
				graph.begin();
				graph.setLineStyle(0);
				graph.setNormalFill(cord.CurrentFillColor);
				graph.drawPolygon(column.CurrentPoints);
				graph.end();
				
				graph.begin();
				graph.setLineStyle(1, cord.AverageStrokeColor);
				graph.setNormalFill(cord.AverageFillColor);
				graph.drawPolygon(column.AveragePoints);
				graph.end();
			}
		}
		
	},
	onSetCulture: function(args){
		if (args) {
			this.refresh();
		}
	},
	applySetting: function(setting){
	},
	showFloatingBar: function(index){
		var graph = this._floating;
		if(index === -1){
			var ctx = graph._ctx;
			ctx.clearRect(0,0, this._placeHolder.width(), this._placeHolder.height());
		}
		else{
			this.showFloatingBar(-1);
			var groups = this._datasource.getFloatingBar(index);
			for(var ig=0; ig<groups.length; ig++){
				var columns = groups[ig].Columns;
				for(var ic=0; ic<columns.length; ic++){
					var column = columns[ic];
					if(column.FloatPoints!==null){
						var color= $.color.parse(column.BarColor);
						color.a = 0.4;

						graph.begin();
						graph.setLineStyle(0);
						graph.setNormalFill(color.toString());
						graph.drawPolygon(column.FloatPoints);
						graph.end();
					}
				}
			}
		}
	}
	
});

Chart.Component.HistoryRangeTranslator = function(min, max, height){
	this.min = min;
	this.max = max;
	this.height = height;
};
Chart.Component.HistoryRangeTranslator.prototype.translate = function(val){
	if(val> this.max || val<this.min) return 0;
	return ((this.max-val)/(this.max-this.min))*this.height;
};

