Chart.Component.Legend = function(target){
    TITLE_HEIGHT = 25;
    ITEM_HEIGHT = 21;
    ICON_WIDTH = 20;
    
    this._placeHolder = null;
    this._datasource = null;
	this._tooltipFactory = null;
	this._tooltip = null;
    
    this._datacenter = null;
    this._presentation = null;
    
    this.showTitle = true;
    this.showIcon = true;
    this.enableDelete = true;
    
    var _titleCanvas = null;
    var _legendCanvas = null;
    var _eventCanvas = null;
    
    var mainGraph = this;
    
	this.onShowTip = function(context, e){
		if (!mainGraph._tooltip) {
			mainGraph._tooltip = mainGraph._tooltipFactory.create();
		}
		mainGraph._tooltip.setContent([context]);
		mainGraph._tooltip.popupAt($.getPosition(mainGraph._tooltip.container.get(0), e));
	};
	this.onHideTip = function(e){
		if (mainGraph._tooltip) {
			mainGraph._tooltip.hide();
		}
	};
	
    var initializeEx = function(){
        target.css({
            "position": "relative",
            "background-color": "transparent",
            "cursor": "default"
        });
        target.get(0).onselectstart = function(){
            return false;
        };
        
        var width = target.width() - 2; //width - border size * 2; the same as height.
        var height = target.height() - 2;
		/*
        if ($.browser.msie) {
            width = width + 2;
            height = height + 2;
        }
        */
        mainGraph._placeHolder = $($.Canvas.createDiv(target, "relative", 0, 0, width, height));
        mainGraph._datacenter = new Data.DataCenter();
        mainGraph._presentation = new Presentation.PresentationManager();
		mainGraph._tooltipFactory = new Chart.Common.Controls.BasicTipFactory(target.attr("cid")); 
    };
    
    var Data = function(){
    };
    Data.LegendItemStatus = {
        Initialized: 0,
        Requesting: 1,
        Failed: 2,
        Warning: 3,
        OK: 4,
        
        getStatusPriority: function(status){
            switch (status) {
                case this.Initialized:
                    return 1;
                case this.Requesting:
                    return 5;
                case this.Failed:
                    return 4;
                case this.Warning:
                    return 3;
                case this.OK:
                    return 2;
                default:
                    return 0;
            }
        },
        convertFromItemStatus: function(itemStatus){
            switch (itemStatus) {
                case Chart.Common.Data.ItemStatus.Initialized:
                    return this.Initialized;
                case Chart.Common.Data.ItemStatus.Requesting:
                    return this.Requesting;
                case Chart.Common.Data.ItemStatus.DataResponseOK:
                case Chart.Common.Data.ItemStatus.DataCalculatedOK:
                    return this.OK;
                case Chart.Common.Data.ItemStatus.DataCalculatedEmpty:
                case Chart.Common.Data.ItemStatus.DataResponseEmpty:
                    return this.Warning;
                case Chart.Common.Data.ItemStatus.DataResponseFailed:
                case Chart.Common.Data.ItemStatus.DataCalculatedFailed:
                    return this.Failed;
                default:
                    return this.OK;
            }
        },
        compareTo: function(statusA, statusB){
            var priorityA = this.getStatusPriority(statusA);
            var priorityB = this.getStatusPriority(statusB);
            return priorityA > priorityB ? 1 : (priorityA == priorityB ? 0 : -1);
        }
    };
    
    /**
     * Data.DataCenter
     * @class Data.DataCenter
     * @brief Construct the data of items
     * @note
     */
    Data.DataCenter = function(){
        //[{investmentId: "", itemStatus: new Dictionary()},...]
        //Key: itemKey string (String), Value: ItemStatus (Chart.Common.Data.Item.ItemStatus)
        this._investments = [];
    };
    Data.DataCenter.prototype = $.extend(new Chart.Common.Command.CommandHandler(),{
		defaultHandler: function(args){
		//do nothing here.
		},
		getHandler: function(args){
			switch (args.command) {
				case Chart.Common.Command.Commands.ADD_INVESTMENT:
					return this._onAddInvestment;
				case Chart.Common.Command.Commands.DELETE_ITEM:
					return this._onDeleteItem;
				case Chart.Common.Command.Commands.DELETE_INVESTMENT:
					return this._onDeleteInvestment;
				case Chart.Common.Command.Commands.ITEM_STATUS_UPDATE:
					return this._onItemStatusUpdated;
				/*    
			 case Chart.Common.Command.Commands.REFRESH_PRESENTATION:
			 return this._onRefreshPresentation;
			 case Chart.Common.Command.Commands.RESIZE:
			 return this._onResize;
			 case Chart.Common.Command.Commands.INITIALIZE:
			 return this._onInitialize;
			 */
				case Chart.Common.Command.Commands.COMPONENT_STATUS_UPDATE:
					return this._onComponentStatusUpdate;
				default:
					return null;
			}
		},
		getInvestments : function(){
            return this._investments;
        },
		getInvestmentName: function(investmentId){
			return mainGraph._datasource.getInvestmentName(investmentId);
		},
		getInvestmentSetting: function(investmentId){
			return mainGraph._datasource.getInvestmentSetting(investmentId);
		},
        getInvestmentStatus : function(investmentId){
            var status = Data.LegendItemStatus.Initialized;
            
            if (!investmentId) 
                return status;
            var investment = this._findInvestmentById(investmentId);
            if (investment) {
                $(investment.itemStatus.values()).each(function(){
                    var tempStatus = Data.LegendItemStatus.convertFromItemStatus(this);
                    if (Data.LegendItemStatus.compareTo(tempStatus, status) > 0) {
                        status = tempStatus;
                    }
                });
            }
            return status;
        },
		addInvestment : function(investmentId, index){
            if (!investmentId) 
                return false;
            
            var investment = this._findInvestmentById(investmentId);
            if (!investment) {
                investment = {
                    investmentId: investmentId,
                    itemStatus: new Dictionary()
                };
                if (index >= 0 && index < this._investments.length) 
                    this._investments.splice(index, 0, investment);
                else 
                    this._investments.push(investment);
            }
            else {
                //If the investment is exist,but the position is dismatch
                if (index >= 0 && index < this._investments.length) {
                    var currentIndex = this._investments.indexOf(investment);
                    if (currentIndex != index) {
                        this._investments.splice(currentIndex, 1);
                        this._investments.splice(index, 0, investment);
                    }
                }
            }
            return true;
        },
        deleteInvestment : function(investmentId){
            var investment = this._findInvestmentById(investmentId);
            if (investment) {
                var index = this._investments.indexOf(investment);
                this._investments.splice(index, 1);
                return true;
            }
            return false;
        },
        deleteItem : function(itemkey){
            var investment = this._findInvestmentByDataKey(itemkey);
            if (investment) {
                return investment.itemStatus.remove(itemkey);
            }
            return false;
        },
        updateItemStatus : function(dataArg){
            if (dataArg.investmentId || dataArg.itemKey) {
                var investment = this._findInvestmentById(investmentId);
                if (!investment) 
                    investment = this._findInvestmentById(dataArg.itemKey.investmentId);
                
                if (investment) {
                    investment.itemStatus.updateItem(dataArg.itemKey.toString(), dataArg.status);
                }
            }
        },
        clearAll : function(){
            this._investments = [];
        },
        clearData : function(){
            for (var i = 0; i < this._investments.length; i++) {
                this._investments[i].itemStatus.clear();
            }
        },
		setData: function(dataStr){
			this.clearAll();
			
			var data = $.evalJSON(dataStr);
			if (!data) {
				return;
			}
		},
		
		_findInvestmentById: function(investmentId){
			for (var i = 0; i < this._investments.length; i++) {
				if (this._investments[i].investmentId == investmentId) 
					return this._investments[i];
			}
			return null;
		},
		_findInvestmentByDataKey: function(dataKey){
			for (var i = 0; i < this._investments.length; i++) {
				if (this._investments[i].itemStatus.containsKey(dataKey)) 
					return this._investments[i];
			}
			return null;
		},
		_onAddInvestment: function(args){
			if (args && args.data && args.data.investmentId) {
				this.addInvestment(args.data.investmentId, args.data.index);
			}
		},
		_onDeleteInvestment: function(args){
			if (args && args.data && args.data.investmentId) {
				if (!this.deleteInvestment(args.data.investmentId)) {
					args.handled = true;
				}
			}
		},
		_onDeleteItem: function(args){
			if (args && args.data && args.data.itemKey) {
				if (!this.deleteItem(args.data.itemKey)) {
					args.handled = true;
				}
			}
		},
		_onItemStatusUpdated: function(args){
			if (args && args.data) {
				this.updateItemStatus(args.data);
			}
		},
		_onInitialize: function(args){
		//do nothing here
		//this command will be passed to presentation
		},
		_onRefreshPresentation: function(args){
		//do nothing here
		//this command will be passed to presentation
		},
		_onResize: function(args){
		//do nothing here
		//this command will be passed to presentation
		},
		_onComponentStatusUpdate: function(args){
			if (args && args.data && args.data.status) {
				switch (args.data.status) {
					case Chart.Common.Command.ComponentStatus.ClearAll:
						this.clearAll();
						break;
					case Chart.Common.Command.ComponentStatus.ClearData:
						this.clearData();
						break;
					default:
						break;
				}
			}
		}
	});
    //data above
    
    //presentation below
    var Presentation = function(){
    };
    Presentation.GraphElement = function(){
    };
    Presentation.GraphElement.prototype = new Chart.Common.Graphic.GraphElement();
    
    Presentation.TitleArea = function(){
        this._bgCanvas = null;
        this._bgctx = null;
        this._bgGraphic = null;
        this._labelContainer = null;
        
        var border = {
            size: 1,
            style: "solid",
            color: "#DEDEDE"
        };
        
        var me = this;
        
        this.drawBG = function(width,height){
            var top = 0;
            var lingrad = this._bgctx.createLinearGradient(0, top, 0, height);
            lingrad.addColorStop(0, "#F8F6F5");
            lingrad.addColorStop(0.8, "#EFECEA");
            this._bgGraphic.setGradientFill(lingrad);
            this._bgGraphic.drawRectangle(0, top, width, height - top);
        };
        this.clear = function(){
            $(this._labelContainer).html("");
        };
        this.drawLegendTitle = function(){
            this.clear();
            
            if (mainGraph.createLegendTitle && typeof(mainGraph.createLegendTitle) == "function") {
                var title = $(mainGraph.createLegendTitle(this.getWidth(), this.getHeight())).appendTo($(this._labelContainer));
                if (mainGraph.showIcon) 
                    title.css({
                        left: ICON_WIDTH
                    });
            }
        };
        
        var initializeEx = function(){
            me.canvas = _titleCanvas;
            var arg = $(me.canvas);
            arg.css({
                "border-bottom": String.format("{0}px {1} {2}", border.size, border.style, border.color)
            });
            
            me._bgCanvas = $.Canvas.create(arg, "relative", 0, 0, me.getWidth(), me.getHeight());
            me._bgctx = me._bgCanvas.getContext("2d");
            me._bgGraphic = new $.Graphics(me._bgctx);
            me._labelContainer = $.Canvas.createDiv(arg, "absolute", 0, 0, me.getWidth(), me.getHeight());
            me.drawBG(me.getWidth(),me.getHeight());
        };
        
        initializeEx();
    };
    Presentation.TitleArea.prototype = $.extend(new Presentation.GraphElement(),{
		refresh: function(){
			this.drawLegendTitle();
		},
		reset: function(){
		
		},
		resizeComponents: function(width, height){
			this._bgCanvas.width = width;
			this._bgCanvas.height = height;
			$(this._bgCanvas).css({
				width: width,
				height: height
			});
			this._labelContainer.width = width;
			this._labelContainer.height = height;
			$(this._labelContainer).css({
				width: width,
				height: height
			});
			
			this.drawBG(width,height);
		}
	});
    
    Presentation.LegendArea = function(){
        var LEGENG_INTERVAL = 1;
        
        var _maxRowCount = 5;
        var _maxColCount = 3;
        
        var _currentRowCount = 5;
        var _currentColCount = 1;
        
        var _itemCount = 0;
        var _itemWidth = 0;
        
        var _alterColor = "#FBFAF9";
        var _highlightColor = "#EBF3FA";
        
        //Key: investmentId (String), Value: Html Item Id (string)
        var _itemList = new Dictionary();
        
        //need to be updated in constructor according to legend instance,
        //for there may have several legend components in one page.
        var _cellprefix = "cell_";
        
        var _timer = null;
        var _lastSelectedItemIndex = -1;
        var _lastClickTime;
        
        var me = this;
        
        //return [investmentId1, investmentId2, ..., InvestmentIdN ]
        this.getSelectedInvestments = function(){
            var ret = [];
            var index = 0;
            $(_itemList.values()).each(function(){
                if (getItemSelectedStatus(this)) {
                    ret.push(_itemList.keys()[index]);
                }
                index++;
            });
            return ret;
        };
        this.deleteInvestment = function(id, e){
			//var items = this.getSelectedInvestments();
			//            var str = "";
			//            $(items).each(function() { str += this; });
			ChartLogger.instance.write("[delete-inv] delete investment: " + id);
			
			mainGraph.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.DELETE_INVESTMENT, {
				investmentId: id
			}, Chart.Common.Command.CommandDirection.ToRoot));
		};
        this.showContextMenu = function(e){
            //show menu event delegate, can be implemented by invoker
        };
        this.calculateRowCol = function(){
            var maxCount = _maxRowCount * _maxColCount;
            var itemCount = _maxRowCount < 1 ? _itemCount : Math.min(_itemCount, maxCount);
            
            //horizontial layout
            _currentRowCount = _maxRowCount;
            _currentColCount = _maxColCount;
            while (_currentColCount > itemCount && _currentColCount > 1) {
                _currentColCount--;
            }
            
            _itemWidth = Math.floor((this.getWidth() - (_currentRowCount) * LEGENG_INTERVAL) / _currentColCount);
            _itemWidth = mainGraph.showIcon ? _itemWidth - ICON_WIDTH : _itemWidth;
            _itemWidth = mainGraph.enableDelete ? _itemWidth - ICON_WIDTH : _itemWidth;
        };
        this.relay = function(){
            //table layout
            this.calculateRowCol();
            var arg = $(me.canvas);
            
            //horizontial layout
            var index = 0;
            var tdCount = 2 + mainGraph.showIcon ? 1 : 0 + mainGraph.enableDelete ? 1 : 0;
            var str = String.format("<table cellpadding='0' cellspacing='0' border='0' width='{0}'>", me.getWidth());
            for (var i = 0; i < _currentRowCount; i++) {
                str += "<tr>";
                for (var j = 0; j < _currentColCount; j++) {
                    index = i * _currentColCount + j;
                    if (mainGraph.showIcon) 
                        str += String.format("<td tid='{2}{0}' style='width:{1}px;' width='{1}' ct='icon' />", index, ICON_WIDTH, _cellprefix);
                    str += String.format("<td tid='{3}{0}' height='{1}' width='{2}' ct='text' />", index, ITEM_HEIGHT, _itemWidth, _cellprefix);
                    if (mainGraph.enableDelete) 
                        str += String.format("<td tid='{2}{0}' style='width:{1}px;' width='{1}' />", index, ICON_WIDTH, _cellprefix);
                    str += String.format("<td width='{0}' />", LEGENG_INTERVAL);
                }
                str += "</tr>";
                str += String.format("<tr><td height='{0}' colspan={1}/></td>", LEGENG_INTERVAL, _currentColCount * tdCount);
            }
            str += "</table>";
            
            arg.html(str);
            arg.find("table tr:nth-child(4n+3)").css({
                "background-color": _alterColor
            }).find("td").attr({
                "bgcolor": _alterColor
            });
            arg.find("table tr:nth-child(4n+4)").css({
                "background-color": _alterColor
            }).find("td").attr({
                "bgcolor": _alterColor
            });
        };
        this.clear = function(){
            _itemCount = 0;
            _itemList.clear();
            _lastSelectedItemIndex = -1;
        };
        this.drawLegendArea = function(){
            this.clear();
            var items = mainGraph._datacenter.getInvestments();
            _itemCount = items.length;
            
            if (!mainGraph.createLegendItem || typeof(mainGraph.createLegendItem) != "function") 
                return;
            
            if (_timer) 
                return;
            _timer = setTimeout(function(){
                //clear timer, set the next refresh behavior enable.
                clearTimeout(_timer);
                _timer = null;
                
                //update the table layout
                me.relay();
                
                //horizontial layout
                var itemIndex = 0;
                for (var rowIndex = 0; rowIndex < _currentRowCount; rowIndex++) {
                    for (var colIndex = 0; colIndex < _currentColCount; colIndex++) {
                        //draw legend item here;
                        if (_itemCount > itemIndex) 
                            createItem(items[itemIndex].investmentId, _cellprefix + itemIndex);
                        else 
                            return;
                        itemIndex++;
                    }
                }
            }, 200);
        };
        
        var createItem = function(investmentId, tid){
            _itemList.add(investmentId, tid);
            var td = target.find("td[tid='" + tid + "']");
            td.mouseover(function(e){
                var arg = $(this);
                if (arg.attr("selected") == "1") 
                    return;
                setItemHighlight(arg.attr("tid"));
            });
            td.mouseout(function(e){
                var arg = $(this);
                if (arg.attr("selected") == "1") 
                    return;
                setItemNormal(arg.attr("tid"));
            });
            //            td.mouseup(function(e) {
            //                var arg = $(this);
            //                debugger;
            //                setItemSelectedStatus(arg.attr("tid"), arg.attr("selected") != "1");
            //            });
            $(mainGraph.createLegendItem(investmentId, _itemWidth, ITEM_HEIGHT)).appendTo(td.filter("[ct=text]"));
            if (mainGraph.showIcon) 
                createIcon(investmentId, ICON_WIDTH, ITEM_HEIGHT, td.get(0));
            if (mainGraph.enableDelete) 
                createDelBtn(investmentId, ICON_WIDTH, ITEM_HEIGHT, td.get(2));
        };
        var createIcon = function(investmentId, width, height, container){
            var setting = mainGraph._datasource.getInvestmentSetting(investmentId);
            if (setting) {
                var icondrawer = new Icon.Drawer(container);
                var iconsetting = new Icon.Setting();
                iconsetting.iconType = setting.shape;
                iconsetting.color = setting.color;
                iconsetting.region.width = width;
                iconsetting.region.height = height;
                var status = mainGraph._datacenter.getInvestmentStatus(investmentId);
                switch (status) {
                    case Data.LegendItemStatus.Requesting:
                        iconsetting.iconType = Icon.IconType.LoadingIcon;
                        break;
                    case Data.LegendItemStatus.Failed:
                        iconSetting.color = "#FF0000";
                        iconsetting.iconType = Icon.IconType.Error;
                        showDesc = true;
                        break;
                    case Data.LegendItemStatus.Warning:
                        //iconDrawer.Draw(iconSetting);
                        iconsetting.iconType = Icon.IconType.Warning;
                        //iconSetting.HAlign = HorizontalAlignment.Right;
                        //iconSetting.VAlign = VerticalAlignment.Bottom;
                        showDesc = true;
                        break;
                }
                $(icondrawer.draw(iconsetting)).css({
                    "float": "left"
                });
            }
        };
        var createDelBtn = function(investmentId, width, height, container){
            var icondrawer = new Icon.Drawer(container);
            var iconsetting = new Icon.Setting();
            iconsetting.iconType = Icon.IconType.Error;
            iconsetting.color = "#808080";
            iconsetting.region.width = width;
            iconsetting.region.height = height;
            iconsetting.size.width = 8;
            iconsetting.size.height = 8;
            $(icondrawer.draw(iconsetting)).css({
                "float": "left"
            }).mouseup(function(e){
                me.deleteInvestment(investmentId)
            });
        };
        var setItemHighlight = function(itemId){
            target.find("td[tid='" + itemId + "']").css({
                "background-color": _highlightColor
            });
        };
        var setItemNormal = function(itemId){
            var cells = target.find("td[tid='" + itemId + "']");
            if (cells && cells.length > 0) {
                var color = cells.get(0).bgcolor;
                cells.css({
                    "background-color": color ? color : "Transparent"
                });
            }
        };
        var setItemSelectedStatus = function(itemId, status){
            var cells = target.find("td[tid='" + itemId + "']");
            if (cells && cells.length > 0) {
                if (status) {
                    cells.attr({
                        "selected": "1"
                    });
                    cells.css({
                        "background-color": _highlightColor
                    });
                }
                else {
                    var color = cells.get(0).bgcolor;
                    cells.attr({
                        "selected": "0"
                    });
                    cells.css({
                        "background-color": color ? color : "Transparent"
                    });
                }
            }
        };
        var getItemSelectedStatus = function(itemId){
            var cells = target.find("td[tid='" + itemId + "']");
            return cells.attr("selected") == "1"
        };
        var getItemIndexAfterCursor = function(e){
            if (_itemCount <= 0) 
                return -1;
            var cell = null;
            var offset = null;
            var width = 0;
            var height = 0;
            for (var i = 0; i < _itemList.count; i++) {
                cell = target.find("td[tid='" + _itemList.values()[i] + "']");
                if (!cell || cell.length < 1) 
                    continue;
                offset = cell.offset();
                height = cell.height();
                width = 0;
                cell.each(function(){
                    width += $(this).width();
                });
                if (offset.left <= e.pageX &&
                offset.top <= e.pageY &&
                offset.left + width >= e.pageX &&
                offset.top + height >= e.pageY) 
                    return i;
            }
            return -1;
        };
        var clearAllItemSelection = function(){
            $(_itemList.values()).each(function(){
                setItemSelectedStatus(this, false);
            })
        };
        var setSelectedItemRange = function(startIndex, endIndex){
            clearAllItemSelection();
            if (startIndex < 0 && endIndex < 0) 
                return;
            
            var start = startIndex;
            var end = endIndex;
            if (start > end) {
                var temp = start;
                start = end;
                end = temp;
            }
            
            if (start < 0) {
                setItemSelectedStatus(_itemList.values()[end], true);
            }
            else {
                for (var i = start; i <= end; i++) {
                    setItemSelectedStatus(_itemList.values()[i], true);
                }
            }
        };
        var onMouseUp = function(e){
            if (_itemCount <= 0) 
                return;
            
            var currentSelectedItemOrder = getItemIndexAfterCursor(e); //currentSelectedItemOrder should be larger than -1;
            if (currentSelectedItemOrder < 0) {
                _lastSelectedItemIndex = -1;
                // clean the current selection and relative floating windows
                clearAllItemSelection();
                return;
            }
            
            //it is a click
            if (e.ctrlKey) {
            }
            else 
                if (e.shiftKey) {
                    if (_lastSelectedItemIndex > -1) {
                        setSelectedItemRange(_lastSelectedItemIndex, currentSelectedItemOrder);
                    }
                }
                else {
                    // clean the current selection and relative floating windows
                    clearAllItemSelection();
                }
            setItemSelectedStatus(_itemList.values()[currentSelectedItemOrder], true);
            _lastSelectedItemIndex = currentSelectedItemOrder;
        };
        var initializeEx = function(){
            me.canvas = _legendCanvas;
            me.relay();
            $(me.canvas).mouseup(onMouseUp);
        };
        
        initializeEx();
    };
    Presentation.LegendArea.prototype = $.extend(new Presentation.GraphElement(),{
		refresh: function(){
			this.drawLegendArea();
		},
		reset: function(){
			this.clear();
			this.relay();
		},
		resizeComponents: function(width, height){
		
		}
	});
    
    Presentation.PresentationManager = function(){
        this._legendArea = null;
        this._titleArea = null;
        this._border = mainGraph._placeHolder.get(0);
        
        var initializeEx = function(){
			//this border should be set first, or will get a wrong width in IE.
            mainGraph._placeHolder.css({
                "border": "1px solid #CCCCCC"
            });
			createElement();	
            this.canvas = mainGraph._eventCanvas;
        };
        var createElement = function(){
            var canvasWidth = mainGraph._placeHolder.width() - 2; //inner border size * 2;
            var canvasHeight = mainGraph._placeHolder.height() - 2;
            _titleCanvas = $.Canvas.createDiv(mainGraph._placeHolder, "relative", 1, 1, canvasWidth, TITLE_HEIGHT);
            _legendCanvas = $.Canvas.createDiv(mainGraph._placeHolder, "relative", 1, 1, canvasWidth, canvasHeight - TITLE_HEIGHT);
        };
        
        initializeEx();
    };
    Presentation.PresentationManager.prototype = $.extend(new Chart.Common.Command.CommandHandler(),new Presentation.GraphElement(),{
		applySetting: function(setting){
			var bgSetting = {};
			if (Chart.Setting.Presentation.BG.tryDeSerialize(setting, Chart.Setting.SettingItem.Chart, bgSetting)) {
				mainGraph._placeHolder.css({
					"background-color": bgSetting.color
				});
			}
			this._legendArea.applySetting(setting);
			if (mainGraph.showTitle) 
				this._titleArea.applySetting(setting);
		},
		refresh: function(){
			this._legendArea.refresh();
			if (mainGraph.showTitle) 
				this._titleArea.refresh();
		},
		clearAll: function(){
			this._legendArea.reset();
			if (mainGraph.showTitle) 
				this._titleArea.reset();
		},
		resizeComponents: function(width, height){
			if (mainGraph.showTitle) {
				this._legendArea.resize(width - 4, height - 4 - TITLE_HEIGHT); // -4 for (border + innerborder *2)
				this._titleArea.resize(width - 4, TITLE_HEIGHT);
			}
			else {
				this._legendArea.resize(width - 4, height - 4);
				this._titleArea.resize(width - 4, 0);
			}
			this._border.width = width - 2; //-2 for border * 2
			this._border.height = height - 2;
			mainGraph._placeHolder.css({
				width: width - 2,
				height: height - 2
			});
		},
		getHandler: function(args){
			switch (args.command) {
				case Chart.Common.Command.Commands.APPLY_CHART_SETTING:
					return this._onApplyChartSetting;
				case Chart.Common.Command.Commands.ADD_INVESTMENT:
				case Chart.Common.Command.Commands.DELETE_INVESTMENT:
				case Chart.Common.Command.Commands.DELETE_ITEM:
				case Chart.Common.Command.Commands.REFRESH_PRESENTATION:
					return this._onRefreshPresentation;
				case Chart.Common.Command.Commands.RESIZE:
					return this._onResize;
				case Chart.Common.Command.Commands.INITIALIZE:
					return this._onInitialize;
				case Chart.Common.Command.Commands.COMPONENT_STATUS_UPDATE:
					return this._onComponentStatusUpdate;
				case Chart.Common.Command.Commands.ITEM_STATUS_UPDATE:
				//return this.onItemStatusUpdated;
				default:
					return null;
			}
		},
		_onApplyChartSetting: function(args){
			if (args && args.data && args.data.setting) {
				this.applySetting(args.data.setting);
				//this.refresh();
			}
		},
		_onInitialize: function(args){
			this._legendArea = new Presentation.LegendArea();
			if (mainGraph.showTitle) 
				this._titleArea = new Presentation.TitleArea();
		},
		_onRefreshPresentation: function(args){
			if (args) {
				this.refresh();
			}
		},
		_onResize: function(args){
			if (args && args.data && args.data.width && args.data.height) {
				this.resize(args.data.width, args.data.height);
			}
			this.refresh();
		},
		_onComponentStatusUpdate: function(args){
			if (args && args.data && args.data.status) {
				switch (args.data.status) {
					case Chart.Common.Command.ComponentStatus.ClearAll:
						this.clearAll();
						break;
					case Chart.Common.Command.ComponentStatus.ClearData:
						//                    this._legendArea.refresh(true);
						break;
					default:
						break;
				}
			}
		}
	});
    
    initializeEx();
};
Chart.Component.Legend.prototype = $.extend(new Chart.Common.Command.CommandHandler(),{
	defaultHandler: function(args){
		//do nothing here.
	},
	getHandler: function(args){
		return this.defaultHandler;
	},
	collectionChildren: function(){
		this.interactiveChildren = [this._datacenter, this._presentation];
		this._datacenter.parentContainer = this;
		this._presentation.parentContainer = this;
	},
	setDataSource: function(datasource){
		this._datasource = datasource;
	},
	setData: function(dataStr){
		if (this._datacenter && this._datacenter.setData) {
			this._datacenter.setData(dataStr);
		}
	},
	resize: function(width,height){
		this._presentation.resize(width, height);
		this._presentation.refresh();
	},
	createLegendItem: function(investmentId, width, height){
		//default dehavior, this function will be override by invoker when needed
		var legend = document.createElement("DIV");
		var arg = $(legend);
		legend.width = width;
		legend.height = height;
		arg.css({
			position: "relative",
			width: width,
			height: height,
			"background-color": "Transparent"
		});
		
		var name = this._datacenter.getInvestmentName(investmentId);
		var textSize = $.TextStudio.getTextMeasure(name, arg, "legend");
		var text = new Chart.RestrictedText(arg);
		text.setTextClass("legend");
		text.setMaxTextWidth(width);
		text.showTip = this.onShowTip;
		text.hideTip = this.onHideTip;
		$(text.draw(name)).css({
			top: textSize.height > height ? 0 : (height - textSize.height) / 2
		});
		//        var textSize = $.TextStudio.getTextMeasure("Investment " + investmentId, arg, "legend");
		//        $($.TextStudio.create(
		//            "Investment " + investmentId + "with a very long long long long long long name ",
		//            arg,
		//            "relative",
		//            0,
		//            textSize.height > height ? 0 : (height - textSize.height) / 2,
		//            null, null, "legend")).css({ "float": "left" });
		return legend;
	},
	createLegendTitle: function(width, height){
		//default dehavior, this function will be override by invoker when needed
		var title = document.createElement("DIV");
		var arg = $(title);
		title.width = width;
		title.height = height;
		arg.css({
			position: "relative",
			width: width,
			height: height,
			"background-color": "Transparent"
		});
		
		var titleText = LocalizationManager.instance.getLabel("investmentName", "Investment Name");
		var textSize = $.TextStudio.getTextMeasure(titleText, arg, "legendTitle");
		$($.TextStudio.create(titleText, arg, "relative", 0, textSize.height > height ? 0 : (height - textSize.height) / 2, null, null, "legendTitle")).css({
			"float": "left"
		});
		return title;
	}
});

Chart.RestrictedText = function(container){
    var ORIGIN = 2;
    var OMIT_TEXT = "...";
    
    var _container = container;
    var _textMaxWidth = 0;
    var _textClass = "";
    var _text = "";
    
    var _retricted = false;
    var _mouseIn = false;
    
    var _zoomx = 1;
    var _zoomy = 1;
    
    var me = this;
    
    this.setMaxTextWidth = function(width){
        _textMaxWidth = width;
    };
    this.setTextClass = function(className){
        _textClass = className;
    };
    this.showTip = function(context, e){
        //default as null, will be override by invoker.
    };
    this.hideTip = function(e){
        //default as null, will be override by invoker.
    };
    this.draw = function(text){
        _text = text;
        var showTxt = _text;
        if (_textMaxWidth > 0) {
            if ($.TextStudio.getTextMeasure(showTxt, _container, _textClass).width > _textMaxWidth) {
                showTxt = getRestrictedText();
            }
        }
        var textbox = $.TextStudio.create(showTxt, _container, "relative", 0, 0, null, null, _textClass);
        if (_retricted) {
            addTip(textbox);
        }
        return textbox;
    };
    
    var getRestrictedText = function(){
        _retricted = true;
        var strShow = _text;
        strShow = strShow.substr(0, strShow.length - 4) + OMIT_TEXT;
        do {
            if ($.TextStudio.getTextMeasure(strShow, _container, _textClass).width < _textMaxWidth) 
                break;
            if (strShow.length > 4) {
                strShow = strShow.substr(0, strShow.length - 4) + OMIT_TEXT;
            }
            else {
                strShow = OMIT_TEXT;
                break;
            }
        }
        while (true);
        return strShow;
    };
    var addTip = function(textbox){
        if (_retricted && me.showTip) {
            var arg = $(textbox);
            arg.mouseover(onMouseEnter);
            arg.mousemove(onMouseMove);
            arg.mouseout(onMouseLeave);
        }
    };
    var onMouseEnter = function(e){
        _mouseIn = true;
    };
    var onMouseLeave = function(e){
        _mouseIn = false;
        me.hideTip(e)
    };
    var onMouseMove = function(e){
        if (_mouseIn) {
            me.showTip(_text, e);
        }
    };
};
