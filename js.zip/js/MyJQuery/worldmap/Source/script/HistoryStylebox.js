Chart.HistoryStyleboxChart = function(containerDOM){
	this.cId = +new Date();	
	this.container = containerDOM;

	this.graph = null;
	
	this.graphCanvas = null;
	this.floatCanvas = null;
	
	this.canvasWidth = 0;
	this.canvasHeight = 0;
	
	if (containerDOM) {
		this._initialize();
	}
	return this;
};
Chart.HistoryStyleboxChart.prototype = $.extend(new Chart.Common.Graphic.GraphElement(), {
	/*
	 * override
	 */
	resizeComponents: function(width, height){
		this.canvasWidth = width;
		this.canvasHeight = height;
		
		this.graphCanvas.css({
			width: width,
			height: height
		});
		
		this.graph.resize(width, height);
	},
	/*
	 * override
	 */
	refresh: function(){
		var me = this;
		this.graph.refresh();
	},
	/*
	 * interface for push data mode
	 * @param jsonStr {string} data string, in JSON format.
	 * @return null;
	 */
	setData: function(jsonStr){
		return this.graph.setData(jsonStr);
	},
	/*
	 * another interface for push data mode, call refresh directly.
	 */
	draw: function(){
		this.graph.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.REFRESH_PRESENTATION, null));
	},
	setCulture: function(cultureName){
		var me = this;
		LocalizationManager.instance.setCurrentCulture(cultureName, function(){
			me.graph.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.SET_CULTURE, null));
		});
	},
	_initialize: function(){
		this.canvas = this.container.get(0);
		this.canvasWidth = this.container.width();
		this.canvasHeight = this.container.height();
		
		this._createElements();
		this._createComponents();
	},
	_createComponents: function(){
		this.graph = new Chart.Component.HistoryStyleboxGraph(this.graphCanvas);
		// this.graph.setDataSource(this.dataSource);
		this.graph.collectionChildren();
		this.graph.executeCommand(new Chart.Common.Command.CommandArgs(null, Chart.Common.Command.Commands.INITIALIZE, null));
	},
	_createElements: function(){
		this.container.attr({
			"cid": this.cId
		});
		//this.container.addClass("holdingperformance");
		this.graphCanvas = $($.Canvas.createDiv(this.container, "relative", 0, 0, this.canvasWidth, this.canvasHeight)).attr({
			"cid": this.cId
		});

		this.floatCanvas = $("<div></div>").appendTo(this.container).attr({
			"id": "phTip" + this.cId,
			"cid": this.cId
		});
	}
});

Chart.Component.HistoryStyleboxData = function(){
	this._x = this._y = this._width = this._height = 0;
};
Chart.Component.HistoryStyleboxData.prototype = $.extend(new Chart.Common.Command.CommandHandler(),{
	ChartType:{
		Equity: 0,
		FixedIncome: 1
	},
	DefaultData: {
		"Size": {
			"X": 160,
			"Y": 160 
		},
		"Type": 0,
		"Labels":{
			"VLabels": ["Large", "Mid", "Small"],
			"HLabels": ["Value", "Blend", "Growth"],
			"Font":{
				"Family": "Verdana",
				"Size": 10,
				"Color": "#000000"
			},
			"Margin": 7,
			"Line": {
				"Size": 1,
				"Color": "#999999"
			}
		},
		"Years": [
			{
				"Order": 1,
				"Color": "#314984",
				"Radius": 5,
				"StyleScore": 226.35,
				"SizeScore": 209.627,
				"Label": "Year 2010",
				"Font": "Verdana",
				"Size": 10
			}
		]
	},

	/*
	 * set data and option
	 * @param {string} in JSON format.
	 */
	setData: function(jsonStr){
		var d = +new Date();
		var data =(typeof(jsonStr)==="string" ? $.evalJSON(jsonStr) : jsonStr);
		this.reset();
		//check required field
		if (!data || !data.Size || typeof(data.Type)==="undefined" 
			|| !data.Labels || !data.Labels.VLabels || !data.Labels.HLabels
			||!data.Years || data.Years.length<1 ) {
			return false;
		}
		
		data.Labels = $.extend(true,{}, this.DefaultData.Labels, (data.Labels ? data.Labels : null));
		
		var years = [];
		var yearsLength = data.Years.length;
		var yearDefault = this.DefaultData.Years[0];
		for(var i=0; i<yearsLength; i++){
			var centroid = data.Years[i];
			years[centroid.Order-1] = $.extend(true,{}, yearDefault, centroid);
		};
		data.Years = years;
		this.data = data;
		this.executeCommand(
			new Chart.Common.Command.CommandArgs(
				null, 
				Chart.Common.Command.Commands.APPLY_CHART_SETTING, 
				{setting:data}));
		
		ChartLogger.instance.write("[time-consuming] time consuming of set data interface: " + (new Date() - d));
		return true;
	},
	getRange: function(){
		return {
			x: this._x,
			y: this._y,
			width: this.data.Size.X,
			height: this.data.Size.Y
		};
	},
	setRange: function(range){
		this._x = range.x;
		this._y = range.y;
		this.data.Size.X = range.width;
		this.data.Size.Y = range.height;
	},
	/*
	 * hook function
	 */
	refresh: function(callback){
		if(callback && typeof(callback)== "function"){
			callback();
		}
	},
	/*
	 * clear all cache data.
	 */
	reset: function(){
		this.data = null;
	},
	/*
     * override. filter commands.
     * @param arg {Chart.Common.Command.CommandArgs} content.
     * @return the handler event of target command.
     */
	getHandler: function(args){
		switch (args.command) {
			case Chart.Common.Command.Commands.ADD_INVESTMENT:
			case Chart.Common.Command.Commands.DELETE_ITEM:
			case Chart.Common.Command.Commands.REFRESH_PRESENTATION:
			case Chart.Common.Command.Commands.RESIZE:
			case Chart.Common.Command.Commands.INITIALIZE:
			case Chart.Common.Command.Commands.COMPONENT_STATUS_UPDATE:
			case Chart.Common.Command.Commands.SET_CULTURE:
				return this.defaultHandler;
			default:
				return this.defaultHandler;
		}
		return this.defaultHandler;
	},
	/*
     * default command handler, the purpose of this is the enable all commmand will be passed to children.
     * @param arg {Chart.Common.Command.CommandArgs} content.
     * @return null.
     */
	defaultHandler: function(args){
		//do nothing here.
	},
	getArea: function(){
		var labelSpace = this.data.Labels.Font.Size + this.data.Labels.Margin
		var squareLength = (this.data.Size.Y > this.data.Size.X ? this.data.Size.X : this.data.Size.Y) - labelSpace;
		// if(this.data.Type === this.ChartType.Equity){
			return {
				x: 0,
				y: 0,
				width: squareLength,
				height: squareLength
			};
		// }
		// else{
			// return {
				// x: labelSpace,
				// y: labelSpace,
				// width: squareLength,
				// height: squareLength
			// };
		// }
	},
	getYears: function(){
		var area = this.getArea();
		var years = this.data.Years;
		for(var i=0; i<years.length; i++){
			var year = years[i];
			var point = {
				x: area.x + year.StyleScore*( area.width/300),
				y: area.y + (300 - year.SizeScore)*( area.height/300)
			};
			year.Point = point;
		}
		// return $.extend(true, {}, years);
		return years;
	},
	getCordinator: function(){
		var area = this.getArea();
		var lines = [
			[area.x, area.y, area.x + area.width, area.y],
			[area.x, area.y + area.height*1/3, area.x + area.width, area.y + area.height*1/3],
			[area.x, area.y + area.height*2/3, area.x + area.width, area.y + area.height*2/3],
			[area.x, area.y + area.height, area.x + area.width, area.y + area.height],
			[area.x, area.y, area.x, area.y + area.height],
			[area.x + area.width*1/3, area.y, area.x + area.width*1/3, area.y + area.height],
			[area.x + area.width*2/3, area.y, area.x + area.width*2/3, area.y + area.height],
			[area.x + area.width, area.y, area.x + area.width, area.y + area.height]
		];
		
		var vPoints = [
			[area.x + area.width + this.data.Labels.Margin, area.y, area.width*1/3, area.height*1/3],
			[area.x + area.width + this.data.Labels.Margin, area.y + area.height*1/3, area.width*1/3, area.height*1/3],
			[area.x + area.width + this.data.Labels.Margin, area.y + area.height*2/3, area.width*1/3, area.height*1/3],
		];
		var hPoints = [
			[area.x, area.y + area.height + this.data.Labels.Margin, area.width*1/3, this.data.Labels.Font.Size],
			[area.x + area.width*1/3, area.y + area.height + this.data.Labels.Margin, area.width*1/3, this.data.Labels.Font.Size],
			[area.x + area.width*2/3, area.y + area.height + this.data.Labels.Margin, area.width*1/3, this.data.Labels.Font.Size]
		];
		
		return $.extend(true, {}, this.data.Labels,{"Line": {"Points":lines}, "VPoints": vPoints, "HPoints": hPoints});
	}
});

Chart.Component.HistoryStyleboxGraph = function(target){
    this._placeHolder = target;
    this._placeHolder.css({
        "position": "relative",
        "background-color": "transparent",
        "cursor": "default"
    });
	this._tooltip = new Chart.Component.HistoryStyleboxGraph.ToolTip(target);
    this.labelMargin = 7;
	this._datasource = new Chart.Component.HistoryStyleboxData();
	this.createGraph();

};
Chart.Component.HistoryStyleboxGraph.prototype = $.extend(new Chart.Common.Command.CommandHandler(), {
    createGraph: function(){
		var position = this._placeHolder.position();
		canvas = $.Canvas.create(this._placeHolder, "absolute", position.left, position.top, this._placeHolder.width(), this._placeHolder.height());
		ctx = canvas.getContext("2d");
		this._graph = new $.Graphics(ctx);
	},
	defaultHandler: function(args){
		switch (args.command) {
			case Chart.Common.Command.Commands.APPLY_CHART_SETTING:
				return this._onApplyChartSetting(args);
			case Chart.Common.Command.Commands.REFRESH_PRESENTATION:
				return this.refresh();
			case Chart.Common.Command.Commands.RESIZE:
				return this.resize();
			case Chart.Common.Command.Commands.SET_CULTURE:
				return this.onSetCulture();	

			// case Chart.Common.Command.Commands.INITIALIZE:
				// return this._onInitialize;
			// case Chart.Common.Command.Commands.COMPONENT_STATUS_UPDATE:
				// return this._onComponentStatusUpdate;
			default:
				return null;
		}
    },
	_onApplyChartSetting: function(args){
		if (args && args.data && args.data.setting) {
			this.applySetting(args.data.setting);
			//this.refresh();
		}
	},
    getHandler: function(args){
		return this.defaultHandler;
    },
    collectionChildren: function(){
        this.interactiveChildren = [this._datasource];
    },
    setData: function(datasource){
        this._datasource.setData(datasource);
		this._tooltip.setData({"Years": this._datasource.getYears()});
		// var range = this.dataSource.getRange();
    },
    reset: function(){
		this._placeHolder.empty();
		this.createGraph();
	},
	resize: function(width, height){
		this.reset();
		var range = this._datasource.getRange();
		range.width = width;
		range.height = height;
		this._datasource.setRange(range);
		this.refresh();
    },
	refresh: function(){
		var graph = this._graph;
		var cord = this._datasource.getCordinator();
		graph.begin();
		graph.setLineStyle(cord.Line.Size, cord.Line.Color);
		graph.drawLines(cord.Line.Points);
		graph.end();
		
		for(var i =0; i< cord.VLabels.length; i++){
			var label = $.TextStudio.create(cord.VLabels[i], this._placeHolder,"absolute", cord.VPoints[i][0], cord.VPoints[i][1], cord.VPoints[i][2], cord.VPoints[i][3]);
			$(label).css({
				"color": cord.Font.Color,
				"font-family": cord.Font.Family,
				"font-size": cord.Font.Size + "px",
				"line-height":cord.VPoints[i][3] + "px",
				"font-weight": "normal",
				"text-align": "left",
				"vertical-align": "middle"
			});
		}
		
		for(var i =0; i< cord.HLabels.length; i++){
			var label = $.TextStudio.create(cord.HLabels[i], this._placeHolder,"absolute", cord.HPoints[i][0], cord.HPoints[i][1], cord.HPoints[i][2], cord.HPoints[i][3]);
			$(label).css({
				"color": cord.Font.Color,
				"font-family": cord.Font.Family,
				"font-size": cord.Font.Size + "px",
				"line-height":cord.Font.Size + "px",
				"font-weight": "normal",
				"text-align": "left",
				"vertical-align": "middle"
			});
		}

		var years = this._datasource.getYears();
		for(var i = years.length - 1; i >=0; i--){
			var year = years[i];
			graph.begin();
			graph.setLineStyle(0, year.OuterColor);
			graph.setNormalFill(year.Color);
			graph.drawCircle(year.Point, year.Radius);
			graph.end();
		}
		
	},
	applySetting: function(setting){
		
	},
	onSetCulture: function(args){
		if (args) {
			this.refresh();
		}
	}
});

Chart.Component.HistoryStyleboxGraph.ToolTip = function(target){
	var me = this;
	this._target = $(target);
	var _OnMouseMove = function(e){
		var pt = $.getPosition(me._target, e);
		var tip = me._data.FindToolTip(pt);
		if(typeof(tip)=="string" && tip.length > 0){
			if (!me._tooltip) {
				me._tooltip = me._tooltipFactory.create();
			}
			me._tooltip.setContent([tip]);
			me._tooltip.popupAt($.getPosition(me._target.get(0), e));
		}
		else{
			if(me._tooltip) me._tooltip.hide();
		}
	};
	var _OnMouseOut = function(){
		if(me._tooltip) me._tooltip.hide();
	};
	this._target.mousemove(_OnMouseMove);
	this._target.mouseout(_OnMouseOut);
    this._tooltipFactory = new Chart.Common.Controls.BasicTipFactory(this._target.attr("cid"));
	this._tooltip = null;
	this._data = new Chart.Component.HistoryStyleboxGraph.ToolTipData();
	this.setData = function(data){
		this._data.setData(data);
	};
}
Chart.Component.HistoryStyleboxGraph.ToolTipData = function(){
	this._data = null;
	this.FindToolTip = function(point){
		if(!this._data || !this._data.Years || this._data.Years.length<1) return "";
		
		var tip = null;
		var str = null;
		var years = this._data.Years;
		for(var i = 0; i < years.length; i++){
			var year = years[i];
			var center = year.Point;
			var radius = year.Radius;
			if( radius > Math.sqrt(Math.pow(point.x - center.x, 2) + Math.pow(point.y - center.y, 2))){
				str = year.Label;
				break;
			}
		}
		return str;
	};
	this.setData = function(data){
		this._data = data;
	};
}

