﻿var util = util;
/*8888888888888888888888888888888888*/
console.log("" == true);

var myUtil = (function(obj) {

    obj.fuck = "fuck";
    console.log(obj.fuck);
} (myUtil||{}));
normalplus();
globalvariable();
plus();

function plus() {
    var a = { n: 1 };
    var b = a; // 暂存a
    a.x = a = { n: 2 };
    console.log( 'ab a.x');
    console.log(a.x); // --> undefined
    console.log('ab b.x');
    console.log(b.x); // --> [object Object]
    
    var i = 3;
    i += i *= i;
    console.log(i);
}

function normalplus() {
    var a = { n: 1 };
    var b = a; // 暂存a
    a = { n: 2 };
    a.x = a;
    console.log('a.x');
    console.log(a.x); // --> undefined
    console.log('b.x');
    console.log(b.x); // --> [object Object]

    var i = 3;
    i += i *= i;
    console.log(i);

    var s = { n: 1 };
    var t = s;
    s.x = 5;
    console.log('t.x ' + t.x);

}

var s = 2;
function globalvariable() {
    var s = s;
    console.log('global');
    console.log(s);
}