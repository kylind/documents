﻿function getMy(param) {
  
    return {
        myParam: param,
        myField: field,
        setField: function() {
            field = 100;
        },
        setParam: function() {
            param = 100;
        }
    };

    var field = 1;
}

var my1 = getMy(1);
my1.setField();
var my2 = getMy(2);
my2.setParam();
var my3 = getMy();
console.log('----');

//-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- - param change, does obj change returned from closure?
function getStudent(techer,age) {
    var student = {
        myTecher: techer,
        myName: 'Kylin',
        myAge:age
    };

    return student;

}

var techer = { name: "zhuzhu", age: 18 };
var age = 15;
var student = getStudent(techer,age);

techer.age = 20;

age = 12;

console.log(student);

//-------------------------------- it this legal

var legal = {
    a: 1,
    b:legal.a    
};
