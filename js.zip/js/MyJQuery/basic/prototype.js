﻿var parent = {
    name: 'jack',
    language: ['english']
};

function Children(name, language) { 
    Children.prototype = parent;
    if(name) {
        this.name = name;
    }
    if(language) {
        this.language = language;
    }
   
  
}
  
var lily = new Children('lily', ['a', 'b']);
console.log('parent' + parent.name + '  ' + parent.language);
console.log('lily' + lily.name + '  ' + lily.language);


var lucy = new Children();
lucy.name = 'lucy';
lucy.language = ['c', 'd'];
console.log('parent' + parent.name + '  ' + parent.language);
console.log('lucy' + lucy.name + '  ' + lucy.language);

var minerva = new Children();
minerva.name = 'minerva';
console.log('parent' + parent.name + '  ' + parent.language);
console.log('minerva' + minerva.name + '  ' + minerva.language);

var melissa = new Children();
melissa.language.push('janpanese');

console.log('parent' + parent.name + '  ' + parent.language);

console.log('lily' + lily.name + '  ' + lily.language);
console.log('lucy' + lucy.name + '  ' + lucy.language);
console.log('minerva' + minerva.name + '  ' + minerva.language);
console.log('melissa' + melissa.name + '  ' + melissa.language);




