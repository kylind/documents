﻿// JScript 文件
function Rectangle(w,h)
{
    this.width = w;
    this.height = h;
    
    nothis="nothis";
    novar="novar";
    
    return "kylin";
}

function Rectangle1(w,h)
{
    this.width = w;
    this.height = h;
    
    return {url:"kylin"};
}

function Rectangle2(w,h)
{
    this.width = w;
    this.height = h;
    
    var obj=new Object();
    obj.url="kylin";
    return obj;
}

var rectangle = new Rectangle(100,120);

var rectangle1 = new Rectangle1(100,120);

document.write("rectangle width:"+rectangle.width+"---novar:"+rectangle.novar+"--nothis:"+nothis);
document.write("---");
document.write("rectangle1 width:"+rectangle1.width);
document.write(" URL:"+rectangle1.url);

var rectangle2 = new Rectangle2(100,120);
document.write("----rectangle2 width:"+rectangle2.width);
document.write(" URL:"+rectangle2.url);

//type judge
var bo = true;
var botype = typeof (bo);
document.write("????????????bool instance:" + botype);
document.write("??????????bool:" + typeof (Boolean));
document.write("?????????bool new boolenan:" + typeof (new Boolean(false)));

document.write("------string instance:" + typeof (new String("aa")));
document.write("-----string type:" + typeof (String));
document.write("------string direct string:" + typeof ("aa"))

;
document.write("/////////////bool:" + typeof (Boolean));

document.write("////////date instance:" + typeof(new Date()));
document.write("date:" + typeof (Date));

document.write("/////function:" + typeof(new Function()));

//``````````````````````````````````````

function myclass() {
    this.name = "myname";
    this.showName = showName;
    function showName() {
        alert(this.name);
        alert(getName());
    }

    function getName() {
        return this.name;
    }
}

var obj = new myclass;
window.name = "kkk";
obj.showName();
//-----------------------------test return function
function returnfunction() {

    var s = "kylin";
    return function() {
        console.log("kylin");
        return s;
    };
}
var funcvar = returnfunction();
console.log(typeof (funcvar));
console.log(funcvar instanceof Function);



var ar = [];
console.log(typeof (ar));
console.log("is's a array:");
console.log(ar instanceof Array);




