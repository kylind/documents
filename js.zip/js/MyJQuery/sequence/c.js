﻿var date = new Date();
console.log('c '+date.getTime()/1000);