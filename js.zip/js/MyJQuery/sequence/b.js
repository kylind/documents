﻿console.log('b ' + new Date().getTime() / 1000);
var exitTime = (new Date()).getTime() + 4000;
while ((new Date()).getTime() < exitTime) { }
console.log('b - end' + new Date().getTime() / 1000);
