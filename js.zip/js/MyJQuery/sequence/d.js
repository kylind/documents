﻿var date = new Date();
console.log('d '+date.getTime()/1000);